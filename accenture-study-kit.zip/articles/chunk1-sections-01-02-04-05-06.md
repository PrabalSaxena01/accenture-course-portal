# Accenture Mock Test Series — Articles Chunk 1 (Sections 01, 02, 04, 05, 06)

Extracted 2026-10-14 from the course player. Summaries with key facts; full Q&A text captured in later passes.

## Section 01 "Updated Exam for On Campus" > Pattern Update
Updated on-campus exam flow, 4 rounds:
- Round 1: standard personality/behavioral psychometric test ("pretty straightforward").
- Round 2: gamified assessment right after Round 1 — memory game, quick-fire math game, grid path puzzle ("find the path in the least number of steps").
- Round 3: technical assessment "in great detail" — Pseudo Code, MS Office, Cloud, Computer Networks, Cybersecurity, plus OOPS (Python OOPs, Java OOPs, JavaScript frontend questions).
- Round 4: coding round, 3 items — simple array-based DSA question; SQL query with JOINs on 2–3 tables/schemas; JavaScript frontend task (e.g. colored boxes / basic UI element).

## Section 02 "Whatsapp Group" > Whatsapp Group Link
Single line + link: https://whatsapp.com/channel/0029VbDyKtqJP2111E81Xy0E

## Section 04 "Game Based Assessment (Actual)" > Maths Quiz
Interactive game "Math Bubbles" ("Click in order: Lowest → Middle → Highest"). Score/Time (15.0)/Reset/Start Game. No question text.

## Section 04 > Memory Game
"Lock & Key Memory Game". Rules: memorize key locations before timer ends; click lock then matching key; clear pairs to unlock next level. 6 levels, 3x3 (3 keys, 12s) up to 6x6 (18 keys, 30s). Not played.

## Section 04 > Path Game
"3x3 Grid Path Builder". Stats: Moves/Best/Timer. Controls: Level 1–4, Start Level, Rotate Piece, Change Layout, Validate Path, Reset. L1: path from (0,0) to (2,2) in fewest moves. Not played.

## Section 04 > Maths Game Practice
"Math Order Challenge" — select 3 circles HIGHEST→LOWEST, 10s/question, 24 questions. Start Test / View Solution (not pressed).

## Section 05 "Accenture Full Paper (Most Recent)" > Accenture Full Paper (Exact With Solution)
Interactive practice quiz (answers NOT shown without interacting): "Accenture Technical Assessment Practice Quiz", 45 questions, 4 sections — Computer Networks (12), Cloud Computing (11), Technical MCQs (11), Pseudocode (11). Topics seen: OSI layers, topologies, cloud deployment/service models, Big-O of merge sort, Java/Python/C++ OOP snippets, pseudocode traces.

## Section 05 > Web Based
Content is two IMAGES (exam screenshots, "Secure Exam Browser 1.6.8"). Task: frontend — build a search filter: unordered list of 5 items (fruits/vegetables), class "product", "data-name" attribute with search tags; initial search value "nana"; show product if search input is part of its name else hide via CSS; list-item font-size 25px. Constraints: don't change id/class attributes; follow provided CSS. Second image: Result/Console preview (gray box; Red/Green/Blue buttons). Discussion has a user-posted solution snippet.

## Section 06 "Accenture Coding Set this year" > Accenture 8 Jan Solution txt
3 coding solutions:
1. String grid uniformity — string length is a perfect square; fill n×n grid row-wise (n = sqrt(len)); count rows+columns with all identical chars. Python + Java. Example S="aaaabbbcc" → 3×3 → answer 1.
2. SQL — join course/section/schedule tables; select course_id, course_name, day, starttime where day='wed'.
3. Web (jQuery) — dropdown of fruits (Apple, Banana, Mango, Orange) + "Show Selected" button displaying value in a paragraph; centered text.

## Section 06 > Sept 10 Set
Q1 "Running Sum and Divisibility Count" — for N, running sums 1..N, count sums divisible by given integer. Python/Java/C# solutions.
Q2 "Random Quote Generator" — web task with Math.random() on button click; HTML/CSS/JS + live "Show Random Quote" output.

## Section 06 > Accenture Sept 17 & 18
"Accenture Coding Archive 17 & 18 Sept Exams", 45-min limit, Java/Python toggle:
- Q1 (Slot 1) "Mountain Trail Elevation (Max Bitonic Subarray Sum)", Medium: contiguous subarray ≥3 checkpoints, strictly increasing to peak then strictly decreasing; max such sum (0/-1 if none). 3 test cases + O(N) solution (leftSum/rightSum at peaks) + visualizer.
- Q2 (Slot 2) "Robot Energy Peak Route", Medium: same bitonic-max-sum on energy values; example (10,20,30,25,15,5,20,40,10 → 105); O(N) + two-pointer alternative + tester.
- Q3 (Slot 3) "Array Digital Length & Digit Operations", Easy-Medium: per element, even digit-length → add (digit length)², odd → add digit sum. Example [12,345,7,8888] → 4+12+7+16=39. Playground + solution.

## Section 06 > Accenture 19 Sept Solution
"Accenture Exam Solutions 19th September Slot" (SRM KTR feedback), 3 tabs:
1. Coding — "Square Last Digit Match (Coins Problem)", Easy-Medium: count numbers 1..N whose squares end with digit D. Java/Python + simulation.
2. Web Dev — "Countdown & Pop-up".
3. SQL — "Animal & Thief Join".

## Section 06 > Coding Set 22 Sept
Just "Link :" → https://knoffcampusjobs.com/5612-2/ ("Accenture Coding Assessment QUestions , SQL , Web"). Comments (Sep 26 / Oct 2, 2026) say link not loading.

## Section 06 > Coding Set 22 Sept 2nd Shift
"Accenture Exam Solutions — 22nd September", 3 verified solutions:
- Task 1 DSA "Next Palindromic Perfect Square Difference": given N, next X>N that is both palindrome and perfect square; return |X−N|. Example N=404 → 484 → 80. C++/Java/Python/JS + tester.
- Task 2: SQL Query. Task 3: Frontend Swap.

## Section 06 > Accenture 30 Sept
"Accenture Assessment Solutions", 3 sections:
- Coding / Array: Q1 "Rotate Array to the Right by K Steps" — examples + playground + "Show Solution".
- SQL / 4-table join & aggregation: Q2 "Multi-Table Aggregation Query" — output Department Name, Total Employees, Total Salary; 7 tables "Show Tables" + solution.
- Web / UI: Q3 "Interactive Shape Switcher Widget" — Triangle/Circle/Square buttons + live preview + solution.
Discussion has student-posted solutions.

## Section 06 > Coding Set 6 October
"Accenture Technical Recruitment Solutions":
1. Coding — per unique char: (ASCII × frequency) % 5, sum non-zero results. Java/Python. 4 tests: "ababc" → 4+1+4=9; "aaaaa" → 0. Embedded ASCII/modulo calculator.
2. SQL — join Categories & Courses; courses priced above their category's average: title, category, price. Sample: Categories (Web Development, Data Science); Courses (React JS Mastery 150, Full Stack Node.js 250, Python for Data Science 300, ML Specialization 500) → expected: Full Stack Node.js/Web Development/250.00; ML Specialization/Data Science/500.00.
3. Web Lab (HTML/CSS/JS) — form input placeholders, CSS input padding, JS string processing + form events.
Discussion: user-posted Python/Java solutions.

## Section 06 > Web Based 6 oct Solution
Interactive "Web Lab Solution" (no static text): char frequency / ASCII-modulo-5 calculator — "Enter Assessment String" + "Calculate Result" (not pressed). Discussion: AMAN KASAUDHAN (Oct 7, 2026) posted HTML/JS solution ((97+i)*count % 5 per letter); PSEUDO ANONYMOUS: "bro where is the soluton".
