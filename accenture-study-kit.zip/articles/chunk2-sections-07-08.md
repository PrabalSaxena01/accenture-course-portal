# Accenture Mock Test Series — Articles Chunk 2 (Sections 07, 08)

Extracted 2026-10-14 from the course player, summary-style per question
(Asks = paraphrased question intent, Answer = key correct-answer fact, Why = explanation gist).
Note: Section 07's four items are interactive quizzes/portals, not static articles — topics only.

## Section 07 "Full Technical Set (Pracitce)"

### Complete Set - Technical 1
Interactive practice quiz "Technical Assessment Practice Quiz - Set 2", 45 MCQs (topics; answers not shown without interaction):
1. SRE: microservices OOM-crashing with low CPU, autoscaler on CPU metrics — first investigative step (options: double CPU limit, inspect heap/memory profiles, rolling restart, reduce min instances).
2. Bank: two concurrent transactions — which anomaly (incl. lost update).
3. SQL: departments with >3 employees earning >70000 — GROUP BY vs HAVING.
4. Python `for i in range(1, 6): print(i*2)` — output.
5. Python `text[::-1]` — output.
6. C uninitialized `int *ptr` — what it contains.
7. JS `let` vs `var`/`const` — characteristic of `let`.
8. Java `int arr[10]` — valid syntax?
9. Python `[1,2,3].append([4,5])` — resulting list.
10. CPU component doing arithmetic/logic ops.
11. Sharing code between modules — principle (DRY, YAGNI...).
12. Java overridden method — term (polymorphism).
13. Agile ceremony inspecting sprint progress (daily stand-up).
14. What unit tests verify.
15. REST API standard request/response format (JSON).
16. What `git pull` does.
17. Docker's core role.
18. Key benefit of auto-scaling.
19. HTTP code for "resource not found" (404).
20. What normalization reduces.
21. Java `final` keyword effect.
22. Python `len("Hello World")`.
23. SQL `WHERE age > 25 AND city = 'New York'` — result set.
24. Linux command to list files.
25. OOP principle restricting direct access (encapsulation).
26. JS `===` vs `==`.
27. Python tuple vs list — key difference.
28. Java String content comparison method.
29. Protocol for sending email (SMTP).
30. What a firewall does.
31. SQL clause that sorts (ORDER BY).
32. Java cleanup block (finally).
33. Python `dict.get(key)` on missing key.
34. Cloud "multi-tenancy" meaning.
35. Agile role prioritizing the backlog.
36. What a JS Promise represents.
37. What a foreign key enforces.
38. Linux command to change permissions.
39. Python function-definition keyword.
40. What a Git branch is.
41. What DNS resolves.
42. What inheritance enables.
43. What integration testing verifies.
44. Cloud shared-responsibility model.
45. SQL statement inserting data.

### Complete Set - Technical 2
Interactive quiz "Accenture Technical Assessment Practice Quiz", 44 questions, 4 sections:
Section 1 – Computer Science (Q1–Q14):
1. JS: passing `this` from button onclick to a function — what the function receives.
2. JS: transform [10,20,30] dividing by two — output.
3. Semantic HTML element aiding SEO/accessibility (header).
4. CSS to make square avatars circular.
5. Java: class Bike inheriting Vehicle — correct syntax.
6. WAF as inline reverse proxy — what it does (intercepts SQLi/XSS).
7. Java: class (Book) vs object (myBook) distinction.
8. `calculateArea` defined for circles vs rectangles — concept (method overloading).
9. HTTP status for missing/invalid auth token (401/403/404/500).
10. Avoiding breaking consumers on JSON API changes (versioned endpoints /v1/, /v2/).
11. DevOps: component storing built jars + image layers (artifact repository).
12. Best primary key for an ordering engine (OrderID).
13. Txn A reads balance, B modifies after — anomaly (non-repeatable read).
14. DB cluster CPU exhaustion — first diagnostic step (process list / slow-query logs / APM).
Section 2 – Networking (Q15–Q27):
15. Microsegmentation purpose (contain breaches, restrict lateral movement).
16. IPsec component providing confidentiality (ESP).
17. 50 branches to cloud DC — best connectivity (site-to-site VPN).
18. Low-latency live sports streaming — protocol (UDP).
19. Packet analyzer showing headers — OSI layer inspected (Data Link / Network).
20. Perimeter device tracking TCP connections — technology (stateful firewall).
21. Migrating apps to cloud VPCs — service model (IaaS).
22. Government with strict regulation — cloud type (private cloud).
23. Layer where virtualized servers are created (hypervisor).
24. AWS shared responsibility — customer duty (patching guest OS).
25. Flash-sale surges — cloud trait reallocating from shared pool (resource pooling).
26. Caesar cipher (+3) applied twice — result (double-shifted/garbled).
27. Enterprise Wi-Fi mutual auth — best method (EAP-TLS).
Section 3 – Pseudo Code (Q28–Q37):
28. SQL: count occurrences of 'a' in LastName.
29. SQL: list all departments incl. those with no employees (LEFT JOIN).
30. scores[2]=90 in [70,80,90,100] — printed output.
31. Regex `[a-zA-Z0-9]{6}` — which string matches.
32. Bitwise loop x=6, y=10 — final x+y.
33. 2D array with bitwise AND — printed output.
34. Recursive `sumSeries` — what it computes (sum 1..n).
35. `fun(a=2,b=4,c=5)` with conditions — printed value.
36. XOR p=3,q=6,r=4 — printed value.
37. `process(a=2,b=3,c=4)` — returned value.
Section 4 – Common Applications and OS (Q38–Q44):
38. Bottleneck component when CPU waits on disk/network (system bus).
39. Eliminating disk I/O bottlenecks on DB server (NVMe SSDs).
40. Linux subsystem managing file permissions (file system access control).
41. PowerPoint: bullets appearing one by one (entrance animation "By Paragraph").
42. Excel: current time shortcut (Ctrl+Shift+;) vs date (Ctrl+;).
43. INDEX/MATCH on sales — max-sales product (Smartphone).
44. Admin roles on workstations — principle (least privilege).

### Coding Assessment Full
"Skill Assessment Portal" overview (timed; Start buttons not clicked):
1. Coding (DSA): validate an n×n matrix containing integers 1..n; full test suite; 20 min.
2. SQL: medium query, e-commerce schema, 6 related tables; 10 min.
3. Web Dev: modify existing JS/HTML to build a dynamic counter with bounds.

### Coding Assessment Full 2
"Skill Assessment Portal" overview:
1. Coding (DSA): grid-based encryption — construct layout dimensions, read column-wise; 20 min.
2. SQL: 30-day retention rate + active subscriber metrics, SaaS billing schemas; 10 min.
3. Web Dev: client-side interactive form validation with dynamic feedback styling.
(Discussion: partial user-posted code fragments only.)

## Section 08 "Similar Questions to Accenture" (10 questions each)

### Similar Questions Like Wifi Security
- Q1: Asks which config line weakens WPA3 (SAE=Y, SUITEB=Y, SUITEB192=N). Answer: `SUITEB192 = N`. Why: 192-bit mode is for high-security environments; disabling weakens protection.
- Q2: Asks what's missing using WPA3-Personal vs Enterprise for government devices. Answer: 802.1X authentication. Why: Enterprise provides 802.1X; Personal lacks it.
- Q3: Asks impact of enabling TKIP on WPA3 for backward compatibility. Answer: reduces security (TKIP outdated). Why: TKIP is deprecated, below WPA3 standards.
- Q4: Asks risk of open network with WPA3 SAE but no password. Answer: unauthorized access. Why: open SSID lets anyone connect.
- Q5: Asks risk of WPA3 SAE with weak password policy. Answer: brute-forceable passwords. Why: SAE protects handshake, not weak passwords.
- Q6: Asks risk of disabling PMF. Answer: deauthentication attacks. Why: PMF protects management frames from spoofing/DoS.
- Q7: Asks consequence of `SUITEB192 = N` on classified network. Answer: breaks high-security compliance. Why: 192-bit mode mandatory for classified data.
- Q8: Asks risk of WPA3 with WPA2 fallback. Answer: forced WPA2 downgrade. Why: mixed mode enables downgrade attacks.
- Q9: Asks impact of disabling SAE. Answer: loss of mutual authentication. Why: SAE does secure password-based mutual auth.
- Q10: Asks risk of legacy ciphers (RC4/DES). Answer: compromise WPA3 security. Why: exploitable, below modern standards.

### Similar Question Like Accenture Asked (DevOps)
- Q1: Asks how to stop microservices reading each other's data on shared K8s. Answer: separate namespaces + isolated persistent volumes. Why: isolates filesystem data per service.
- Q2: Asks kernel mechanism stopping containers exhausting host memory. Answer: cgroups. Why: limit/monitor CPU+memory per container.
- Q3: Asks how to give one container USB sensor access only. Answer: device cgroup config. Why: controls hardware visibility per container.
- Q4: Asks how to prevent privilege escalation to host root. Answer: user namespaces + dropping capabilities. Why: blocks escalation paths.
- Q5: Asks how to handle two containers competing for CPU. Answer: CPU quotas via cgroups. Why: enforces fair allocation.
- Q6: Asks how to pin GPU workloads to GPU nodes. Answer: node affinity with GPU-labeled nodes.
- Q7: Asks how to hide host processes from containers. Answer: PID namespaces. Why: isolated PID space per container.
- Q8: Asks how to secure comms between internal financial services. Answer: service mesh with mTLS. Why: end-to-end encryption + mutual auth.
- Q9: Asks risk of mistakenly privileged container. Answer: can modify host kernel configs / access system devices. Why: near-root host access.
- Q10: Asks most critical practice for multi-tenant isolation. Answer: kernel-level isolation via namespaces + cgroups. Why: foundation of secure multi-tenancy.

### Similar Questions Like OS
- Q1: Asks syscalls for a C program to create a process running /usr/bin/python. Answer: fork() + exec. Why: fork creates, exec replaces image.
- Q2: Asks how two processes avoid concurrent access to a shared resource. Answer: mutex lock. Why: only one holder at a time.
- Q3: Asks best way to send structured data between independent processes on one machine. Answer: message queues. Why: async structured IPC.
- Q4: Asks what threads of a process share. Answer: heap memory (+ globals). Why: shared heap/globals; separate stacks/registers.
- Q5: Asks which state is NOT preserved during context switch. Answer: open file descriptors. Why: FDs are process context, unchanged by CPU switch (registers/SP saved).
- Q6: Asks where control goes on a system call. Answer: kernel mode. Why: user→kernel transition.
- Q7: Asks what happens when parent exits before child. Answer: orphan adopted by init (PID 1).
- Q8: Asks what happens on access to unowned memory. Answer: segmentation fault (SIGSEGV).
- Q9: Asks which calls redirect stdout to a file. Answer: open() + dup2(). Why: open gets FD, dup2 replaces stdout.
- Q10: Asks scheduling for real-time system needing immediate critical processes. Answer: preemptive priority scheduling. Why: high-priority preempts instantly.

### Similar Like NW / Cloud Traffic
All 10 ask which cloud features handle sudden traffic spikes (video streaming, online exams, ticket sales, e-learning, flash sales, mobile game backends, healthcare portals, analytics tools, gaming launches, webinars). Answer every time: auto-scaling + load balancing. Why: auto-scaling adjusts capacity with demand; load balancing spreads traffic so no server is overwhelmed.

### Similar Question Like Cloud
- Q1: Asks best cloud for finance org with strict data residency. Answer: private cloud. Why: full control/isolation for compliance.
- Q2: Asks who secures OS/apps in IaaS (shared responsibility). Answer: the customer. Why: provider secures hardware; OS/apps/data are customer's.
- Q3: Asks how healthcare org keeps cloud admins from reading data. Answer: customer-managed encryption keys. Why: provider can't decrypt without keys.
- Q4: Asks top hybrid-cloud practice mixing public + confidential data. Answer: data classification and segregation.
- Q5: Asks single system to control access across SaaS apps. Answer: SSO. Why: centralizes auth.
- Q6: Asks first response to unusual logins from different regions. Answer: geo-blocking + enforce MFA.
- Q7: Asks how to survive a 12-hour regional outage. Answer: multi-region data replication.
- Q8: Asks how to avoid vendor lock-in from proprietary APIs. Answer: cloud-agnostic architecture. Why: portability.
- Q9: Asks what proves ISO compliance to auditor. Answer: compliance certification report (ISO 27001/SOC 2).
- Q10: Asks how to contain a breached container. Answer: network segmentation + isolation. Why: blocks lateral movement.

### Similar Question Like CN
- Q1: Asks server response when client sends FIN. Answer: ACK. Why: ACK first, then its own FIN.
- Q2: Asks what resolves a URL to an IP. Answer: DNS.
- Q3: Asks what auto-assigns laptop IP + subnet mask. Answer: DHCP.
- Q4: Asks what maps IP→MAC locally. Answer: ARP.
- Q5: Asks how TCP guarantees ordered delivery. Answer: sequence + acknowledgment numbers.
- Q6: Asks what a router does with a packet to an unknown destination. Answer: drops it, sends ICMP Destination Unreachable.
- Q7: Asks what an HTTP response line with 404 indicates. Answer: resource not found.
- Q8: Asks primary function of network layer (L3). Answer: logical addressing + routing.
- Q9: Asks which protocol ping uses. Answer: ICMP (Echo Request/Reply).
- Q10: Asks term for wrapping data with headers/trailers down layers. Answer: encapsulation.

### Similar Like Wifi Encryption
- Q1: Asks most secure wireless encryption. Answer: WPA2 with AES.
- Q2: Asks best VPN protocol for encryption+integrity. Answer: L2TP/IPSec.
- Q3: Asks firewall type blocking unauthorized access but allowing specific apps. Answer: stateful firewall. Why: tracks connection state.
- Q4: Asks how to prevent DNS spoofing. Answer: DNSSEC. Why: validates responses.
- Q5: Asks what monitors traffic for attacks. Answer: IDS.
- Q6: Asks what dynamically assigns IPs. Answer: DHCP.
- Q7: Asks what encrypts data between web client and server. Answer: HTTPS (TLS/SSL).
- Q8: Asks purpose of sharing one public IP across devices. Answer: NAT.
- Q9: Asks protocol for secure remote access. Answer: SSH.
- Q10: Asks authentication for enterprise Wi-Fi. Answer: WPA2-Enterprise with RADIUS.

### Similar Question Like Security
- Q1: Asks attack falsifying source IP to hide identity. Answer: IP spoofing.
- Q2: Asks attack intercepting/modifying comms between two parties. Answer: man-in-the-middle.
- Q3: Asks attack sending fake ARP tying attacker MAC to trusted server. Answer: ARP poisoning.
- Q4: Asks attack sending fake DNS responses to redirect users. Answer: DNS spoofing.
- Q5: Asks attack flooding server from a single source. Answer: denial-of-service.
- Q6: Asks attack of massive traffic from many machines. Answer: DDoS.
- Q7: Asks attack of fraudulent emails/sites stealing credentials. Answer: phishing.
- Q8: Asks attack injecting scripts via unvalidated input. Answer: XSS.
- Q9: Asks attack submitting malicious SQL in login forms. Answer: SQL injection.
- Q10: Asks attack passively capturing LAN traffic. Answer: packet sniffing.

### Similar Question Like Design
- Q1: Asks instruction moving memory→accumulator. Answer: LOAD.
- Q2: Asks instruction saving accumulator to memory address. Answer: STORE.
- Q3: Asks instruction adding memory value to accumulator. Answer: ADD.
- Q4: Asks instruction type for register-to-register moves (no memory). Answer: data transfer.
- Q5: Asks instruction type for jumping to an address. Answer: branch/jump (control flow).
- Q6: Asks operand type when adding a constant to accumulator. Answer: immediate.
- Q7: Asks component holding intermediate arithmetic results. Answer: accumulator.
- Q8: Asks addressing mode adding value at memory location a register points to. Answer: register indirect.
- Q9: Asks which unit generates data-movement signals. Answer: control unit.
- Q10: Asks fetch–decode–execute phase moving memory→register. Answer: execute.

### Similar Question CN Deploy
- Q1: Asks how to connect on-prem to cloud securely. Answer: VPN or dedicated leased lines. Why: secure reliable hybrid connectivity.
- Q2: Asks how to keep cloud data unreadable to provider. Answer: server-side encryption with customer-managed keys.
- Q3: Asks best access control across SaaS apps. Answer: MFA + SSO.
- Q4: Asks best disaster-recovery approach. Answer: DRaaS. Why: cloud replication, fast recovery.
- Q5: Asks how to demonstrate continuous compliance. Answer: provider certifications + logging.
- Q6: Asks how to isolate workloads in hybrid network. Answer: VLANs + micro-segmentation.
- Q7: Asks how to secure on-prem↔cloud data in transit. Answer: TLS/SSL channels.
- Q8: Asks how to distribute traffic across regions. Answer: cloud load balancer.
- Q9: Asks how to get centralized visibility. Answer: SIEM.
- Q10: Asks how to govern multiple cloud providers. Answer: governance framework with policies + automation.

### Similar Questions Like VPN
- Q1: Asks VPN type for remote employees. Answer: remote-access VPN.
- Q2: Asks VPN type connecting two branches. Answer: site-to-site VPN.
- Q3: Asks best VPN protocol for encryption. Answer: L2TP/IPSec.
- Q4: Asks extra control for secure remote work. Answer: MFA.
- Q5: Asks VPN type for cloud app access. Answer: client-based VPN.
- Q6: Asks VPN for mobile devices. Answer: client-based VPN with mobile support.
- Q7: Asks VPN for branches using ERP/CRM. Answer: site-to-site VPN.
- Q8: Asks how to optimize VPN performance. Answer: split tunneling. Why: local traffic bypasses VPN.
- Q9: Asks VPN for hybrid on-prem+cloud access. Answer: remote-access VPN with hybrid routing.
- Q10: Asks how to gain VPN activity visibility. Answer: centralized logging + monitoring.

### Similar Questions Like Devops Deploy
- Q1: Asks what continuous deployment means. Answer: code auto-releases to production after tests pass.
- Q2: Asks purpose of continuous integration. Answer: frequent merges with automated builds; catches issues early.
- Q3: Asks role of continuous testing. Answer: automated tests verify quality at every stage.
- Q4: Asks why production monitoring matters. Answer: tracks behavior/performance post-deploy; stability.
- Q5: Asks benefit of automated build pipelines. Answer: streamlined build/test/deploy; faster, reliable releases.
- Q6: Asks how rolling deployment works. Answer: old instances gradually replaced, zero downtime.
- Q7: Asks how blue-green deployment works. Answer: two identical environments, traffic switched; minimal downtime, easy rollback.
- Q8: Asks what a canary release is. Answer: new feature to ~5% of users first.
- Q9: Asks purpose of infrastructure as code. Answer: scripts auto-configure cloud infra; consistency.
- Q10: Asks version-control best practices for CI. Answer: small frequent commits with descriptive messages.

### Similar Questions Like Cyber Attacks
- Q1: Asks attack behind false global routing announcements. Answer: BGP hijacking (prefix hijack). Why: fake announcements reroute traffic via attacker.
- Q2: Asks attack poisoning LAN ARP caches. Answer: ARP poisoning/spoofing.
- Q3: Asks attack modifying DNS responses in transit. Answer: DNS spoofing / cache poisoning.
- Q4: Asks technique of announcing more-specific prefixes to override routes. Answer: prefix deaggregation for route hijack (longest-prefix match wins).
- Q5: Asks attack of false routing updates inside corporate net. Answer: route injection / control-plane compromise.
- Q6: Asks attack tampering with AS_PATH. Answer: path manipulation for route hijacking.
- Q7: Asks attack forging messages to send traffic via malicious hop. Answer: ICMP redirect attack.
- Q8: Asks attack of compromised router advertising bad routes. Answer: route leak / unauthorized advertisement.
- Q9: Asks attack exploiting weak routing origin validation. Answer: BGP origin hijack.
- Q10: Asks attack modifying routes across transit networks on-path. Answer: advanced BGP hijack / on-path interception.

### Similar Questions Like CPU OS
- Q1: Asks register saved/restored on context switch. Answer: program counter. Why: holds next-instruction address.
- Q2: Asks register tracking stack top. Answer: stack pointer.
- Q3: Asks register holding condition flags (zero/carry/overflow). Answer: status (flag) register.
- Q4: Asks register holding instruction being decoded/executed. Answer: instruction register.
- Q5: Asks registers defining process memory boundaries. Answer: base and limit registers.
- Q6: Asks correct save order on context switch. Answer: PC, SP, status register.
- Q7: Asks why each thread needs its own PC. Answer: each tracks its next instruction independently.
- Q8: Asks registers saved during interrupts. Answer: PC, SP, status register.
- Q9: Asks what to save for memory-mapped I/O registers. Answer: general-purpose + I/O-related registers.
- Q10: Asks structure storing a thread's saved state. Answer: thread control block (TCB).

### Similar Questions Like Networking BUS
- Q1: Asks disk component reducing latency for hot data. Answer: disk controller with built-in cache.
- Q2: Asks NIC feature for CPU-free transfers. Answer: NIC with DMA + built-in buffer/cache.
- Q3: Asks GPU feature helping graphics. Answer: GPU with onboard VRAM.
- Q4: Asks disk feature for direct device→memory transfers. Answer: disk controller with DMA support.
- Q5: Asks storage controller feature cutting latency, raising throughput. Answer: SSD controller with built-in cache.
- Q6: Asks controller for low-speed keyboard input. Answer: keyboard controller (caching adds little for slow input).
- Q7: Asks audio feature preventing streaming dropouts. Answer: built-in buffer/cache.
- Q8: Asks printer feature enabling continuous printing. Answer: printer controller with built-in memory.
- Q9: Asks USB feature improving sequential transfers. Answer: USB controller with cache.
- Q10: Asks design reducing contention in multi-device buses. Answer: device controller with local buffer/cache.

### Similar Questions Like Encryption
- Q1: Asks attack where adversary chooses plaintexts, observes ciphertexts. Answer: chosen-plaintext attack.
- Q2: Asks attack exploiting decryption error messages on crafted ciphertexts. Answer: padding oracle attack. Why: errors leak plaintext.
- Q3: Asks attack intercepting unauthenticated Diffie-Hellman. Answer: man-in-the-middle.
- Q4: Asks attack measuring smart-card power during crypto. Answer: side-channel (power-analysis) attack.
- Q5: Asks attack collecting messages to find hash collisions. Answer: birthday attack.
- Q6: Asks attack reusing a captured auth token. Answer: replay attack.
- Q7: Asks attack possible with only ciphertexts. Answer: ciphertext-only attack.
- Q8: Asks attack trying every key in short keyspace. Answer: brute-force.
- Q9: Asks attack downgrading a negotiation to older protocol. Answer: downgrade attack.
- Q10: Asks attack using known plaintext–ciphertext pairs. Answer: known-plaintext attack.

### Similar Questions Like Container - CN
- Q1: Asks what containers primarily isolate. Answer: processes. Why: consistent, separated behavior.
- Q2: Asks what makes containers lightweight virtualization. Answer: shared host OS kernel. Why: less overhead, fast starts.
- Q3: Asks benefit of encapsulating code + dependencies. Answer: portability.
- Q4: Asks which architecture containers suit best. Answer: microservices.
- Q5: Asks how to stop one container starving others. Answer: resource constraints/limits.
- Q6: Asks why containers enable rapid deployment. Answer: rapid provisioning, consistent environments.
- Q7: Asks how containers fit CI/CD. Answer: consistent automated pipelines (identical envs).
- Q8: Asks container principle of no internal state. Answer: statelessness. Why: easier scale/redeploy.
- Q9: Asks benefit of layered images. Answer: efficient storage + caching.
- Q10: Asks what isolates containers from host. Answer: namespaces (+ cgroups).

### Similar Questions Like Cloud - Shared
- Q1: Asks who is responsible for cloud security. Answer: both provider and customer (shared).
- Q2: Asks customer duty in PaaS (provider manages OS/runtime). Answer: protect application logic + user data.
- Q3: Asks customer duty for IaaS VMs. Answer: secure app data + network configs.
- Q4: Asks customer duty for SaaS CRM. Answer: proper user access control.
- Q5: Asks how security works in hybrid cloud. Answer: shared between environments/parties.
- Q6: Asks developer duty on managed Kubernetes. Answer: manage container image vulnerabilities.
- Q7: Asks team duty for analytics on EC2. Answer: OS patching + firewall config.
- Q8: Asks cause when managed-DB credentials are exposed publicly. Answer: user misconfiguration (admin's responsibility).
- Q9: Asks who secures a fully org-managed private cloud. Answer: fully the customer.
- Q10: Asks customer duty in serverless. Answer: secure code + dependencies.

### Similar Questions Like OS - Management
- Q1: Asks which OS function configures printers/drives/scanners. Answer: device management. Why: prevents conflicts.
- Q2: Asks which OS feature runs background processes while user works. Answer: time sharing. Why: CPU sharing, responsiveness.
- Q3: Asks which OS component handles background services hogging CPU. Answer: the kernel. Why: scheduling + resource allocation.
- Q4: Asks which OS property lets apps survive one app's crash. Answer: fault isolation.
- Q5: Asks which OS function gives an HR app quick file access. Answer: file management.
- Q6: Asks which OS function grants an app more RAM. Answer: memory management. Why: dynamic allocation.
- Q7: Asks which OS function enforces sequential task execution. Answer: process synchronization.
- Q8: Asks which OS capability a medical device needs for on-time critical processes. Answer: real-time processing.
- Q9: Asks which OS function handles login authentication. Answer: security (auth + access permissions).
- Q10: Asks which OS type supports multiple concurrent remote sessions. Answer: multiuser system.

### Similar Questions Like Cloud Resources
- Q1: Asks cloud trait letting a bank rapidly provision servers. Answer: elasticity. Why: auto-scales to workload.
- Q2: Asks trait letting admin track multi-region usage for billing. Answer: measured service.
- Q3: Asks trait letting dev/test/prod VMs share hardware securely. Answer: multitenancy.
- Q4: Asks trait letting e-learning auto-scale. Answer: elasticity.
- Q5: Asks cloud model for hospital keeping records private + public portal. Answer: hybrid cloud.
- Q6: Asks technique for high availability across datacenters. Answer: load balancing.
- Q7: Asks trait behind pay-for-what-you-use billing. Answer: measured service (pay-as-you-go).
- Q8: Asks what creates isolated per-user environments on shared hardware. Answer: virtualization.
- Q9: Asks service model for predictive models on real-time shipment data. Answer: PaaS.
- Q10: Asks model for browser-accessed cloud CRM. Answer: SaaS.
