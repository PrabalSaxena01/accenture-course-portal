# Accenture Mock Test Series — Articles Chunk 3 (Sections 09, 12, 13, 21)

Extracted 2026-10-14 from the course player, summary-style per question
(Asks = paraphrased intent, Answer = key correct fact, Why = explanation gist).

## Section 09 "Similar Questions SQL , HTML , JS"

### SQL Trigger
10 scenario MCQs + trigger syntax/key points (BEFORE/AFTER timing, INSERT/UPDATE/DELETE events, FOR EACH ROW, OLD/NEW, delimiter use, restrictions, use cases):
1. Asks: pick trigger backing up rows deleted from students. Answer: AFTER DELETE ON students, inserting OLD row + deletion timestamp into student_backup. Why: audit copy after deletion.
2. Asks: pick trigger logging salary changes. Answer: AFTER UPDATE ON employees, inserting emp_id with OLD.salary and NEW.salary into salary_log. Why: captures before/after values.
3. Asks: pick trigger logging new hires. Answer: AFTER INSERT ON employees, inserting NEW.emp_id + join date into register_log.
4. Asks: pick trigger logging deleted products. Answer: AFTER DELETE ON products, inserting OLD.prod_id into product_log.
5. Asks: pick trigger blocking negative order totals. Answer: BEFORE INSERT ON orders, error when NEW.total_amount < 0. Why: validates before save.
6. Asks: pick trigger logging attendance changes. Answer: AFTER UPDATE ON attendance, inserting OLD/NEW percentage into attendance_log.
7. Asks: pick trigger preventing admin deletion. Answer: BEFORE DELETE ON users, error when OLD.role = 'Admin'. Why: protects admins from accidental removal.
8. Asks: pick trigger logging department changes. Answer: AFTER UPDATE ON employees, only when OLD.department ≠ NEW.department. Why: logs genuine changes only.
9. Asks: pick trigger logging new customers. Answer: AFTER INSERT ON customers into customer_log. Why: tracks join dates.
10. Asks: pick trigger blocking negative price updates. Answer: BEFORE UPDATE ON products, error when NEW.price < 0.

### JavaScript Function
10 output-prediction MCQs (DOM/document.write):
1. Asks: getElementsByTagName("p").length after appending one <p>. Answer: 1.
2. Asks: button sets innerHTML="Clicked", then document.write(btn.innerHTML). Answer: "Clicked" on blank page; button disappears. Why: document.write replaces whole document.
3. Asks: typeof input value after typing 123. Answer: "string". Why: input values are always strings.
4. Asks: div.innerHTML = 10 + 20 + "30". Answer: "3030". Why: 10+20=30, then +"30" concatenates.
5. Asks: getElementById("test") after id renamed to "sample". Answer: null.
6. Asks: document.body.lastChild.innerText after appending "New" button. Answer: "New".
7. Asks: getAttribute("id") + " " + getAttribute("data-info") on div. Answer: "block 12345".
8. Asks: childNodes.length after appending 3 <li> to <ul>. Answer: 3.
9. Asks: p.innerHTML after p.textContent = "Updated". Answer: "Updated".
10. Asks: click sets data-clicked="yes", then document.write(getAttribute("data-clicked")). Answer: "yes" on blank page; button disappears.

### JavaScript Function 2
10 output-prediction MCQs (window/screen, events, styles):
1. Asks: button writes window.innerWidth/innerHeight on maximized screen. Answer: full viewport width/height; button disappears.
2. Asks: three buttons ("One","Two","Three") share handler writing this.innerHTML. Answer: clicked button's label. Why: this = clicked button.
3. Asks: three buttons with ids share handler writing this.id. Answer: clicked button's id.
4. Asks: two buttons with data-number share handler writing getAttribute("data-number"). Answer: clicked button's number (e.g. "10").
5. Asks: "Reset" sets para.innerText = "". Answer: paragraph emptied; button remains.
6. Asks: alert(window.screen.width + " x " + height). Answer: device screen resolution (e.g. "1920 x 1080").
7. Asks: button sets div style.width = 200px. Answer: div shows 200px.
8. Asks: "Apply" sets div fontSize = 30px. Answer: div shows 30px.
9. Asks: checkbox handler writes "Clicked". Answer: "Clicked" on blank page; checkbox disappears.
10. Asks: button sets backgroundColor = "lightblue". Answer: div shows lightblue.

### JavaScript Function 3
20 output-prediction MCQs (10 Array.map + 10 button-click array methods); article also embeds scanned question images.
Map set:
1. Asks: map addTwo (n+2) over [1,2,3]. Answer: "3,4,5".
2. Asks: map double over [5,10,15]. Answer: "10,20,30".
3. Asks: map sqrt over [1,4,9]. Answer: "1,2,3".
4. Asks: map minusOne over [2,4,6]. Answer: "1,3,5".
5. Asks: map e/2 over [10,20,30]. Answer: "5,10,15".
6. Asks: map isEven over [1,2,3,4]. Answer: "false,true,false,true".
7. Asks: map upper over ["a","b","c"]. Answer: "A,B,C".
8. Asks: map n*n over [1,2,3,4]. Answer: "1,4,9,16".
9. Asks: map x>10 over [5,10,15]. Answer: "false,false,true".
10. Asks: map addFive over [3,6,9]. Answer: "8,11,14".
Button-click set:
11. Asks: button maps addTen over [2,4,6], alerts. Answer: "12,14,16".
12. Asks: button reduces "5,10,15".split(",") with parseInt sum. Answer: 30.
13. Asks: button filters evens from [1,2,3,4,5]. Answer: "2,4".
14. Asks: button finds n>7 in [5,10,15]. Answer: 10 (first match).
15. Asks: button checks every n>0 in [2,4,6]. Answer: true.
16. Asks: button checks some n>3 in [1,2,3,4]. Answer: true (4 qualifies).
17. Asks: button forEach-doubles [1,2,3] into new array. Answer: "2,4,6".
18. Asks: button concats [1,2] and [3,4]. Answer: "1,2,3,4".
19. Asks: button stringifies [1,2,3]. Answer: "[1,2,3]" (JSON text).
20. Asks: button reverses [5,10,15]. Answer: "15,10,5".

### HTML CSS
10 HTML5 semantic-element MCQs:
1. Asks: purpose of <canvas> for a live graph. Answer: drawing graphics dynamically with JavaScript.
2. Asks: what happens if browser doesn't support <audio>. Answer: fallback content inside the tag displays.
3. Asks: which video attribute adds play/pause/volume. Answer: "controls".
4. Asks: which element draws scalable shapes via XML without JS. Answer: "svg".
5. Asks: meaning of <progress value="70" max="100">. Answer: 70% progress bar.
6. Asks: role of <output> in an oninput sum form. Answer: displays calculated results dynamically.
7. Asks: what happens clicking <summary> inside <details>. Answer: hidden text expands/collapses (native disclosure widget).
8. Asks: meaning of <meter value="0.8" min="0" max="1">. Answer: gauge showing 80%.
9. Asks: semantic purpose of <article> in news page. Answer: independent, self-contained content.
10. Asks: purpose of <main> in header/main/footer layout. Answer: the document's central, unique content.

## Section 12 "Coding Assessment"

### SQL - 1
Single scenario (E-Commerce DB: customers, orders, order_items; scenario text truncated in article). Asks: query finding New York customers who purchased more than 1 product total across all orders (discussion: output id, name, total spending, distinct product count). Answer: JOIN three tables, filter city='New York', GROUP BY customer, HAVING SUM(quantity)>1, computing SUM(quantity*price) and COUNT(DISTINCT product_name). Why: joins link customers to items; grouping + HAVING isolates above-threshold.

### Web Based (1st)
Photo of Mercer Mettl "Front End Simulator" chatbot task. Asks: finish partial chatbot — welcome message → bot message (add "bot-message" class); recolor user chats to #cfe2ff; bot replies to every user input. Answer: add bot-message class to welcome; CSS user-message color #cfe2ff; sendMessage() handler appending bot reply per input. Why: three objectives = working styled chatbot. Constraint: don't modify existing ids/classes.

### SQL Query 2
Employees table (EMP_ID, NAME, DEPARTMENT, SALARY; 7 rows). Asks: highest-paid employee(s) per department → department, name, salary. Answer: keep rows where salary = department MAX (correlated subquery or per-department max join).

### Web Based (2nd)
Photo of Mercer Mettl "Product Rating System" task. Asks: five star icons (class "star", Font Awesome "fa-star") in rating-stars div; "filled" gold (#ffd700); setRating() updates display on click. Answer: five star icons; .filled { color:#ffd700 }; setRating() toggles "filled" on stars up to clicked index. Constraint: don't change class names/IDs.

### SQL Query 1
Employees + Departments tables. Asks: department names whose average salary exceeds overall company average. Answer: GROUP BY department HAVING AVG(salary) > (SELECT AVG(salary) FROM Employees), joined to Departments for names.

### Web Based Question
Photo of Mercer Mettl iPod-interface task. Asks: add "Next" button; color iPod pink; display each button's action text on screen when clicked. Answer: add button element; CSS .pod { color:pink }; click handler writing e.g. "Next action triggered" into screen element. Constraint: don't modify ids/classes.

## Section 13 "Coding Questions"

### Web Based Questions
INTERACTIVE "Cognizant GenC / Digital UI Coding Practice Lab": 10 selectable problems, each with live preview, evaluation checklist, HTML/CSS/JS solution tabs with copy-code. Problems: Shopping Cart Total; Grade Calculator & Filter; Password Validator; Multi-Step Quiz; Product Grid Filter; Modal Dialog & Timer; Responsive Drawer; LocalStorage To-Do; Tab Switcher & Badge; Char Limit & Progress. Visible problem (Shopping Cart Total): recalc row subtotals on qty change; prevent qty below zero; 10% discount when total > $100.

### Web Based Asked in 2027
INTERACTIVE "Web Development Q&A Guide", 3 tasks with live demo + full solution code:
- Task 1: canvas click draws filled rectangle exactly at mouse location + clear button. Key: map clientX/Y via getBoundingClientRect(); fillRect to draw; clearRect to clear.
- Task 2: button randomizes box background to random hex color and displays the code. Key: Math.random().toString(16); style.backgroundColor update.
- Task 3: drag element within bounded container following mouse. Key: mousedown/mousemove/mouseup with absolute positioning clamped to container bounds.

## Section 21 "Communicaiton" (all INTERACTIVE — not started)

### Complete Set
"SpeakReady" Communication Assessment — 4-part spoken-English test: Sec 1 Read & Repeat (13 sentences, 15s each); Sec 2 Listen & Repeat (10 sentences, played once, 30s to repeat); Sec 3 Speak on a Topic (4 topics, 30s prep + 60s speaking); Sec 4 Quiz (4 passages, 8 MCQs); then Results. Needs microphone.

### Versant Practice
Five Versant-modeled mock tests (listening, structure, comprehension, speaking), 10–15 min each: 1) Professional Communication (workplace/business, intermediate, 10 min); 2) Technology & Innovation (digital world, 12 min); 3) Health & Wellbeing (medical/lifestyle, upper-intermediate, 11 min); 4) Environment & Sustainability (climate/society, advanced, 13 min); 5) Education & Career (learning/growth, mixed levels).

### Practice - Voice , Speech
"Grammar Mastery Practice" — 30 medium questions on Active/Passive Voice and Direct/Indirect Speech, detailed explanations per option, behind "Start Practice →".

### Para Answers 2
"Listening Comprehension" — 8 paragraphs, 2 MCQs per passage, behind "Start Practice →".

### Speak on topic 2
"Speak on Topic Practice" — 4 topics, 30s prep + 60s auto-recorded speaking each, behind "Start Practice →".

### Speak on Topic
Same "Speak on Topic Practice" app as above (identical content; course reuses the app).

### Listen & Repeat 2
"Listen & Repeat" — 30 questions; audio plays once; Play Audio / Record Answer / Next controls (a comment notes audio may not play).

### Listen & Repeat
Same "Listen & Repeat" app (identical content; reused).

### Paragraph Answers
Same "Listening Comprehension" app as Para Answers 2 (8 paragraphs, 2 MCQs each; reused).
