# Interactive Batch — communication section (part 2)

Extracted 2026-10-14. Mic items opened only, no audio recorded.

## "Practice - Voice, Speech" — Grammar Mastery Practice (30 questions, submitted; answers = app's embedded key)
Q1–15 = Active/Passive Voice; Q16–30 = Direct/Indirect Speech. One explanation per question shown.
- Q1: Asks: passive of past-continuous (chef preparing meal when inspector arrived)? Answer: past-continuous passive ("was being prepared"). Why: "was/were being + V3".
- Q2: Asks: active of modal-perfect passive (guidelines should have been announced)? Answer: "The committee should have announced the new guidelines last week." Why: modal perfect passive → modal perfect active with doer as subject.
- Q3: Asks: passive of "Nobody has solved this cryptographic puzzle."? Answer: negative present-perfect passive ("has never been solved"). Why: "nobody" → negative passive.
- Q4: Asks: passive of "going to" future (demolish warehouse tomorrow)? Answer: "The old warehouse is going to be demolished tomorrow." Why: "going to be + V3".
- Q5: Asks: passive interrogative for "Who wrote this symphony?"? Answer: "By whom was this extraordinary symphony written?" Why: "By whom + was + subject + V3?".
- Q6: Asks: passive of polite imperative "Please maintain silence..."? Answer: "You are requested to maintain silence in the study hall." Why: "You are requested to + V1".
- Q7: Asks: passive of present-perfect (management appointed Sarah)? Answer: "Sarah has been appointed as the lead architect by the management." Why: "has/have been + V3".
- Q8: Asks: passive interrogative for "Why did the security team deny him access?"? Answer: "Why was he denied access by the security team?" Why: "was/were + subject + V3", keep word order.
- Q9: Asks: active of past-perfect passive (moisture had damaged scroll)? Answer: "Moisture had damaged the ancient scroll before they discovered it." Why: "had been + V3" → "had + V3".
- Q10: Asks: passive of "One must keep one's promises."? Answer: "Promises must be kept." Why: indefinite "one" dropped.
- Q11: Asks: passive of simple future (judge will deliver verdict Monday)? Answer: "The final verdict will be delivered by the judge on Monday." Why: "will be + V3".
- Q12: Asks: passive of past-continuous (merger was being discussed)? Answer: "The merger was being discussed when I entered the board room." Why: "was/were being + V3".
- Q13: Asks: active of "Let the gate be closed immediately."? Answer: "Close the gate immediately." Why: "Let + object + be + V3" → imperative.
- Q14: Asks: passive of simple present (company expects overtime)? Answer: "Employees are expected to work overtime during tax season by the company." Why: "is/are + V3".
- Q15: Asks: passive of past-simple double verb (opened door, offered seat)? Answer: "The door was opened and a seat was offered to her by him." Why: both verbs → passive past simple.
- Q16: Asks: indirect of David's "will finish...tomorrow"? Answer: "...he would finish reading that report the next day." Why: will→would, this→that, tomorrow→the next day.
- Q17: Asks: indirect of Maria's yes/no question (attending meeting)? Answer: "Maria asked me if I was attending the strategy meeting that afternoon." Why: if/whether + statement order; continuous → past continuous.
- Q18: Asks: indirect of manager's wh-question (where files were stored)? Answer: "The manager inquired where I had stored the backup files." Why: wh-word kept + statement order; past simple → past perfect.
- Q19: Asks: indirect of electrician's "don't touch" warning? Answer: "The electrician warned us not to touch those exposed wires." Why: "warned + object + not to + V1"; these→those.
- Q20: Asks: indirect of exclamation praising a performance? Answer: "The director exclaimed with appreciation that it had been a brilliant performance." Why: "exclaimed that" + statement; was→had been.
- Q21: Asks: indirect of professor's "Earth rotates..." statement? Answer: "...the Earth rotates on its axis once every 24 hours." Why: universal truths don't shift tense.
- Q22: Asks: indirect of Lucas's "have been working since last month."? Answer: "...he had been working on that project since the previous month." Why: present perfect continuous → past perfect continuous; this→that; last→previous.
- Q23: Asks: indirect of polite "please bring tea" request? Answer: "The elderly lady requested the nurse to bring her a cup of tea." Why: "requested + object + to + V1".
- Q24: Asks: direct of indirect ("asked me if I could help...that night")? Answer: "She said to me, 'Can you help me with my assignment tonight?'" Why: could→can; that night→tonight; pronouns revert.
- Q25: Asks: indirect of "Alas! We have lost..."? Answer: "The minister exclaimed with sorrow that they had lost their most experienced leader." Why: "exclaimed with sorrow that"; have lost→had lost.
- Q26: Asks: indirect of "Let us take a break" proposal? Answer: "The team lead suggested that we should take a break and resume in an hour." Why: "Let us" → "suggested that + subject + should + V1".
- Q27: Asks: indirect of supervisor's yes/no past question (completed assignment)? Answer: "The supervisor asked if I had completed the assignment before leaving." Why: past yes/no → if/whether + past perfect.
- Q28: Asks: indirect of officer's "must submit" obligation? Answer: "The officer said that he had to submit those documents by Friday." Why: obligation "must" → "had to".
- Q29: Asks: indirect of judge's command (call second witness)? Answer: "The judge ordered them to call the second witness immediately." Why: command → "ordered" + infinitive.
- Q30: Asks: indirect of mentor's wish for success? Answer: "The mentor wished that he might achieve great success in his career." Why: "wished that"; may→might.

## "Paragraph Answers" — Listening Comprehension (8 passages × 2 MCQs; submitted per passage; app marks correct green/red; no explanations)
- P1 (community gardens): Q1 main goal of converting vacant lots → increase green spaces and neighborhood connection. Q2 funding for seeds/tools → state environmental grant.
- P2 (solar panels): Q1 why panels got affordable → advances in photovoltaic technology. Q2 key remaining challenge → energy storage on cloudy days.
- P3 (deep-sea vents): Q1 equipment scientists use → remotely operated vehicles. Q2 how vent organisms make energy without sunlight → chemosynthesis.
- P4 (remote work): Q1 hiring advantage for employers → hire talent globally, no geographic limits. Q2 adopted flexibility/teamwork balance → hybrid work models.
- P5 (AI in healthcare): Q1 how AI helps diagnostics → analyzing scans quickly to spot abnormalities. Q2 experts' stance → supportive tool, not a replacement.
- P6 (literature festival): Q1 festival length → three days. Q2 impact on local businesses → surge in foot traffic.
- P7 (bees): Q1 primary reason for bee decline → habitat loss, pesticides, climate shifts. Q2 effective habitat-restoration practice → planting wildflowers along farm borders.
- P8 (Mars rovers): Q1 what current rovers do → collect soil samples searching for ancient microbial life. Q2 critical for long-term human survival → producing oxygen and water from Martian resources.

## Duplicates identified
- "Para Answers 2" = identical "Listening Comprehension" app (same 8 passages × 2 MCQs) — duplicate of "Paragraph Answers"; no separate extraction needed.
- "Speak on topic 2" = "Speak on Topic Practice" (4 topics, 30s prep + 60s auto-record) — mic-required, not attempted; duplicate of unnamed "Speak on Topic" article.
- "Listen & Repeat 2" = "Listen & Repeat" (30 Qs; audio plays once, then record) — mic-required, not attempted; duplicate of unnamed "Listen & Repeat" article. (Learner comment: audio may not work for some users.)

## Mic-required apps (identified, opened only, not attempted)
- "Complete Set" article = "SpeakReady" app: Sec1 Read (13 sentences, 15s aloud); Sec2 Listen (10 sentences played once, 30s repeat); Sec3 Topic (4 topics, 30s prep + 60s speak); Sec4 Quiz (4 passages × 8 MCQs).
- "Versant Practice" = 5 Versant-style mock tests (Professional Communication, Technology & Innovation, Health & Wellbeing, Environment & Sustainability, Education & Career).
