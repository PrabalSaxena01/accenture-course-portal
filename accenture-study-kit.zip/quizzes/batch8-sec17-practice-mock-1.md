# Quiz Batch 8 — Section 17 Practice Mock Test 1 (6 quizzes, 90 questions)

Extracted 2026-10-14 via submit-unanswered → View Solution.
Per-question: Asks (paraphrased intent) / Answer (correct) / Why (gist).
Note: the sixth quiz is titled "Pseudo Code (Easy)" on the platform.

## English Ability (17 questions)
- Q1: Asks: synonym for "Amiable"? Answer: Friendly.
- Q2: Asks: error in "She do not like coffee." Answer: "do not" (→ does not).
- Q3: Asks: "She is not only smart ___ hardworking." Answer: but also.
- Q4: Asks: antonym of "Expand"? Answer: Contract.
- Q5: Asks: correct spelling of accommodation word? Answer: Accommodation (double c, double m).
- Q6: Asks: passive voice of "They are building a new bridge"? Answer: "A new bridge is being built."
- Q7: Asks: "He is good ___ painting." Answer: at.
- Q8: Asks: meaning of idiom "Break the ice"? Answer: to start a conversation.
- Q9: Asks: correct word order (Beautiful / a / has / she / voice)? Answer: "She has a beautiful voice."
- Q10: Asks: "I ___ to the market yesterday." Answer: went.
- Q11: Asks: synonym for "Lethargic"? Answer: Lazy.
- Q12: Asks: indirect speech of "He said, 'I am happy'"? Answer: "He said that he was happy."
- Q13: Asks: error in "Each of the students were given a prize." Answer: "were" (→ was).
- Q14: Asks: "He walked ___ the road." Answer: across.
- Q15: Asks: antonym of "Optimistic"? Answer: Pessimistic.
- Q16: Asks: part of speech of "quickly" in "She runs quickly." Answer: Adverb.
- Q17: Asks: "___ apple a day keeps the doctor away." Answer: An.

## Critical Reasoning and Problem Solving (18 questions)
- Q1: Asks: valid conclusion from "all apples are fruits, all fruits grow on trees"? Answer: all apples grow on trees.
- Q2: Asks: time to cover same distance at 90 km/h (vs 60 km/h in 1h)? Answer: 45 minutes.
- Q3: Asks: implicit assumption in "No one without a ticket is allowed to enter." Answer: tickets are mandatory for entry.
- Q4: Asks: valid conclusion from "All cats are animals", "Some animals are dogs"? Answer: some animals are cats.
- Q5: Asks: D's sibling (A father of B, C mother of D, E is B's sister)? Answer: E.
- Q6: Asks: two pipes (6h, 8h) fill tank together — time? Answer: 3h 20m. Why: 1/6+1/8=7/24 → 24/7≈3.33h.
- Q7: Asks: next in 7, 10, 8, 11, 9, 12, ...? Answer: 10. Why: alternating +3/−2.
- Q8: Asks: distance from start after 15km E, 10km N, 15km W? Answer: 10 km (E/W cancel).
- Q9: Asks: profit % when doubling selling price triples profit? Answer: 100.
- Q10: Asks: code for "CRICKET" if "FANTA"→"LGTZG"? Answer: IXOIQKZ. Why: +6 letter shift.
- Q11: Asks: total clock strikes in 24h? Answer: 156.
- Q12: Asks: odd one out in 2, 4, 8, 16, 30, 32? Answer: 30 (series doubles).
- Q13: Asks: % of 1–70 with 1 or 9 in units digit? Answer: 20.
- Q14: Asks: P(blue) from 4 red + 6 blue? Answer: 3/5.
- Q15: Asks: loan interest problem [stem truncated]? Answer: 6.
- Q16: Asks: new person's weight when avg of 8 rises 2.5kg replacing one (old 65kg)? Answer: 85 kg. Why: 65+8×2.5.
- Q17: Asks: odd one out: Circle, Square, Rectangle, Sphere? Answer: Sphere (3D).
- Q18: Asks: sister's age if boy is 3× sister, in 12y boy will be 2× sister? Answer: 4. Why: 3x+12=2(x+12).

## Abstract Reasoning (15 questions)
- Q1: Asks: square rotates 90° clockwise 4 times — appearance? Answer: original square.
- Q2: Asks: odd one out among symbol orders? Answer: ●△■ (others follow ■,●,△).
- Q3: Asks: next after square in triangle/square alternation? Answer: Triangle.
- Q4: Asks: next polygon after triangle, square, pentagon? Answer: Hexagon.
- Q5: Asks: dot after 3 clockwise corner moves from top-left? Answer: bottom-right.
- Q6: Asks: odd one out: ▲, ■, ●, ♦? Answer: ● (only non-polygon).
- Q7: Asks: next in 1, 4, 9, 16, __? Answer: 25 (squares).
- Q8: Asks: color after 5 steps in black/white alternation? Answer: Black.
- Q9: Asks: next arrow in →, ←, →, ←, __? Answer: →.
- Q10: Asks: shaded circle portion after 3 clockwise steps? Answer: bottom-left.
- Q11: Asks: next in ▲, △, ▲, △, __? Answer: ▲.
- Q12: Asks: end position of dot moving diagonally downward? Answer: bottom-right.
- Q13: Asks: 4th division when line rotates 45° dividing square? Answer: cross-diagonal.
- Q14: Asks: next in 2, 6, 12, 20, __? Answer: 28. Why: n(n+1) pattern.
- Q15: Asks: next in black square, white triangle, black circle, white square, __? Answer: black triangle (shapes cycle, colors alternate).

## Common Application and MS Office (12 questions)
- Q1: Asks: default Word file extension? Answer: .docx.
- Q2: Asks: Excel function to average a range? Answer: AVERAGE().
- Q3: Asks: shortcut to copy in Word/Excel? Answer: Ctrl+C.
- Q4: Asks: default PowerPoint view on open? Answer: Normal View.
- Q5: Asks: Excel worksheet file extension? Answer: .xlsx.
- Q6: Asks: Word tab to insert a table? Answer: Insert.
- Q7: Asks: formula summing A1:A5? Answer: =SUM(A1:A5).
- Q8: Asks: add transitions between slides? Answer: Transitions tab.
- Q9: Asks: protect Word doc from unauthorized editing? Answer: use a password.
- Q10: Asks: Excel feature auto-filling repetitive/series data? Answer: Fill Handle.
- Q11: Asks: maximum slides in PowerPoint? Answer: 1000 (practical answer).
- Q12: Asks: what does VLOOKUP do? Answer: look up value, return corresponding value from another column.

## Network Security and Cloud (10 questions)
- Q1: Asks: common method securing network vs unauthorized access? Answer: VPN.
- Q2: Asks: primary function of firewall? Answer: monitor traffic, block/allow packets per security rules.
- Q3: Asks: cloud model giving most customer control over infra+software? Answer: IaaS.
- Q4: Asks: example of cloud security model? Answer: IAM.
- Q5: Asks: who ensures physical security in cloud? Answer: cloud service provider.
- Q6: Asks: protocol for secure browser-server communication? Answer: HTTPS.
- Q7: Asks: tool detecting/responding to network threats in real time? Answer: IPS.
- Q8: Asks: best description of public cloud? Answer: infrastructure shared by multiple orgs.
- Q9: Asks: meaning of "data encryption"? Answer: converting data to format only authorized users understand.
- Q10: Asks: meaning of "scalability" in cloud? Answer: add/remove resources based on demand.

## Pseudo Code (Easy) (18 questions)
- Q1: Asks: while-loop pseudocode (x=10,y=5; parity update) output? Answer: -5.
- Q2: Asks: recursive mystery(n)=n*mystery(n−1) computes? Answer: Factorial.
- Q3: Asks: final y after nested loops (i=1..5, j=1..i, y+=j)? Answer: 35.
- Q4: Asks: compute(6), Fibonacci-style? Answer: 21.
- Q5: Asks: final z in while loop accumulating y? Answer: 21.
- Q6: Asks: mystery/count (Collatz steps) computes? Answer: Collatz step count.
- Q7: Asks: Fibonacci-like loop (z=x+y) output? Answer: 8.
- Q8: Asks: prime counter (1–20)? Answer: 7.
- Q9: Asks: in-place reverse of [1,2,3,4]? Answer: [4, 3, 2, 1].
- Q10: Asks: x,y = y,x+y (x=10,y=20)? Answer: 20, 30.
- Q11: Asks: typeof null === "object" in JS? Answer: true (legacy).
- Q12: Asks: C code a && b++ short-circuit (a=5,b=0) output? Answer: 0. Why: b++ skipped.
- Q13: Asks: Python list aliasing (y=x; y.append(4); print(x))? Answer: [1, 2, 3, 4].
- Q14: Asks: 1 + "2" + 3 in JS? Answer: "123".
- Q15: Asks: [1,2,3].map(x*2).filter(x>4)? Answer: [6].
- Q16: Asks: 5 | 3 bitwise in C? Answer: 7.
- Q17: Asks: {1,2,3} & {3,4,5} in Python? Answer: {3} (set intersection).
- Q18: Asks: [1,2,3].reduce((acc,val)=>acc+val,0)? Answer: 6.
