# Quiz Batch 10 — Section 20 aptitude part 1 (6 quizzes, 120 questions)

Extracted 2026-10-14 via submit-unanswered → View Solution.
Per-question: Asks (paraphrased intent) / Answer (correct) / Why (gist).

## Easy Quant-1 (20 questions)
- Q1: Asks: average of 65, 85, 70, 90, 105? Answer: 83. Why: 415/5.
- Q2: Asks: length of train at 60 km/h crossing pole in 9 s? Answer: 150 m. Why: (60×5/18)×9.
- Q3: Asks: seller sells 40%, 420 apples left — total? Answer: 700. Why: 420/0.6.
- Q4: Asks: time to cover 500 m at 30 km/h? Answer: 60 s.
- Q5: Asks: man 20 days, woman 15 days; together 5 days — fraction left? Answer: 5/12. Why: 1−5(1/20+1/15).
- Q6: Asks: article sold Rs.200 at 20% loss — cost price? Answer: 250. Why: 200/0.8.
- Q7: Asks: LCM of 15, 30, 45? Answer: 90.
- Q8: Asks: P(at least one head) in 3 tosses? Answer: 7/8. Why: 1−(1/2)³.
- Q9: Asks: x+y=21, xy=110 — x²+y²? Answer: 221. Why: 21²−2×110.
- Q10: Asks: SI principal for Rs.1,25,000 interest in 5 yrs at 2.5%? Answer: 10,00,000. Why: 125000/0.125.
- Q11: Asks: a:b=5:9, b:c=7:4 — a:b:c? Answer: 35:63:36.
- Q12: Asks: ¹⁶P(r−1):¹⁵P(r−1)=16:7 — r? Answer: 10. Why: 16/(17−r)=16/7.
- Q13: Asks: 125 m train passes man running 5 km/h (same dir) in 10 s — train speed? Answer: 50 km/h. Why: rel. speed 45 + 5.
- Q14: Asks: multiplied by 3/5 instead of 5/3 — % error? Answer: 64%. Why: (5/3−3/5)/(5/3)=16/25.
- Q15: Asks: 800 m in 4 min 20 s — speed km/h? Answer: 11.05.
- Q16: Asks: L 16 days, M 12 days, with N done in 4 days — N alone? Answer: 48/5 days. Why: 1/N=1/4−1/16−1/12.
- Q17: Asks: 15% gain on CP, sale Rs.580 — profit? Answer: 75.65. Why: 580×15/115.
- Q18: Asks: ratio 3:2, LCM 30 — sum of numbers? Answer: 25 (15 and 10).
- Q19: Asks: P(numbered card) from deck? Answer: 9/13 (36/52).
- Q20: Asks: a−b=16, a²−b²=544 — 2ab? Answer: 450. Why: a+b=34; (34²−16²)/2.

## Easy Quant-2 (20 questions)
- Q1: Asks: SI — x for 7.5 yrs at 6.5%, total 125000 — x? Answer: 84034. Why: x×1.4875=125000.
- Q2: Asks: mean proportional between 0.23 and 0.24? Answer: 0.234946802 (√0.0552).
- Q3: Asks: 55 members each send card to all others — total? Answer: 2970 (55×54).
- Q4: Asks: average of 1 to 67? Answer: 34.
- Q5: Asks: two trains cross man in 27 s and 17 s, cross each other in 23 s — speed ratio? Answer: 3:2. Why: 27x+17y=23(x+y).
- Q6: Asks: 20% of x = y; y% of 20 in terms of x? Answer: 4% of x.
- Q7: Asks: man walks 6 km/h, crosses bridge in 15 min — bridge length? Answer: 1500 m.
- Q8: Asks: P 20d, Q 30d, R 60d; P assisted by Q,R every third day — days? Answer: 15. Why: 3-day cycle = 1/5 job.
- Q9: Asks: book sold Rs.450 at 10% loss — CP and SP for 10% gain? Answer: 500, 550.
- Q10: Asks: LCM of 25, 35, 55? Answer: 1925.
- Q11: Asks: 5 green, 7 red; two drawn, P(green then red)? Answer: 35/132.
- Q12: Asks: pq=24, p²+q²=52 — p? Answer: 6 or 4. Why: p+q=10, roots of t²−10t+24.
- Q13: Asks: SI — x for 7 yrs at 8.8%, total 404000 — x? Answer: 2,50,000.
- Q14: Asks: divide Rs.981 in 5:4? Answer: 545:436.
- Q15: Asks: arrangements of DANGER with no vowel in odd positions? Answer: 144. Why: ³P₂×4!.
- Q16: Asks: average of 7 consecutive numbers is 20 — largest? Answer: 23.
- Q17: Asks: train passes platform in 36 s, man in 20 s, speed 54 km/h — platform length? Answer: 240 m. Why: train 300 m; (P+300)/36=15.
- Q18: Asks: votes 1000, 5000, 10000 — winner's %? Answer: 62.5%.
- Q19: Asks: A reaches 16h after meeting, B 25h; A speed 25 — B's speed? Answer: 20. Why: 25×√(16/25).
- Q20: Asks: Ankit 6d, Bishal 8d, with Dinesh done in 3 days, Rs.4800 — Dinesh's pay? Answer: Rs.600. Why: Dinesh's share 1/8.

## Easy Quant-3 (20 questions)
- Q1: Asks: merchant sells 30 m cloth, gains SP of 10 m — gain %? Answer: 50%. Why: 10/20.
- Q2: Asks: HCF of 22 and 33? Answer: 11.
- Q3: Asks: P(sum 7) two dice? Answer: 1/6.
- Q4: Asks: simplify 4/(1+2/(5+2/(3+5/7)))? Answer: 144/49.
- Q5: Asks: SI — x for 11 yrs at 12.2%, amount 1826760 — x? Answer: 7,80,000.
- Q6: Asks: 50p/25p/10p in 2:5:3, total Rs.510 — each count? Answer: 400, 1000, 600. Why: x=200.
- Q7: Asks: sum of all 4-digit numbers from 1,3,5,7,9 (no repetition)? Answer: 666600. Why: 24×25×1111.
- Q8: Asks: avg of 10 numbers is 23; each +4 — new avg? Answer: 27.
- Q9: Asks: 240 m train passes pole in 24 s — time for 650 m platform? Answer: 89 s. Why: 10 m/s; 890/10.
- Q10: Asks: trains opposite at 60/90 km/h, lengths 1.10/0.90 km — crossing time? Answer: 48 s. Why: 2 km/150 km/h.
- Q11: Asks: price −25% then +20% — net? Answer: 10% decrease. Why: 0.75×1.2=0.9.
- Q12: Asks: buses P→Q and Q→P reach 4h and 16h after crossing — speed ratio? Answer: 2:1. Why: √(16/4).
- Q13: Asks: Vicky does job in 45/2 days — part in 2 days? Answer: 4/45.
- Q14: Asks: SP of 10 candles = CP of 12 — gain %? Answer: 20%.
- Q15: Asks: HCF 20, LCM's other factors 10 and 12 — greater number? Answer: 240.
- Q16: Asks: P(honor card) from deck? Answer: 4/13 (16/52).
- Q17: Asks: X+Y=174, X is half of Y — X? Answer: 58.
- Q18: Asks: SI — x for 8 yrs at 9%, amount 26,00,640 — x? Answer: 15,12,000.
- Q19: Asks: sugar solution:colored water 4:3; add 10 L colored → 4:5 — initial sugar solution? Answer: 20 L. Why: k=5.
- Q20: Asks: nPr=3024, nCr=126 — n and r? Answer: 9, 4. Why: r!=24.

## Easy Quant-4 (20 questions)
- Q1: Asks: rectangles (excl. squares) and squares in 8×8 chessboard? Answer: 1092, 204. Why: total 1296 − 204.
- Q2: Asks: avg of 50 numbers is 20; discard 37 and 43 — new avg? Answer: 19.17. Why: 920/48.
- Q3: Asks: jogger 9 km/h, 240 m ahead of 120 m train engine (same dir) — time to pass him? Answer: 36 s.
- Q4: Asks: washing machine depreciates 10% yearly — present value? Answer: Rs.12000.
- Q5: Asks: towns P,Q 275 km apart; motorcycle from P at 8 am — crossing time? Answer: 2:30 p.m.
- Q6: Asks: Karan does 1/15 part in 1 day — days for full job? Answer: 15.
- Q7: Asks: SP of 40 apples = CP of 35 — gain/loss %? Answer: loss of 12.5%. Why: 5/40.
- Q8: Asks: (as stated) HCF of 6,12,18 is 24 — LCM? Answer: 54. Why: (6×12×18)/24.
- Q9: Asks: (x²+y²)³=(x³+y³)², xy≠0 — x/y+y/x? Answer: 2/3.
- Q10: Asks: SI — x for 17 yrs at 33%, amount 45,00,088 — x? Answer: 6,80,800.
- Q11: Asks: A invests 1 lakh, B 2 lakhs — profit shares? Answer: Rs.10,000 and Rs.20,000 (1:2 of 30,000).
- Q12: Asks: A 70,000; B joins with 60,000 after n months; profit ratio 2:1 — B joined when? Answer: 5 months. Why: (70000×12)/(60000×(12−n))=2.
- Q13: Asks: 20 points, 5 collinear — triangles? Answer: 1130. Why: C(20,3)−C(5,3).
- Q14: Asks: avg of first six multiples of 4? Answer: 14.
- Q15: Asks: 270 m train at 120 km/h crosses opposite train — other train's length? Answer: 230 m.
- Q16: Asks: goods train 72 km/h crosses 250 m platform in 26 s — train length? Answer: 270 m.
- Q17: Asks: pass 55%; gets 120, fails by 78 — max marks? Answer: 360. Why: 198/0.55.
- Q18: Asks: aeroplane 200 km segments @ 200/400/600/800 km/h — avg speed over 1000 km? Answer: 480 km/h. Why: 1000/(25/12). Note: platform divides stated 1000 km by segment times though segments sum to 800 km.
- Q19: Asks: 20 people, 20 toys, 15 days @ 10 h/day; 25 persons, 30 toys @ 20 h/day — days? Answer: 9.
- Q20: Asks: difference between 3¾ and its reciprocal? Answer: 209/60. Why: 15/4−4/15.

## Easy Reasoning-1 (20 questions)
- Q1: Asks: vowels preceded by symbol in "A*59IN&E@#U1&"? Answer: 2 (E after &, U after #).
- Q2: Asks: 2nd left of 6th from right in series? Answer: N.
- Q3: Asks: hour-hand rotation 8 am→2 pm? Answer: 180°. Why: 6×30°.
- Q4: Asks: SAND→UCPF; code STONE? Answer: UVQPG (+2 each).
- Q5: Asks: "He is the son of the only son of my mother" — relation to Suresh? Answer: Father (Suresh's son).
- Q6: Asks: Joe walks N 15, left 10, right 10, right 30 — direction from start? Answer: North-East (25N, 20E).
- Q7: Asks: water-image of given combination? Answer: 4th option (image).
- Q8: Asks: some actors are singers; all singers are dancers — conclusions? Answer: only (1) follows ("some actors are dancers").
- Q9: Asks: all harmoniums are instruments; all instruments are flutes — conclusions? Answer: only (2) follows ("all harmoniums are flutes").
- Q10: Asks: seating (B 2nd left, C next, D right of C, A rightmost, E/A neighbours of F) — between C and E? Answer: D.
- Q11: Asks: same seating — E's position? Answer: 5th from left.
- Q12: Asks: missing term in 3×4 grid? Answer: 16. Why: (8+19)−x=11.
- Q13: Asks: Ram 7th left, Shyam 12th right; after swap Ram 22nd left — total? Answer: 33. Why: 22+12−1.
- Q14: Asks: table — profit % on article 1 (CP 12500, MP 15000, 10% off)? Answer: 8%. Why: SP 13500.
- Q15: Asks: table — avg of m and q (SPs articles 1 and 5)? Answer: 14070. Why: (13500+14640)/2.
- Q16: Asks: data sufficiency — Rock's gym rank? Answer: only I and either II or III.
- Q17: Asks: data sufficiency — tallest among six? Answer: only II and III (Tia tallest).
- Q18: Asks: next in ABDEFHIJLMNPQRT? Answer: UVX. Why: skip C,G,K,O,S,W.
- Q19: Asks: missing in ACE?MOQSUW? Answer: GIK.
- Q20: Asks: LION→MNHK; code MONKEY? Answer: XDJMNL. Why: reverse then −1.

## Easy Reasoning-2 (20 questions)
- Q1: Asks: which expression shows P is maternal uncle of Q? Answer: P − M + N × Q.
- Q2: Asks: Morris faces N, walks 10 km, 270° ACW, 15 km, 45° CW, 25 km — direction faced? Answer: South-East.
- Q3: Asks: water-image of given combination? Answer: 2nd option (image).
- Q4: Asks: water-image of given combination? Answer: 3rd option (image).
- Q5: Asks: some mangoes are yellow; some tixo are mangoes — conclusions? Answer: neither follows.
- Q6: Asks: two parallel lines of 5 men/5 women — extreme ends? Answer: Ajit, Chirag.
- Q7: Asks: same seating — opposite Octavia? Answer: Ejaz.
- Q8: Asks: same seating — right corner of women's line? Answer: Neelu.
- Q9: Asks: missing value in figure? Answer: 26.
- Q10: Asks: Sujay 14th of 25; 3 added at bottom — rank from top? Answer: 14.
- Q11: Asks: table — avg height boys and girls? Answer: 145.625. Why: (140.25+151)/2.
- Q12: Asks: data sufficiency — colour of the Sky? Answer: C (either I or II alone; sky = blue = white).
- Q13: Asks: data sufficiency — code for 'aayam'? Answer: A (I alone).
- Q14: Asks: 435 224 786 823 902; digits ascending — which becomes largest? Answer: 786 → 678.
- Q15: Asks: same series — least digit-product? Answer: 902 (9×0×2=0).
- Q16: Asks: hour-hand rotation noon→5:10? Answer: 155°. Why: 31/6×30.
- Q17: Asks: CODE→DPEF; code DEFENCE? Answer: EFGFODF (+1 each).
- Q18: Asks: A brother of B; B sister of C; C father of D — D's relation to A? Answer: cannot be determined (D's gender unknown).
- Q19: Asks: Joe faces S, 45° ACW, 180° ACW, 270° CW — direction faced? Answer: South West. Why: net +45° CW from S.
- Q20: Asks: water-image of "A1M3b"? Answer: 3rd option (image).

Note: Quant-4 Q18 — four 200-km segments sum to 800 km, but platform divides stated 1000 km by segment times → 480 km/h.
