# Quiz Batch 5 — Section 10 web mocks + Section 11 cloud/security (8 quizzes, 160 questions)

Extracted 2026-10-14 via submit-unanswered → View Solution.
Per-question: Asks (paraphrased intent) / Answer (correct) / Why (gist).

## [Updated Pattern (Practice Set)] > Web Mock-1 (20 questions)
- Q1: Asks: which color has equal RGB amounts? Answer: All of the above (white, gray, black). Why: 255/255/255, 128/128/128, 0/0/0.
- Q2: Asks: valid way(s) to add CSS? Answer: All — Inline, External, Internal.
- Q3: Asks: CSS property for text color? Answer: color.
- Q4: Asks: output of JS object with duplicate key (first:20, second:30, first:50)? Answer: {first: 50, second: 30}. Why: last occurrence wins.
- Q5: Asks: which is NOT an HTML vs XHTML difference? Answer: "Charset in both is 'text/html'". Why: real diffs = case sensitivity, escaping special chars.
- Q6: Asks: correct JS alert syntax for "Hello World"? Answer: alert('Hello World');
- Q7: Asks: what does JS "undefined" represent? Answer: unassigned (declared, no value).
- Q8: Asks: what is <select> for? Answer: creates a combo box (drop-down).
- Q9: Asks: which of <div>, <p>, <h1> are block-level? Answer: all.
- Q10: Asks: selector targeting element by id? Answer: #id.
- Q11: Asks: how to select class "example"? Answer: .example.
- Q12: Asks: output — NaN's type (Object/Number/String/None)? Answer: Number.
- Q13: Asks: what is DOM? Answer: convention for representing/interacting with objects in HTML docs.
- Q14: Asks: HTML5 element highlighting text? Answer: <mark>.
- Q15: Asks: JS operator checking value + type? Answer: ===.
- Q16: Asks: output of let x='Hello', y='World', x+' '+y? Answer: "Hello World".
- Q17: Asks: how to define a JS function? Answer: function myFunc() {}.
- Q18: Asks: what is an empty HTML tag? Answer: needs no closing tag.
- Q19: Asks: property changing text font? Answer: font-family.
- Q20: Asks: what's wrong in ".class { color: blue; font-weight; bold; }"? Answer: syntax error — should be font-weight: bold;.

## [Updated Pattern (Practice Set)] > Web Mock-2 (20 questions)
- Q1: Asks: CSS Box Model components? Answer: Content, Padding, Border, Margin.
- Q2: Asks: CSS property for outer space around element? Answer: Margin.
- Q3: Asks: output of snippet (8/7/0/1)? Answer: 7.
- Q4: Asks: output when JS fn called with numbers instead of single object? Answer: undefined undefined undefined. Why: destructuring fails.
- Q5: Asks: result of rotating array right by N? Answer: [111, 44, 1, 22]. Why: 5 rotations on length-4 = 1 rotation.
- Q6: Asks: HTML is a subset of ___? Answer: SGML.
- Q7: Asks: which HTML makes an image clickable? Answer: <a href="..."><img src="..."/></a>.
- Q8: Asks: element for short quotes? Answer: <q> (<em>=emphasis; <blockquote>=long quotes).
- Q9: Asks: output of snippet pushing into array (3/4/5/Error)? Answer: 4. Why: push → length 3→4.
- Q10: Asks: what's wrong with power/exponent function? Answer: doesn't handle missing exponent.
- Q11: Asks: property letting image link show text label? Answer: alt.
- Q12: Asks: how is black represented in RGB? Answer: RGB(0, 0, 0).
- Q13: Asks: default BORDER attribute value? Answer: 1pixel.
- Q14: Asks: types of unordered lists? Answer: circle, square, disc.
- Q15: Asks: which objects store client-side data (localStorage/sessionStorage)? Answer: both window.localStorage and window.sessionStorage.
- Q16: Asks: what does Alpha in RGBA represent? Answer: opacity.
- Q17: Asks: Alpha 0.0 = ? Answer: fully transparent (1.0 = opaque).
- Q18: Asks: how does "margin: auto;" affect element? Answer: centers horizontally.
- Q19: Asks: output of Math.max()/Math.min() with no args? Answer: -Infinity Infinity.
- Q20: Asks: output of snippet mixing numbers, strings, objects? Answer: 11 Hello6 [object Object]6.

## [Updated Pattern (Practice Set)] > Web Mock-3 (20 questions)
- Q1: Asks: what does <address> do in HTML5? Answer: contains author's contact details.
- Q2: Asks: width 100px + padding 15px + border 5px, box-sizing content-box — total? Answer: 140px. Why: 100+30+10.
- Q3: Asks: issue with div {width:100%; padding:20px;} without border-box? Answer: div wider than parent (padding adds to width).
- Q4: Asks: output of snippet using ...args rest (NaN/Number/Object/Array)? Answer: Object. Why: array's typeof is "object".
- Q5: Asks: output of snippet with true in arithmetic (3/0/Error/5)? Answer: 5. Why: true=1.
- Q6: Asks: how to find array length in JS? Answer: array.length.
- Q7: Asks: how to check if variable is an array? Answer: Array.isArray(variable).
- Q8: Asks: output transforming [10,20,30,40] (options [1,2,3,4]/...)? Answer: [1, 2, 3, 4].
- Q9: Asks: let numbers=[1,2,3]; numbers[10]=11; length? Answer: 11.
- Q10: Asks: output of snippet (44/8/4/Error)? Answer: 44.
- Q11: Asks: CSS property letting flex item expand proportionally? Answer: flex-grow.
- Q12: Asks: what does box-shadow do? Answer: adds shadow outside element border.
- Q13: Asks: correct web address syntax? Answer: scheme://prefix.domain:port/path/filename.
- Q14: Asks: non-essential attribute under <iframe>? Answer: frameborder.
- Q15: Asks: property aligning flex item center on main axis? Answer: justify-content: center.
- Q16: Asks: output of snippet ("4 10 18"/"1 2 3"/"1 4 7"/None)? Answer: 4 10 18.
- Q17: Asks: output ("1 2 3 4"/"2 3 4 1"/"2 4 3 1"/"4 3 2 1")? Answer: 2 4 3 1.
- Q18: Asks: how to create a new JS object? Answer: both Object.create() and new Object().
- Q19: Asks: obj1={a:1}, obj2={a:1}; obj1===obj2? Answer: false.
- Q20: Asks: which position value positions element relative to nearest positioned ancestor? Answer: absolute.

## [Security & MS Office] > Security and Cloud Mock-4 (20 questions)
- Q1: Asks: main advantage of quantum computing in cloud? Answer: high processing power for complex computations.
- Q2: Asks: how does edge complement cloud? Answer: processing data closer to source (lower latency).
- Q3: Asks: key benefit of serverless? Answer: no server management.
- Q4: Asks: highest degree of cloud integration? Answer: SaaS.
- Q5: Asks: which monitors cloud performance in real time? Answer: CloudSensors.
- Q6: Asks: GAE stands for? Answer: Google Apps Engine.
- Q7: Asks: correct IaaS provider? Answer: EC2.
- Q8: Asks: repeatable task within business process = ___? Answer: service.
- Q9: Asks: Google's payment processing system? Answer: checkout.
- Q10: Asks: which provider relies on VM tech to deliver servers? Answer: IaaS.
- Q11: Asks: Hadoop data node IP/hostname changes — namenode must? Answer: need not update file-name→block-name mapping.
- Q12: Asks: company specializing in cloud management tools? Answer: RightScale.
- Q13: Asks: cloud app intermittent downtime — monitor which metric? Answer: Latency.
- Q14: Asks: challenge of multi-cloud monitoring? Answer: inconsistent metrics across providers.
- Q15: Asks: longer-than-expected recovery after cloud disaster — cause? Answer: lack of automated failover.
- Q16: Asks: best business-continuity strategy for regional outage? Answer: data replication across regions.
- Q17: Asks: scalable cloud app DB connection issues under load — cause? Answer: database throttling.
- Q18: Asks: cloud app perf issues from traffic spike — solution? Answer: auto-scaling.
- Q19: Asks: major challenge scaling stateful cloud app? Answer: managing session state.
- Q20: Asks: company needs local data residency — solution? Answer: use local cloud data center.

## [Security & MS Office] > Security and Cloud Mock-3 (20 questions)
- Q1: Asks: essential cloud element per CSA? Answer: Multi-tenancy.
- Q2: Asks: wrong cloud-security statement? Answer: "Cloud computing doesn't have vulnerabilities associated with Internet applications".
- Q3: Asks: flowchart evaluates ___ in any cloud? Answer: risk.
- Q4: Asks: which services must be negotiated in SLAs? Answer: all (logging, auditing, regulatory compliance).
- Q5/Q10: Asks: purpose of CSPM? Answer: assessing/maintaining security configurations in cloud.
- Q6: Asks: primary purpose of Cloud Security Access Broker? Answer: enforcing security policies in cloud services.
- Q7: Asks: term for cloud measure monitoring/controlling user access? Answer: RBAC.
- Q8: Asks: service model providing runtime for event-driven code? Answer: FaaS.
- Q9: Asks: term for attack flooding network with traffic? Answer: DDoS.
- Q11: Asks: deployment model using on-premise + cloud? Answer: Hybrid cloud.
- Q12: Asks: purpose of cloud SIEM? Answer: monitoring/analyzing security events.
- Q13: Asks: term for security measure creating backups? Answer: Data redundancy.
- Q14: Asks: which cloud model not trusted security-wise? Answer: Public.
- Q15: Asks: for which model may security boundary include vendor software? Answer: PaaS.
- Q16: Asks: post-migration app slower — likely cause? Answer: misconfigured network settings.
- Q17: Asks: extended downtime during cloud migration — cause? Answer: incomplete data migration.
- Q18: Asks: migration strategy redesigning app for cloud? Answer: Re-factoring.
- Q19: Asks: primary challenge migrating legacy systems? Answer: application compatibility.
- Q20: Asks: edge app high latency — cause? Answer: insufficient edge resources.

## [Security & MS Office] > Security and Cloud Mock-2 (20 questions)
- Q1: Asks: command listing running Docker containers? Answer: docker ps.
- Q2: Asks: likely cause of slow cloud VM? Answer: insufficient CPU allocation.
- Q3: Asks: containerized app can't reach host network — cause? Answer: misconfigured network bridge.
- Q4: Asks: Microsoft security accounts per client? Answer: 5.
- Q5: Asks: which provides token service for validated resource access? Answer: OAuth.
- Q6: Asks: term for securing data as unreadable code? Answer: Encryption.
- Q7: Asks: auth combining something known + something else? Answer: MFA.
- Q8: Asks: during which migration phase is security most critical? Answer: all (discovery, migration, operations).
- Q9: Asks: VM resource contention — solution? Answer: optimize VM resource allocation.
- Q10: Asks: example of object storage? Answer: Amazon S3.
- Q11: Asks: best cloud storage for frequently accessed data? Answer: Object storage.
- Q12: Asks: common block storage use case? Answer: databases and boot volumes.
- Q13: Asks: repeatable task within business process = ___? Answer: service.
- Q14: Asks: wrong cloud-protocol statement? Answer: none (all correct).
- Q15: Asks: action providing wrapper for metadata + operational instructions? Answer: HEAD.
- Q16: Asks: primary goal of DDoS in cloud context? Answer: disrupting service availability.
- Q17: Asks: attack tricking user into revealing sensitive info? Answer: Phishing.
- Q18: Asks: term for cloud model allocating resources dynamically on demand? Answer: Elasticity.
- Q19: Asks: measure monitoring/controlling traffic between VMs? Answer: Microsegmentation.
- Q20: Asks: user can't access S3 file — likely cause? Answer: incorrect bucket permissions.

## [Security & MS Office] > Cloud SB Mock-1 (20 questions, scenario-based)
- Q1: Asks: most secure cloud for single org? Answer: Private Cloud.
- Q2: Asks: what enables secure hybrid connectivity? Answer: VPN (encrypted tunnel).
- Q3: Asks: architecture for near-zero latency global content + dynamic scaling (streaming)? Answer: Edge Caching & Serverless.
- Q4: Asks: migration pattern for zero-downtime DB schema change on Kubernetes? Answer: Strangler Fig Pattern.
- Q5: Asks: local processing paradigm for IoT with intermittent connectivity? Answer: Edge Computing.
- Q6: Asks: lift-and-shift banking app without code changes = ? Answer: Re-Hosting.
- Q7: Asks: VM degraded at peak, CPU fine, network I/O maxed — cause? Answer: network throttling/bandwidth cap.
- Q8: Asks: best deployment for game logic closest to remote users? Answer: Edge Computing/Local Zones.
- Q9: Asks: governance solution for cloud sprawl? Answer: cloud resource tagging and policy.
- Q10: Asks: most cost-effective storage for 7-year rarely-accessed audit logs? Answer: archival storage (Glacier).
- Q11: Asks: offload OS/DB patching burden — which model? Answer: PaaS.
- Q12: Asks: high-perf low-latency block storage for VM? Answer: EBS.
- Q13: Asks: optimal decoupled async comms among 50 microservices? Answer: message queue/broker (SQS, RabbitMQ).
- Q14: Asks: funding model replacing on-prem CapEx with cloud? Answer: Reserved Instances.
- Q15: Asks: best mitigation for botnet hitting API gateway? Answer: WAF (Layer 7).
- Q16: Asks: reduce hybrid latency (on-prem DB over VPN)? Answer: Direct Connect/ExpressRoute.
- Q17: Asks: proof that not even cloud admins can view data? Answer: Customer Managed Keys (CMK).
- Q18: Asks: Kubernetes security for automated breach response to running-container attack? Answer: runtime security enforcement (seccomp/AppArmor/Falco).
- Q19: Asks: eliminate config drift across Dev/Staging/Prod? Answer: Infrastructure as Code.
- Q20: Asks: ensure German customer data never leaves EU? Answer: data sovereignty and residency policy.

## [Security & MS Office] > Cloud SB Mock-2 (20 questions, scenario-based)
- Q1: Asks: optimal data store for real-time bidding (extreme latency)? Answer: in-memory data store.
- Q2: Asks: best tech for multi-cloud portability (AWS+Azure)? Answer: Kubernetes/containerization.
- Q3: Asks: proactive control enforcing policy before new cloud services deploy? Answer: policy-as-code engine.
- Q4: Asks: load balancer config to maintain sessions? Answer: sticky sessions/affinity.
- Q5: Asks: DB component for lift-and-shifted app opening/closing connections at peak? Answer: database proxy/connection pooler.
- Q6: Asks: serverless fn slow after inactivity in low-traffic env? Answer: cold start latency.
- Q7: Asks: Kubernetes rolling update fails new Docker image (memory exceeded)? Answer: resource limit (OOM-kill).
- Q8: Asks: SSO with existing corporate credentials in cloud? Answer: federation/identity provider (SAML/OIDC/OAuth).
- Q9: Asks: DR component — backup copy in distant region? Answer: geographic redundancy.
- Q10: Asks: VPC feature enforcing private-only access to object storage? Answer: VPC endpoint/service link.
- Q11: Asks: resource type for non-urgent monthly background task? Answer: async queue processing.
- Q12: Asks: practice for end-to-end perf visibility, bottleneck unknown? Answer: APM (distributed tracing).
- Q13: Asks: tool predicting next quarter's cloud bill? Answer: budget/forecasting tool.
- Q14: Asks: principle violated by permanent high-level perms for temp task? Answer: short-lived credentials (marked answer; explanation truncated).
- Q15: Asks: force worldwide users to see updated image (CDN cached old)? Answer: cache invalidation.
- Q16: Asks: durable log storage from volatile K8s pods? Answer: Persistent Volume Claim.
- Q17: Asks: pattern coordinating multiple serverless actions from one event (fan-out)? Answer: event bus/broker.
- Q18: Asks: protect backend API from exhaustion at peak? Answer: rate limiting.
- Q19: Asks: auto-scaling for predictable Monday 9 AM spikes? Answer: scheduled scaling.
- Q20: Asks: service mesh component enforcing cross-region header-level security? Answer: sidecar proxy policy (Envoy).

Note: Cloud SB Mock-2 Q14's marked answer ("Short-lived Credentials") sits oddly vs its truncated explanation — reported as the platform shows it.
