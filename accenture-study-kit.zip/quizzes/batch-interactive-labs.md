# Interactive Batch — Section 13 coding labs (10 items)

Inspected 2026-10-14, read-only (no code run/submitted). None of the 10 items has an official Solution/Answer tab; approaches below are key solutions with short canonical code; community solutions exist in discussion comments. Problem intents paraphrased.

1. "Web Compiler Link" (link) — not a question. Embedded OneCompiler web IDE (HTML/CSS/JS live preview). Purpose: free compiler link for practice. No problem, no solution.

2. "SQL - 1" (article) — E-Commerce DB scenario (customers, orders, order_items with sample rows). Intent: list New York customers who bought more than 1 product in total across all orders, showing customer name, total spending, distinct-product count. Key approach: join three tables, filter city='New York', GROUP BY customer, HAVING SUM(quantity) > 1.
```sql
SELECT c.customer_name,
       SUM(oi.quantity * oi.price) AS total_spending,
       COUNT(DISTINCT oi.product_name) AS distinct_products
FROM customers c
JOIN orders o ON c.customer_id = o.customer_id
JOIN order_items oi ON o.order_id = oi.order_id
WHERE c.city = 'New York'
GROUP BY c.customer_id, c.customer_name
HAVING SUM(oi.quantity) > 1;
```

3. "Coding Mock Test - 14" (code exercise) — Story: Detective Reva's suspect hideouts numbered; only prime-numbered addresses suspicious. Intent: read limits L and R, print all primes between them inclusive; print "No primes found" if none. Sample: 10..20 → 11, 13, 17, 19. Key approach: trial-division primality per number in [L, R].
```python
def is_prime(n):
    if n < 2:
        return False
    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:
            return False
    return True
L, R = int(input()), int(input())
primes = [x for x in range(L, R + 1) if is_prime(x)]
print(", ".join(map(str, primes)) if primes else "No primes found")
```

4. "Web Based" (article) — Screenshot of Mercer/Mettl-style web task: build/fix a chatbot widget. Objectives: (a) make the welcome message a bot message (add `bot-message` class); (b) user chat color #cfe2ff; (c) bot responds to every user input. Constraint: don't modify id/class attributes. Key fixes: add `bot-message` class to welcome div; CSS `.user-message { background-color: #cfe2ff; }`; in sendMessage(), append automated bot reply (e.g., via setTimeout) after each user message.

5. "SQL Query 2" (article) — Employees table (EMP_ID, NAME, DEPARTMENT, SALARY; 7 rows). Intent: name and salary of the highest-paid employee(s) per department. Expected: Alice/HR 50000; Frank/IT 72000; Eva/Finance 60000. Key approach: MAX(salary) per department subquery, join back on department + salary.
```sql
SELECT e.name, e.salary
FROM Employees e
JOIN (SELECT department, MAX(salary) AS max_sal
      FROM Employees GROUP BY department) m
  ON e.department = m.department AND e.salary = m.max_sal;
```

6. "Coding Mock Test - 15" (code exercise) — Story: year 3025, spaceship "Voyager Armstrong" scans asteroids; Armstrong-numbered IDs are safe zones. Intent: check if a number is an Armstrong number; else print "Not an Armstrong Number". Sample: 153 → Armstrong Number. Key approach: count digits d, sum each digit^d, compare.
```python
n = int(input())
d = len(str(n))
total = sum(int(x) ** d for x in str(n))
print("Armstrong Number" if total == n else "Not an Armstrong Number")
```

7. "Coding Mock - 3" (article) — Screenshot of Mettl-style web task: enhance interactive product rating interface. Objectives: (a) add five star icons (class "star") in rating-stars div; (b) style `filled` class gold (#ffd700); (c) implement setRating() updating star display on click. Constraints: don't modify class names/IDs; use Font Awesome "fa-star"; rating updates immediately. Key fixes: five `<i class="fa fa-star star" onclick="setRating(n)">`; CSS `.filled { color: #ffd700; }`; setRating() toggles 'filled' for indices below clicked rating.

8. "SQL Query 1" (article) — Employees (John/10/60000, Alice/10/80000, Bob/20/70000, Mike/20/40000, Carol/30/90000) and Departments (10/HR, 20/IT, 30/Finance). Intent: department names whose average salary exceeds the overall average. Expected: HR and Finance (70000, 90000 vs 68000). Key approach: GROUP BY department, HAVING AVG(salary) > (SELECT AVG(salary) FROM employees).
```sql
SELECT d.department_name
FROM departments d
JOIN employees e ON e.department_id = d.department_id
GROUP BY d.department_name
HAVING AVG(e.salary) > (SELECT AVG(salary) FROM employees);
```

9. "Coding Mock Test - 16" (code exercise) — Story: Spell Bee Championship; score = vowel count in the word. Intent: count vowels (a,e,i,o,u) in a lowercase English word. Sample: "education" → 5. Key approach: count character membership in "aeiou".
```python
word = input().strip()
print(sum(1 for ch in word if ch in "aeiou"))
```

10. "Web Based Question" (article) — Screenshot of Mettl-style web task: finalize partially complete iPod interface. Objectives: (a) add "Next" button; (b) iPod color pink; (c) clicking a button displays its action text on screen. Constraints: don't modify id/class attributes; apply provided CSS correctly. Key fixes: Next button wired to action handler; iPod body background pink; button-click handler (displayAction/showAction) writing action text into screen element.

Side effects: none — read-only; nothing submitted, run, created, or changed.
