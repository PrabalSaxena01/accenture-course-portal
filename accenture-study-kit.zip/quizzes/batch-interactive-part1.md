# Interactive Batch — embedded quiz sets + communication apps (part 1)

Extracted 2026-10-14 from embedded practice quizzes (instant-feedback reveal, user-approved).
Per-question: Asks (paraphrased intent) / Answer (correct) / Why (gist).
Source quiz item titles verified on platform.

## [Accenture Full Paper (Most Recent)] > "Accenture Full Paper (Exact With Solution)" (45 questions)
Embedded "Accenture Technical Assessment Practice Quiz" (instant feedback). Explanations only for Q1,2,33,34,37,38.
- Q1: Asks: output when button handler writes its onclick attribute? Answer: C ("myFunction(this);"). Why: getAttribute returns the literal string.
- Q2: Asks: map +5 over [3,16,2,18]? Answer: B ("8, 21, 7, 23").
- Q3: Asks: HTML tag for collapsible details? Answer: B ("<details></details>").
- Q4: Asks: CSS3 for pictured rounded square? Answer: B ("border-radius: 20px 0 20px 0; ...").
- Q5: Asks: Java Animal/Dog inheritance setup? Answer: A ("class Dog extends Animal ...").
- Q6: Asks: which is NOT a disadvantage of firewall+web-filter? Answer: B (trust relationship; compromise of one affects the other).
- Q7: Asks: Car class vs myCar object? Answer: A (Car is the class, myCar an instance).
- Q8: Asks: polymorphism in TeaMac overloads? Answer: A (static polymorphism).
- Q9: Asks: HTTP status for missing endpoint? Answer: B (404).
- Q10: Asks: API versioning for breaking changes? Answer: C (version in URL path).
- Q11: Asks: DevOps block storing versioned binaries? Answer: C (artifact management).
- Q12: Asks: Employee table primary key? Answer: C (EmployeeID).
- Q13: Asks: concurrency issue, updates overwriting? Answer: B (lost update).
- Q14: Asks: first step for container latency? Answer: B (analyze network traffic and logs).
- Q15: Asks: purpose of network segmentation? Answer: B (limiting spread of attacks).
- Q16: Asks: tunnel-mode encryption+integrity protocol? Answer: C (ESP).
- Q17: Asks: VPN for remote employee? Answer: A (remote-access VPN).
- Q18: Asks: fast connectionless query-response protocol? Answer: C (DNS).
- Q19: Asks: OSI layer for reliable delivery? Answer: C (transport layer).
- Q20: Asks: single-device state-tracking firewall? Answer: A (stateful packet inspection).
- Q21: Asks: cloud use case for web office apps? Answer: C (SaaS).
- Q22: Asks: layer integrating old+new data sources? Answer: C (abstraction layer).
- Q23: Asks: most secure cloud model? Answer: B (private cloud).
- Q24: Asks: tech for multiple OSes on one machine? Answer: A (virtualization).
- Q25: Asks: cloud model with customer-chosen OS/network? Answer: C (IaaS).
- Q26: Asks: how pooling gives storage elasticity? Answer: C (global-scale, reliable, resilient storage).
- Q27: Asks: cause of substitution-cipher decryption data loss? Answer: B (decryption incorrectly uses encryption key). FLAG: learner comment disputes, claims duplicate mappings from key collision — unreliable.
- Q28: Asks: EAP with server-side certs only? Answer: D (PEAP).
- Q29: Asks: SQL counting 'm' in FirstandLastName? Answer: D (SELECT ... LENGTH−LENGTH(REPLACE(...,'m','')) FROM StudentDetails).
- Q30: Asks: SQL showing students without marks? Answer: C (LEFT JOIN StudentMark ON StudentId).
- Q31: Asks: pseudocode init ages, print 2nd element? Answer: C (PRINT ages[1], 0-based).
- Q32: Asks: which string prints "Valid" for [a-zA-Z0-9]{6}? Answer: A ("arun32").
- Q33: Asks: bitwise loop output (a=8,b=5,c=6)? Answer: D (65). Why: b→33→57; a+b=65.
- Q34: Asks: 2D-array bitwise output? Answer: B (4.0). Why: first AND=0, condition false, 10&1=0.
- Q35: Asks: what does recursive cal() compute? Answer: A (factorial).
- Q36: Asks: nested-if output (a=0,b=2,c=7)? Answer: B (9).
- Q37: Asks: bitwise/XOR output (p=4,q=8,r=6)? Answer: C (55). Why: q=23, r=28, sum=55.
- Q38: Asks: funn output (a=1,b=6,c=7)? Answer: A (14). Why: 16<7 false; returns 1+6+7.
- Q39: Asks: motherboard data/address/control pathway? Answer: B (system bus).
- Q40: Asks: device with cached device controllers? Answer: B (enhanced integrated drive electronics).
- Q41: Asks: key file-management function beyond create/delete? Answer: B (manage file permissions and access control).
- Q42: Asks: PowerPoint auto-highlight bullets one by one? Answer: C (By Paragraph animation).
- Q43: Asks: Word shortcut for today's date? Answer: A (Alt+Shift+D).
- Q44: Asks: INDEX/MATCH for max unit price? Answer: B (Laptop, price 850).
- Q45: Asks: OS feature to harden after breach? Answer: A (access control).

## [Full Technical Set (Pracitce)] > "Complete Set - Technical 1" (45 questions)
Embedded "Technical Assessment Practice Quiz - Set 2".
- Q1: Asks: diagnose abrupt microservice instances in flash sale? Answer: B (heap logs / memory allocation profiling). Why: profiling finds memory leaks.
- Q2: Asks: anomaly — concurrent txns read same balance differently? Answer: B (non-repeatable read).
- Q3: Asks: best PK for EHR patient records? Answer: C (MedicalRecordID).
- Q4: Asks: DevOps block automating SAST audits? Answer: A (continuous delivery pipeline quality gate).
- Q5: Asks: evolve REST API without breaking legacy? Answer: B (content negotiation via Accept headers). Why: legacy clients keep working.
- Q6: Asks: which is NOT a disadvantage of inline reverse-proxy WAF? Answer: C (intercepts/drops SQLi+XSS pre-app — that's the benefit).
- Q7: Asks: Book class vs myBook object? Answer: A (class vs instance).
- Q8: Asks: polymorphism of two executePayment methods? Answer: A (method overloading / compile-time).
- Q9: Asks: first step for slow DB endpoint? Answer: B (process lists, slow query logs, APM).
- Q10: Asks: API versioning /v1/, /v2/? Answer: B (explicit versioned endpoints).
- Q11: Asks: versioned store for build outputs? Answer: B (artifact repository).
- Q12: Asks: PK for Orders table? Answer: C (OrderID).
- Q13: Asks: anomaly — row re-read returns different data? Answer: B (non-repeatable read).
- Q14: Asks: first step for container high latency? Answer: B (analyze network traffic and logs).
- Q15: Asks: purpose of micro-segmentation? Answer: B (restrict lateral movement).
- Q16: Asks: IPsec tunnel encryption+integrity? Answer: B (ESP).
- Q17: Asks: VPN for engineer at public airport? Answer: A (remote-access VPN).
- Q18: Asks: protocol for real-time game traffic? Answer: B (UDP).
- Q19: Asks: OSI layer for IP addressing/routing? Answer: B (network layer / L3).
- Q20: Asks: firewall tracking TCP sessions? Answer: B (stateful packet inspection).
- Q21: Asks: cloud model for ready-to-use web CRM? Answer: C (SaaS).
- Q22: Asks: layer unifying mainframe+cloud data? Answer: C (data virtualization / abstraction layer).
- Q23: Asks: most secure cloud for classified data? Answer: B (private cloud).
- Q24: Asks: tech abstracting bare metal to vCPU/vRAM? Answer: A (hypervisor-based virtualization).
- Q25: Asks: cloud model with customer OS/network control? Answer: C (IaaS).
- Q26: Asks: resource pooling → storage elasticity? Answer: C (dynamic on-demand allocation from shared pool).
- Q27: Asks: why IoT substitution-cipher data garbled? Answer: B (key collisions in cipher mapping).
- Q28: Asks: 802.1X simplified client auth? Answer: B (PEAP).
- Q29: Asks: trace pseudocode (a=2,b=4,c=5)? Answer: B (12). Why: (2+5>5+2) false skipped; 11<11 false → else yields 12.
- Q30: Asks: final p+q+r (p=3,q=6,r=5)? Answer: B (41). Why: (3+5>6−3) true → q=17; XOR check → 41.
- Q31: Asks: evaluate funn(1,3,8)? Answer: A (12). Why: (12<4) false, skipped; returns 1+3+8.
- Q32: Asks: what does compute(5) return? Answer: A (120 = 5!).
- Q33: Asks: 2D-array bitwise output? Answer: A (5.0). Why: (1&2)&5=0; (2>5) false; recomputed → 5.0.
- Q34: Asks: loop pseudocode output (a=5,b=2)? Answer: A (31). Why: iter1 b→14; iter2 → 31.
- Q35: Asks: input matching ^[A-Z]{2}[0-9]{4}$? Answer: A ("AB1234").
- Q36: Asks: print 3rd element of scores (0-based)? Answer: B (PRINT scores[2]).
- Q37: Asks: SQL all employees + departments? Answer: C (LEFT JOIN — preserves all Employees rows).
- Q38: Asks: SQL letter-'e' frequency? Answer: B (LENGTH−LENGTH(REPLACE)).
- Q39: Asks: slot for graphics upgrade? Answer: A (PCIe).
- Q40: Asks: disk module with integrated flash controllers? Answer: B (EIDE).
- Q41: Asks: OS stopping background apps reading sensitive data? Answer: B (access control and file permission management).
- Q42: Asks: PowerPoint reveal nested bullets individually? Answer: B (By Paragraph animation).
- Q43: Asks: Word shortcut for current system time? Answer: A (Alt+Shift+T).
- Q44: Asks: INDEX/MATCH for MIN unit price? Answer: D (Cable, price 15).
- Q45: Asks: policy preventing privilege-escalation recurrence? Answer: A (user access control and least privilege).

## [Full Technical Set (Pracitce)] > "Complete Set - Technical 2" (44 questions)
Embedded "Accenture Technical Assessment Practice Quiz". FLAGS: learner comments report wrong options for Q32, Q33, Q37; confirmed Q32's options duplicate Q31's regex options and Q37's duplicate Q36's; Q32/Q37 marked answers contradict their explanations — marked UNRELIABLE, do not use.
- Q1: Asks: what does `this` pass to handler reading tagName? Answer: A ("button"). Why: HTMLButtonElement; tagName='BUTTON'.
- Q2: Asks: map divide-by-2 over [10,20,30]? Answer: B ("5, 10, 15").
- Q3: Asks: semantic tag for intro content? Answer: B ("<header>").
- Q4: Asks: CSS square→circle? Answer: A ("border-radius: 50%;").
- Q5: Asks: Java Vehicle/Bike inheritance? Answer: A ("class Bike extends Vehicle ...").
- Q6: Asks: NOT a disadvantage of inline WAF? Answer: C (drops SQLi+XSS pre-app — the benefit).
- Q7: Asks: Book class vs myBook? Answer: A (class vs instance).
- Q8: Asks: overloaded executePayment polymorphism? Answer: A (method overloading / compile-time).
- Q9: Asks: HTTP status for unauthenticated admin-endpoint call? Answer: A (401 Unauthorized).
- Q10: Asks: API evolution without breaking clients? Answer: B (/v1/, /v2/ versioned endpoints).
- Q11: Asks: versioned build-output store? Answer: B (artifact repository).
- Q12: Asks: Orders table PK? Answer: C (OrderID).
- Q13: Asks: row re-read anomaly? Answer: B (non-repeatable read).
- Q14: Asks: first step for slow DB query? Answer: B (process lists, slow query logs, APM).
- Q15: Asks: micro-segmentation purpose? Answer: B (restrict lateral movement).
- Q16: Asks: IPsec tunnel protocol? Answer: B (ESP).
- Q17: Asks: VPN for 50 branches? Answer: A (site-to-site VPN).
- Q18: Asks: low-latency game protocol? Answer: B (UDP).
- Q19: Asks: OSI IP addressing layer? Answer: B (network layer / L3).
- Q20: Asks: session-tracking firewall? Answer: B (stateful packet inspection).
- Q21: Asks: cloud model for VPCs/VMs? Answer: C (IaaS).
- Q22: Asks: most secure cloud for defense contractor? Answer: B (private cloud).
- Q23: Asks: hardware abstraction layer? Answer: A (hypervisor).
- Q24: Asks: customer responsibility "in" the cloud? Answer: C (OS patches on guest VMs).
- Q25: Asks: pooling → elasticity? Answer: B (dynamic reallocation from shared pool).
- Q26: Asks: why Caesar(+3) text garbled? Answer: B (double +6 shift; must shift back 3).
- Q27: Asks: 802.1X mutual-cert EAP? Answer: A (EAP-TLS).
- Q28: Asks: SQL count 'a' in LastName? Answer: B (LENGTH−LENGTH(REPLACE 'a')).
- Q29: Asks: SQL all departments incl. empty? Answer: B (Departments LEFT JOIN Employees).
- Q30: Asks: print 3rd element (0-based)? Answer: B (PRINT scores[2]).
- Q31: Asks: string matching 6-alphanumeric rule? Answer: B ("code12").
- Q32: Asks: bitwise loop final (x=6,y=10)? FLAG BROKEN — options duplicate Q31; quiz marks B ("code12") but explanation computes the loop. UNRELIABLE — do not use.
- Q33: Asks: 2D-array bitwise output? Answer: B (16). Why: (4&3)=0; (3>0) true → 16. (Learner-flagged but key+explanation coherent.)
- Q34: Asks: what does recursive sumSeries compute? Answer: B (sum 1..n).
- Q35: Asks: trace funn(2,4,5)? Answer: C (18). Why: (2+4<5) false → b=7; c=2+7=18.
- Q36: Asks: final p+q+r with XOR (3,6,4)? Answer: B (17). Why: 3^6=5>4 → p=7; 7+6+4=17.
- Q37: Asks: output of process(2,3,4)? FLAG BROKEN — options duplicate Q36; quiz marks B (17) but explanation computes 9. UNRELIABLE — do not use.
- Q38: Asks: motherboard CPU/memory/I-O pathway? Answer: A (system bus).
- Q39: Asks: fastest SSD interface? Answer: B (NVMe).
- Q40: Asks: OS file authorization mechanism? Answer: A (file system access control).
- Q41: Asks: PowerPoint sequential bullets? Answer: B (entrance animation + 'By Paragraph').
- Q42: Asks: Excel current-time shortcut? Answer: A (Ctrl+Shift+;).
- Q43: Asks: INDEX/MATCH for MAX sales? Answer: C (Smartphone, 450).
- Q44: Asks: secure admin-role principle? Answer: A (principle of least privilege).

## [Communicaiton] — PARTIAL (browser died during this section; resume needed)
Identified (no audio recorded; mic items not attempted):
- "Complete Set" article = "SpeakReady" app: Sec1 Read (13 sentences, 15s aloud); Sec2 Listen (10 sentences played once, 30s repeat); Sec3 Topic (4 topics, 30s prep + 60s speak); Sec4 Quiz (4 passages × 8 MCQs). Mic needed — not attempted.
- "Versant Practice" = 5 Versant-style mock tests (Professional Communication, Technology & Innovation, Health & Wellbeing, Environment & Sustainability, Education & Career) — not attempted.
- Unnamed article after "Speak on topic 2" = "Speak on Topic Practice" (4 topics, 30s prep + 60s auto-record) — mic, not attempted.
- Unnamed article after "Listen & Repeat 2" = "Listen & Repeat" (30 Qs; audio plays once, then record) — mic, not attempted.
- "Paragraph Answers" = "Listening Comprehension" app (8 paragraphs × 2 MCQs; Start Practice → Submit Answers per passage). Started Passage 1 (community-garden paragraph: Q1 main goal of converting vacant lots; Q2 funding for seeds/tools); clicked Submit Answers → renderer hung; answers NOT extracted.

STILL NEEDED: (a) grammar practice item (~30 Qs, option explanations) — NOT found; check unchecked articles "Practice - Voice, Speech", "Para Answers 2", "Speak on topic 2", "Listen & Repeat 2"; (b) 8 listening passages' topics + correct answers via the "Paragraph Answers" app (select one option per question, submit per passage, read the app's marking; "Para Answers 2" may be a duplicate app — check); (c) titles/purpose of those four unchecked articles (open only, no audio recording).
