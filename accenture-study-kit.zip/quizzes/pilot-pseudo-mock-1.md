# Quiz: Pseudo Mock-1 (Section 10 "Updated Pattern (Practice Set)" > Pseudocodes)

Submitted unanswered 2026-10-14. Score 0/20. Correct answers revealed via View Solution.
Per-question summaries (Asks = paraphrased intent, Answer = correct option, Why = gist).

- Q1: Asks output of recursive Java-style method funn(20,25,30) recursing funn(p−r,q,r−3) while p>1, then printing q. Answer: 25. Why: second call has p=−10, so p>1 fails; only q=25 prints once.
- Q2: Asks output of same print-after-recursion pattern starting fun(22,4,2). Answer: B ("14 12 10 8 6 4"). Why: recursion descends (p: 22→20→16→10→2→−8) until p≤1, then prints q unwinding in reverse.
- Q3: Asks output of recursive pseudocode fun(x), x=7: if x>3 calls fun(x−3), prints x, then fun(x/2), fun(x/4). Answer: C ("4 7"). Why: fun(7)→fun(4) prints 4, then fun(7) prints 7; calls with x≤3 print nothing.
- Q4: Asks output of recursive funn(108,3) recursing (x/3, y+3) while x>1, printing y after. Answer: "9 6 3". Why: descends x 108→36→6→0, prints y on unwind: 9, 6, 3.
- Q5: Asks output of recursive fun(p,q), p=18,q=3, recursing fun(p−3,q+3) while p>1, printing q. Answer: D ("18 15 12 9 6 3"). Why: descends until p≤1, prints q unwinding in reverse.
- Q6: Asks output of pseudocode a=10,b=20, for-loop (c from a to b step 2): a=a+c, b=b−a+c, print a if a>10 else b. Answer: A (20). Why: first iteration (c=10): a=20,b=10, prints 20; next c=12 > updated b=10, loop ends.
- Q7: Asks value printed by array pseudocode arr={2,3,3,4} with arithmetic/bitwise (^, &) updates + conditionals, printing arr[1]+arr[2]+arr[3]. Answer: 45. Why: arr[2]=(6+7)+4=17; (1+7+2)=10 < (7^3)=4 false → else arr[3]=17+3+3=23; (23+2)>(2−23) true → arr[3]=(10&8)+17=25; print 3+17+25=45.
- Q8: Asks output of pp=3,qq=6,rr=5 with bitwise & and ^ assignments + conditional, printing pp+qq+rr. Answer: 21. Why: rr=(6&3)^5=7 then (6&7)+6=12; (3^5)=6<6 false, if skipped; print 3+6+12=21.
- Q9: Asks output of a=1,b=8,c=7 with two ifs, printing a+b+c. Answer: 16. Why: (a>b) false and (c−a−b)=−2 > (b+c)=15 false; nothing changes; print 1+8+7=16.
- Q10: Asks output of p=8,q=5,r=10 with bitwise & in two conditional updates, printing p+q+r. Answer: 32. Why: (8&5)=0<10 true → q=10&10=10, p=9+10=19; (19+10)>(10−19) true → q=15&19=3; print 19+3+10=32.
- Q11: Asks output of nested-if pseudocode a=8,b=8,c=9 using ^, printing a+b+c. Answer: 42. Why: outer (3>8) false → else; inner (8^4)=12<(7+8)=15 true → b=16+9=25; print 8+25+9=42.
- Q12: Asks output of for-loop (r 2→4) with continue when (r^q)<q, updating q=1+r, p=1+q (p=0,q=6), printing p+q. Answer: 6. Why: (2^6)=4,(3^6)=5,(4^6)=2 all <6 → always continues; p,q unchanged; print 0+6=6.
- Q13: Asks return of funn(a,b,c), a=0,b=3,c=5, with c=(c^c)&b and conditional, returning a+b+c. Answer: 3. Why: (5^5)&3=0 → c=0; 9<0 false skips if; return 0+3+0=3.
- Q14: Asks output of for-loop (c 4→8) with continue when (a−c)>(c−a), updating a=(3+2)+c then a=a+a (a=9,b=4), printing a+b. Answer: 13. Why: (a−c)>0 vs (c−a)<0 every c → continue always; a stays 9; print 9+4=13.
- Q15: Asks output of a=4,b=2,c=4 with if (a>c || (a+b)<(b−a)) updating b=8+a, printing a+b+c. Answer: 10. Why: 4>4 false and 6<−2 false → b unchanged; print 4+2+4=10.
- Q16: Asks output of a=3,b=1,c=2 with b=b^a, truthiness checks (b && c), (a), and a mod 1, printing a+b+c. Answer: 1. Why: b=1^3=2 (truthy) → b=1; a truthy → a=3 mod 1=0; c=0; print 0+1+0=1.
- Q17: Asks value printed after nested loops over 4×2 array {{12,21},{13,54},{52,63},{17,81}} where inner loop adds arr[k][k] once per k but a jump exits after first iteration. Answer: 12. Why: k=0 adds arr[0][0]=12, then jump exits outer loop.
- Q18: Asks output incrementing even-indexed / decrementing odd-indexed elements of arr={1,3,17,15,9} (a 0→4), printing arr[1]+arr[2]*arr[4]. Answer: 182. Why: array → {2,2,18,14,10}; 2+18*10=182.
- Q19: Asks how many times "student" prints in while loop (x=15, condition x EQUALS 15) with print + jump-out. Answer: "It will print 'student' only one time". Why: condition true → prints once, then jump exits.
- Q20: Asks final value of a=27 after successive mods (mod 30, 29, 28, 27). Answer: 0. Why: 27 mod 30/29/28 stays 27; 27 mod 27 = 0.

Mechanics confirmed: submit-unanswered → View result (score/overview/rank) → View Solution (per-question correct answers with green checks + explanations). Re-attempt offered; attempts numbered; no explicit attempt limit shown.
