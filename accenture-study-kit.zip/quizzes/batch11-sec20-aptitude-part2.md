# Quiz Batch 11 — Section 20 aptitude part 2 (6 quizzes, 120 questions)

Extracted 2026-10-14 from prior submitted attempts via View Solution (no new submissions).
Per-question: Asks (paraphrased intent) / Answer (correct) / Why (gist).

## Easy Reasoning-3 (20 questions)
- Q1: Asks: syllogism — "Some ants are parrots; All parrots are apples" — conclusions? Answer: only (2) follows.
- Q2: Asks: syllogism — "Some papers are pens; All pencils are pens" — conclusions? Answer: both (1) and (2) follow.
- Q3: Asks: seating (7 students, benches @,#,*) — pair on bench *? Answer: M, S.
- Q4: Asks: same — H sits on bench # with whom? Answer: X.
- Q5: Asks: same — set of students on bench @? Answer: Z, T.
- Q6: Asks: "?" in 3×3 table (rows 1-2-3, 11-7-6, 120-45-?)? Answer: 27. Why: col pattern 11²−1²=120, 7²−2²=45, 6²−3²=27.
- Q7: Asks: "?" in 3×3 table (rows ?-13-49, 8-17-67, 13-11-59)? Answer: 5.
- Q8: Asks: Snigdha 15th of 55 girls; 3 removed from back — new rank from bottom? Answer: 38.
- Q9: Asks: bar chart — wheat 2019+2020 as % of 2017+2018? Answer: 183.33%. Why: 27.5/15×100.
- Q10: Asks: data sufficiency — meaning of "&" in code language? Answer: E (both together necessary).
- Q11: Asks: data sufficiency — Shailesh's relation to Mohan? Answer: D (insufficient).
- Q12: Asks: data sufficiency — Indian cricket team's total score? Answer: A (I alone, as marked).
- Q13: Asks: data sufficiency — which taxi Shweta caught? Answer: D (insufficient).
- Q14: Asks: series "B @ C 7 N R % 5 $ G 6 K M & 4 S # P U 5" — symbols followed by consonants interchange — resulting element [stem truncated]? Answer: #.
- Q15: Asks: arrangement groups "BC7 R5$ 6M& ?" — next group? Answer: SPU.
- Q16: Asks: same arrangement, 2nd left of 12th from right after dropping symbols [stem truncated]? Answer: C.
- Q17: Asks: angle between clock hands at 4:20? Answer: 10°.
- Q18: Asks: "BASE"→"GUCD"; code "COMMAND"? Answer: FPCOOQE. Why: reverse +2 each.
- Q19: Asks: blood relation — "He is the son of the daughter of the father of my uncle." Answer: Brother.
- Q20: Asks: direction — Mary walks South-West 15 miles, turns right 10 miles, then... [stem truncated]? Answer: North-West.

## Easy Reasoning-4 (20 questions)
- Q1: Asks: data sufficiency — which country is south of China? Answer: D (insufficient).
- Q2: Asks: data sufficiency — Brazil's rank of 40 (10 between Brazil and Canada; Canada 20th)? Answer: D (9th or 31st — insufficient).
- Q3: Asks: data sufficiency — who came last (Neha, Naina, Nishtha, Jamal, Harsh)? Answer: E (both together necessary).
- Q4: Asks: digit-letter-symbol series, drop digits; 3rd right of 11th from left? Answer: Z.
- Q5: Asks: 7th left of 9th from right? Answer: &.
- Q6: Asks: clock hands at right angle in a day? Answer: 44.
- Q7: Asks: clock hands straight but opposite in a day? Answer: 22.
- Q8: Asks: SPREAD→"sPReaD"; code CORONA? Answer: coRoNa (odd positions lowercase).
- Q9: Asks: data sufficiency — tallest of Ram, Shyam, Ganesh, Shankar, John, Mark? Answer: B (II alone).
- Q10: Asks: five classmates in circle — immediately right of Tarun [stem truncated]? Answer: A.
- Q11: Asks: data sufficiency — what time did the bus leave (normally 5 min late; scheduled 10 pm)? Answer: D (insufficient).
- Q12: Asks: clock hands coincide in a day? Answer: 22.
- Q13: Asks: FANTA→"LGTZG"; code CRICKET? Answer: IXOIQKZ (+6 each).
- Q14: Asks: reverse-word code DHRUVA→"BWVSIE"; word coded "BWSBIUB"? Answer: ATHARVA. Why: reversed +1.
- Q15: Asks: CH4IR→"GL8MV"; code "1N5T4GR4M"? Answer: 5R9X8KV8Q (+4 each).
- Q16: Asks: blood relation — Bajpai: "He is the son of the only daughter of the father of my brother"? Answer: Maternal Uncle.
- Q17: Asks: direction — Joe 35 m east from Mary's house, left 15 m, then... [stem truncated]? Answer: 45.
- Q18: Asks: direction — boy 12 km east, 90° CW, 20 km, right... [stem truncated]? Answer: 29.
- Q19: Asks: water-image of "ACOUSTIC" (image options)? Answer: 2nd option (vertically mirrored).
- Q20: Asks: syllogism — All actors are girls; All girls are beautiful? Answer: both (1) and (2) follow.

## Easy Verbal-1 (20 questions)
- Q1: Asks: RC — "evaluation of news" implies? Answer: more careful analysis of each news story and its value.
- Q2: Asks: RC — news that "amounts to a row of beans" means? Answer: deserves no one's attention.
- Q3: Asks: cloze (Earth) — the only ___ with an atmosphere? Answer: Planet.
- Q4: Asks: cloze — smaller ___ the four gas giants? Answer: Than.
- Q5: Asks: cloze — Earth is ___ because gravity pulls matter into a ball? Answer: Round.
- Q6: Asks: cloze — "About a ___"? Answer: Plants.
- Q7: Asks: error — "Ram was / senior to / Sam in College"? Answer: No Error.
- Q8: Asks: error — "It was him / who came / running / into the classroom"? Answer: "It was him".
- Q9: Asks: one word — life story written by oneself? Answer: Autobiography.
- Q10: Asks: one word — one who talks while asleep? Answer: Somniloquist.
- Q11: Asks: antonym of "Foremost"? Answer: Unimportant.
- Q12: Asks: idiom — "To make clean breast of"? Answer: to confess without reserve.
- Q13: Asks: synonym of "Fostering"? Answer: Nurturing.
- Q14: Asks: analogy CUP : LIP :: BIRD : ?? Answer: BEAK.
- Q15: Asks: analogy Flow : River :: Stagnant : ?? Answer: Pool.
- Q16: Asks: arrange — "A get some peace / B he left home / C his parents could / D in order that"? Answer: BDCA.
- Q17: Asks: arrange — "A In the wintertime / B the 2022 World Cup in Qatar / C would best be staged / D will not be held"? Answer: BDCA.
- Q18: Asks: indirect speech — "Kiran asked me, 'Did you see the Cricket match on television last night?'" Answer: "Kiran asked me whether I had seen the Cricket match on television the earlier night."
- Q19: Asks: indirect speech — "David said to Anna, 'Mona will leave for her native place tomorrow.'" Answer: "David told Anna that Mona would leave for her native place the next day."
- Q20: Asks: tense — "When you phoned, I ___ a shower." Answer: was having.

## Easy Verbal-4 (20 questions)
- Q1: Asks: cloze (chernozem soil) — first blank? Answer: Decrease.
- Q2: Asks: word choice — on/for/of/them? Answer: of.
- Q3: Asks: word choice — after/later/late/next? Answer: later.
- Q4: Asks: cloze (chernozem) — second blank? Answer: Essential.
- Q5: Asks: error — "Everyone knows / that the leopards is / faster / of all animals"? Answer: "of all animals".
- Q6: Asks: error — "I and my colleague / have carefully considered..."? Answer: "I and my colleague".
- Q7: Asks: one word — misanthrope disliking women? Answer: Misogynist.
- Q8: Asks: one word — one who considers others' happiness? Answer: Altruist.
- Q9: Asks: idiom — "To be above board"? Answer: to be honest in any business deal.
- Q10: Asks: analogy Carbon : Diamond :: Corundum : ?? Answer: Ruby.
- Q11: Asks: analogy Architect : Building :: Sculptor : ?? Answer: Statue.
- Q12: Asks: arrange — "A Bestowed with indifference / B with kind words is much more / C a small gift accompanied / D acce..." [truncated]? Answer: CBDA.
- Q13: Asks: reported speech — He said, "Be quite and listen to my words." Answer: "He urged them to be quite and listen to his words."
- Q14: Asks: reported speech — He said to me, "I have often told you not to play with fire." Answer: "He told me that he had often told me not to play with fire."
- Q15: Asks: tense — "I'm tired. I ___ for 3 hours!" Answer: have been studying.
- Q16: Asks: RC — forest floor soft because...? Answer: the forest did not harden it on account of trees.
- Q17: Asks: RC — "We did not mind the hardness of road because"? Answer: we had nailed boots on.
- Q18: Asks: analogy Eye : Myopia :: Teeth : ?? Answer: Pyorrhoea.
- Q19: Asks: analogy Conference : Chairman :: Newspaper : ?? Answer: Editor.
- Q20: Asks: synonym of "Cease"? Answer: Stop.

## Easy Verbal-3 (20 questions)
- Q1: Asks: RC — "God in man" implies? Answer: the divine qualities in man.
- Q2: Asks: RC — where does human "salvation" lie? Answer: spiritual transformation of life.
- Q3: Asks: RC — people jeer at the "birth of Man" when they...? Answer: become power hungry.
- Q4: Asks: error — "Supposing if / it rains / what shall / we do?"? Answer: "Supposing if".
- Q5: Asks: one word — one who collects coins? Answer: Numismatist.
- Q6: Asks: one word — one who talks of his achievements? Answer: Egotist.
- Q7: Asks: antonym of "Last"? Answer: Grow.
- Q8: Asks: idiom — "To cry wolf"? Answer: to give false alarm.
- Q9: Asks: synonym of "Defer"? Answer: Postpone.
- Q10: Asks: analogy REASON : SFBTPO :: THINK : ?? Answer: UIJOL (+1 each).
- Q11: Asks: arrange — "A coal as a fuel / B in place of wood / C during this period / D people were beginning to use"? Answer: CDAB.
- Q12: Asks: reported speech — The tailor said to him, "Will you have the suit ready by tomorrow evening?" Answer: "The tailor asked him if he would have the suit ready by the next evening."
- Q13: Asks: reported speech — He said to the interviewer, "Could you please repeat the question?" Answer: "He requested the interviewer to repeat the question."
- Q14: Asks: tense — "Most major cities ___ significantly over the last 30 years." Answer: have grown.
- Q15: Asks: tense — "Mick usually ___ his dog in the afternoon." Answer: walks.
- Q16: Asks: error — "Either Nemmu or Mennu / are in the wrong; / both can / certainly never be?"? Answer: "are in the wrong;".
- Q17: Asks: error — "None of two girls / who were present / appeared to be inclined / to listen to sane advice."? Answer: "None of two girls".
- Q18: Asks: one word — lover of good food? Answer: Gourmand.
- Q19: Asks: antonym of "Mighty"? Answer: Weak.
- Q20: Asks: idiom — "To end in smoke"? Answer: to ruin oneself.

## Easy Verbal-2 (20 questions)
- Q1: Asks: RC (Monte Cristo) — Dantes was in...? Answer: a prison.
- Q2: Asks: RC — Dantes heard the key grate when...? Answer: storeroom was shut.
- Q3: Asks: RC — Dantes was planning to...? Answer: make his escape.
- Q4: Asks: error — "The capital of Yemen / is situating / 2190 meters above / the sea level"? Answer: "is situating".
- Q5: Asks: error — "The captain along with his team / are practicing very hard / for the / forth coming matches"? Answer: "are practicing very hard".
- Q6: Asks: one word — one who believes in fate? Answer: Fatalist.
- Q7: Asks: one word — policeman on motorcycle guarding a VIP? Answer: Outriders.
- Q8: Asks: antonym of "Terrible"? Answer: Soothing.
- Q9: Asks: idiom — "To catch a tartar"? Answer: to catch a dangerous person.
- Q10: Asks: idiom — "To have an axe to grind"? Answer: a private end to serve.
- Q11: Asks: synonym of "Massive"? Answer: Huge.
- Q12: Asks: synonym of "Stumbling Block"? Answer: Hurdle.
- Q13: Asks: analogy Paw : Cat :: Hoof : ?? Answer: Horse.
- Q14: Asks: analogy Peacock : India :: Bear : ?? Answer: Russia.
- Q15: Asks: arrange — "A He was a versatile writer who / B that are all considered the best in their spheres / C Tagore was a poet before everything else but / D wrote novels, dramas, essays, and short stories"? Answer: CADB.
- Q16: Asks: reported speech — He said to her, "What a cold day!" Answer: "He exclaimed that it was a very cold day."
- Q17: Asks: tense — "They ___ the French course yet." Answer: have not started.
- Q18: Asks: tense — "My family ___ in Australia for a year when I was a child." Answer: lived.
- Q19: Asks: one word — an iconoclast is one who...? Answer: destroys images.
- Q20: Asks: antonym of "Widely"? Answer: Narrowly.

Note: a few stems were truncated in the rendered page (Reasoning-3 Q14/Q16/Q20, Reasoning-4 Q10/Q17/Q18); paraphrases reflect visible content. Green-check verified via page markup.
