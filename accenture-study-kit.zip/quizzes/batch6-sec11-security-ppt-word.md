# Quiz Batch 6 — Section 11 security + situational + PPT + Word (8 quizzes, 140 questions)

Extracted 2026-10-14 via submit-unanswered → View Solution.
Per-question: Asks (paraphrased intent) / Answer (correct) / Why (gist).

## Security and Cloud Mock-1 (20 questions)
- Q1: Asks: which cloud model offers least built-in security? Answer: IaaS (SaaS most).
- Q2: Asks: true statement about cloud security? Answer: "All of the mentioned" (services differ by model; on-prem adaptation needs planning; encrypt in transfer/storage).
- Q3: Asks: which model delivers virtualized computing resources over internet? Answer: IaaS.
- Q4: Asks: what is the responsibility model? Answer: division of security duties between provider and customer.
- Q5: Asks: encryption technique commonly protecting cloud data in transit? Answer: AES.
- Q6: Asks: SaaS providers manage/secure all except ___? Answer: access controls (customer's enterprise security).
- Q7: Asks: which data may not suit public clouds? Answer: all (legacy app data, mission-critical, sensitive).
- Q8: Asks: Simple Cloud, jclouds, Libcloud are examples of ___? Answer: cross-platform APIs.
- Q9: Asks: moved to cloud, users face slow data access — cause? Answer: insufficient bandwidth.
- Q10: Asks: in IaaS, user's responsibility? Answer: operating system (provider: infrastructure).
- Q11: Asks: SaaS product scaling issues — likely cause? Answer: app has limited inherent scalability.
- Q12: Asks: best suited for hybrid cloud? Answer: large enterprise with varying workloads.
- Q13: Asks: which Azure service deploys apps across hybrid cloud? Answer: Azure Stack.
- Q14: Asks: public-cloud company with data-security concerns — solution? Answer: move to hybrid cloud.
- Q15: Asks: flowchart evaluates ___ in any cloud? Answer: risk.
- Q16: Asks: wrong statement? Answer: "Cloud computing doesn't have vulnerabilities associated with Internet applications."
- Q17: Asks: attack intercepting and altering communication? Answer: Man-in-the-Middle.
- Q18: Asks: primary purpose of CASB? Answer: enforcing security policies in cloud services.
- Q19: Asks: which is NOT confidential computing? Answer: zero-trust networks (categories: TEE, FHE, differential privacy, secure multiparty computation).
- Q20: Asks: key advantage of containers over VMs? Answer: faster startup time.

## Situational (Devops) New Pattern Type (10 questions; intro says 11, solutions show Q1–Q10)
- Q1: Asks: Docker containers with dedicated CPU/memory — Linux kernel feature? Answer: cgroups.
- Q2: Asks: K8s component scheduling pods onto nodes? Answer: Scheduler.
- Q3: Asks: stop one container accessing another's PIDs/network stack — mechanism? Answer: Namespaces.
- Q4: Asks: prevent data leakage between VMs on same host — component? Answer: Hypervisor.
- Q5: Asks: main purpose of a VPC? Answer: isolate network resources within the cloud.
- Q6: Asks: best description of least privilege? Answer: users get only permissions they need.
- Q7: Asks: confidentiality of stored customer data even if storage compromised — solution? Answer: data encryption at rest.
- Q8: Asks: K8s resource stopping containers exceeding CPU/memory? Answer: ResourceQuota.
- Q9: Asks: main advantage of RBAC on container platform? Answer: prevents unauthorized admin actions.
- Q10: Asks: sysadmin using SELinux — primary purpose? Answer: mandatory access control (MAC).

## Situational (Story Based) New Pattern (10 questions)
- Q1: Asks: multiple containers on one host — filesystem isolation mechanism? Answer: Namespaces.
- Q2: Asks: K8s admin caps total memory/CPU of a namespace — object? Answer: ResourceQuota.
- Q3: Asks: two containers share same network namespace — true? Answer: they share same IP and network stack.
- Q4: Asks: hardware virtualization — component allocating CPU/memory between VMs? Answer: Hypervisor.
- Q5: Asks: containerized ML app needs direct GPU access — kernel feature? Answer: device cgroups.
- Q6: Asks: prevent containers gaining unnecessary host privileges — setting? Answer: privileged mode disabled.
- Q7: Asks: CPU starvation when one service overuses CPU — preventing mechanism? Answer: cgroups.
- Q8: Asks: K8s object ensuring pod runs on GPU node? Answer: NodeSelector.
- Q9: Asks: container started --read-only — achieved? Answer: prevents filesystem modification.
- Q10: Asks: secure comms between microservices in different containers — approach? Answer: service mesh with mutual TLS.

## PPT Mock-1 (20 questions)
- Q1: Asks: ungroup shapes shortcut? Answer: Ctrl+Shift+G.
- Q2: Asks: group shapes shortcut? Answer: Ctrl+G.
- Q3: Asks: slideshow from current slide? Answer: Shift+F5.
- Q4: Asks: easy way to apply varied text animations? Answer: apply an Animation Scheme.
- Q5: Asks: view showing all slides on one screen? Answer: View → Slide Sorter.
- Q6: Asks: comments record author/time — feature? Answer: Use Comments.
- Q7: Asks: designs regulating formatting/layout called? Answer: Templates.
- Q8: Asks: what adds text to a slide? Answer: Text Box.
- Q9: Asks: incorrect statements: (i) Ctrl+N adds new slide; (ii) PPT 2016 can save as PDF? Answer: only (i) false (Ctrl+N = new presentation).
- Q10: Asks: dotted areas in empty slide called? Answer: Placeholders.
- Q11: Asks: one of PowerPoint's views? Answer: Presentation View.
- Q12: Asks: same title font/size/color on all slides? Answer: Slide Master.
- Q13: Asks: slideshow from beginning? Answer: F5.
- Q14: Asks: where are themes? Answer: Design tab.
- Q15: Asks: NOT a slide orientation option? Answer: Diamond (options: Landscape, Portrait, Square).
- Q16: Asks: NOT a title-slide layout option? Answer: Picture and content.
- Q17: Asks: NOT a transition timing option? Answer: Instant (Slow, Medium, Fast are).
- Q18: Asks: NOT a slide size option? Answer: Panorama (Standard, Widescreen, Square are).
- Q19: Asks: zoom in/out of a slide? Answer: Ctrl + Mouse Wheel.
- Q20: Asks: exit PowerPoint shortcut? Answer: Alt+F4.

## PPT Mock-2 (20 questions)
- Q1: Asks: undo last action? Answer: Ctrl+Z.
- Q2: Asks: duplicate a slide? Answer: Ctrl+D.
- Q3: Asks: animate shape along a path? Answer: Motion Paths animation effect.
- Q4: Asks: embed YouTube video? Answer: Insert tab → Video → Online Video.
- Q5: Asks: next slide in slideshow mode? Answer: all (Arrow Right, Spacebar, Enter).
- Q6: Asks: what does Format Painter do? Answer: copies formatting to another object.
- Q7: Asks: default slide text font size? Answer: 24 pt.
- Q8: Asks: zoom in on presentation? Answer: all (zoom slider, Ctrl+"+", View tab).
- Q9: Asks: purpose of Notes section? Answer: speaker notes for reference.
- Q10: Asks: apply a design theme? Answer: Design tab → select theme.
- Q11: Asks: Outline View used for? Answer: view/edit text in simple format.
- Q12: Asks: where is Slide Master? Answer: View tab.
- Q13: Asks: purpose of SmartArt? Answer: visual diagrams and charts.
- Q14: Asks: default PowerPoint file extension? Answer: .pptx.
- Q15: Asks: which gives printed copy of presentation? Answer: Audience Handouts.
- Q16: Asks: select more than one slide? Answer: Shift + Click each.
- Q17: Asks: logo in same position on every slide — insert on ___? Answer: Slide Master.
- Q18: Asks: element just above Ribbon for common commands? Answer: Quick Access Toolbar.
- Q19: Asks: file format for PowerPoint templates? Answer: .potx.
- Q20: Asks: preview motion path via Custom Animation pane? Answer: click Play.

## Word Mock-1 (20 questions)
- Q1: Asks: show non-printing characters? Answer: Ctrl+Shift+8.
- Q2: Asks: toggle uppercase/lowercase? Answer: Shift+F3.
- Q3: Asks: quickly open Font dialog? Answer: Ctrl+D.
- Q4: Asks: what is inserted as cross-reference? Answer: Word fields.
- Q5: Asks: Ctrl+N does? Answer: new document.
- Q6: Asks: which are word processing software? Answer: all (WordPerfect, WordPad, MS Word).
- Q7: Asks: document name displays in? Answer: title bar.
- Q8: Asks: paste shortcut? Answer: Ctrl+V.
- Q9: Asks: select all? Answer: Ctrl+A.
- Q10: Asks: center text? Answer: Ctrl+E.
- Q11: Asks: NOT a valid way to modify page numbering? Answer: Styles gallery.
- Q12: Asks: underline shortcut? Answer: Ctrl+U.
- Q13: Asks: NOT a valid way to insert a picture? Answer: typing the picture into the document.
- Q14: Asks: delete word to the right? Answer: Ctrl+Delete.
- Q15: Asks: open Help pane? Answer: F1.
- Q16: Asks: right-align? Answer: Ctrl+R.
- Q17: Asks: close current Word window? Answer: Ctrl+W.
- Q18: Asks: insert current date? Answer: Alt+Shift+D.
- Q19: Asks: what is a "Bookmark"? Answer: tool marking sections for quick navigation.
- Q20: Asks: what is "Thesaurus" for? Answer: synonyms and antonyms.

## Word Mock-2 (20 questions)
- Q1: Asks: function of "Table Styles"? Answer: quickly apply predefined table formatting.
- Q2: Asks: purpose of "Cross-References"? Answer: link text/tables across sections.
- Q3: Asks: what does "Developer" tab allow? Answer: insert advanced controls and macros.
- Q4: Asks: small squares on graphic's selection rectangle? Answer: sizing handles.
- Q5: Asks: short horizontal line at document end? Answer: end mark.
- Q6: Asks: screen element below title bar with categorized options? Answer: menu bar.
- Q7: Asks: email Word doc from within Word? Answer: Office button → Send to → Mail Recipient.
- Q8: Asks: insert new comment? Answer: Ctrl+Shift+M.
- Q9: Asks: open Find and Replace? Answer: Ctrl+H.
- Q10: Asks: valid Word file format? Answer: .docx.
- Q11: Asks: NOT a Word view? Answer: Slide.
- Q12: Asks: NOT a font style? Answer: Rounded (Bold, Italic, Underline are).
- Q13: Asks: NOT found in Home tab? Answer: Page Layout.
- Q14: Asks: where to add paragraph borders? Answer: Borders dropdown (Home tab).
- Q15: Asks: where to apply superscript/subscript? Answer: Font dialog box launcher.
- Q16: Asks: where to apply strikethrough? Answer: Font dialog box launcher.
- Q17: Asks: purpose of Document Inspector? Answer: remove hidden data/metadata.
- Q18: Asks: customize the Ribbon? Answer: File → Options → Customize Ribbon.
- Q19: Asks: what are Content Controls? Answer: interactive elements (text boxes, drop-downs).
- Q20: Asks: what is a macro? Answer: recorded instructions automating repetitive tasks.

## Word Mock-3 (20 questions)
- Q1: Asks: secure Word doc with password? Answer: File → Info → Protect Document.
- Q2: Asks: change margins via? Answer: Page setup dialog box.
- Q3: Asks: Insert Date, Format Page Number, AutoText buttons are on ___ toolbar? Answer: Header and Footer.
- Q4: Asks: Word web authoring tools incorporate ___ on web pages? Answer: all (bullets, hyperlinks, sounds).
- Q5: Asks: which reduces spelling errors? Answer: Auto Correct.
- Q6: Asks: key combo creating line break advancing to next line? Answer: Shift+Enter.
- Q7: Asks: feature aligning text equally between margins? Answer: Justify Alignment.
- Q8: Asks: purpose of ruler? Answer: align text, graphics, other elements.
- Q9: Asks: default Word orientation? Answer: Portrait.
- Q10: Asks: feature adding decorative text? Answer: WordArt.
- Q11: Asks: check word count? Answer: Review → Word Count.
- Q12: Asks: change line spacing? Answer: Home tab → Line Spacing.
- Q13: Asks: feature applying pre-designed text formatting? Answer: Templates.
- Q14: Asks: view showing printed appearance? Answer: Print Layout.
- Q15: Asks: what is a "Footer"? Answer: content at bottom of each page.
- Q16: Asks: default line spacing? Answer: 1.15 lines.
- Q17: Asks: what is Mail Merge? Answer: create mailing labels, envelopes, form letters.
- Q18: Asks: manual line break shortcut? Answer: Shift+Enter (soft return).
- Q19: Asks: double-underline a word — how? Answer: select text → Format > Font → Underline Style → Double Underline (Word 2003); Home → Font → underline style drop-down (2007+).
- Q20: Asks: detect spelling/grammar errors? Answer: press F7.

Note: Situational (Devops) intro says 11 questions but Solutions lists Q1–Q10 (result 0/10, 10 unanswered, 1 incorrect). The "Question Paper" item was static text, not a link, for these quizzes — data from Solutions pages.
