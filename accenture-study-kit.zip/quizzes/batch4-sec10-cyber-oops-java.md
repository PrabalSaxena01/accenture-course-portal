# Quiz Batch 4 — Section 10 cybersecurity + OOPS + Java (7 quizzes, 140 questions)

Extracted 2026-10-14 via submit → View Solution.
Per-question: Asks (paraphrased intent) / Answer (correct) / Why (gist).

## Cybersecurity SB Mock-1 (20 questions, scenario-based)
- Q1: Asks: immediate next step after SIEM alerts successful intrusion into financial DB via compromised service account. Answer: Isolate the DB server from the network and revoke the compromised credentials. Why: "Containment" — stops attacker spread.
- Q2: Asks: which evidence to collect first at a crime scene, per volatility. Answer: System memory (RAM) dump. Why: most volatile first.
- Q3: Asks: what's wrong with relying on client-side JS for input sanitization. Answer: attackers bypass client-side code, sending malicious requests straight to server (e.g. via Burp Suite).
- Q4: Asks: ' OR '1'='1' -- in login field — attack + fix. Answer: SQL Injection; parameterized queries (prepared statements). Why: input never treated as code.
- Q5: Asks: which crypto method proves a sender actually sent a document (non-repudiation). Answer: Digital signatures (sender's private key). Why: hashing gives integrity only.
- Q6: Asks: best encryption design for large transfers (performance). Answer: asymmetric (RSA/ECC) for key exchange + symmetric (AES) for data. Why: hybrid = how TLS works.
- Q7: Asks: pen tester has low-priv shell, wants admin — which attack phase. Answer: Post-Exploitation (privilege escalation).
- Q8: Asks: scanner flags vuln already mitigated by manual hardening — action? Answer: accept risk, mark "False Positive"/"Mitigated by Compensating Control", document it.
- Q9: Asks: EU "Right to Erasure" — CIA triad area + implementation. Answer: Confidentiality and Integrity; data-retention/disposal policy with auditable deletion.
- Q10: Asks: Risk A (high likelihood, low impact) vs Risk B (low likelihood, high impact) — priority? Answer: Risk B. Why: high impact outweighs.
- Q11: Asks: distributed ledger, all nodes agree on shared immutable history — what enables agreement? Answer: hashing + consensus algorithm (PoW/PoS).
- Q12: Asks: thousands of open-source deps, SolarWinds-style risk — best proactive tool? Answer: Software Composition Analysis (SCA) scanning deps for vulns/licenses.
- Q13: Asks: personalized email from seemingly legit vendor citing real transaction, asking to click — attack + hallmark? Answer: Spear phishing — targeted with tailored info.
- Q14: Asks: data encrypted before leaving app, stays encrypted at rest, key inaccessible to provider — methodology? Answer: Client-Side Encryption with customer-managed key from third-party KMS.
- Q15: Asks: in network forensics, which artifact indicates LAN MITM? Answer: ARP replies mapping same MAC to two different IPs (ARP poisoning).
- Q16: Asks: ransomware exfiltrating via DNS TXT records — channel + why it evades? Answer: DNS tunneling — DNS almost always permitted outbound, rarely deeply inspected.
- Q17: Asks: XXE vulnerability — critical failures from exploitation? Answer: disclosure of local server files, or SSRF against internal systems.
- Q18: Asks: encryption key hardcoded in source repo — violated principle + risk? Answer: key confidentiality/secure storage — total data compromise if repo breached.
- Q19: Asks: policy says "Critical" vulns fixed in 7 days, but owner claims non-prod/air-gapped — correct GRC procedure? Answer: formal risk exception/acceptance with documentation, C-level approval, compensating-control review.
- Q20: Asks: industry-standard protocol for cross-domain auth + claims authorization (SSO)? Answer: SAML.

## Cybersecurity SB Mock-2 (20 questions, scenario-based)
- Q1: Asks: company with remote sites/workers needs secure remote access — which VPN? Answer: IPSec VPN. Why: secure, corporate-compatible (PPTP outdated).
- Q2: Asks: attack injecting malicious routes to mis-forward traffic? Answer: routing table poisoning (route hijacking).
- Q3: Asks: audit finds IoT on outdated protocols — action? Answer: upgrade to secure protocols.
- Q4: Asks: web server vulnerable to SQL injection — fix? Answer: sanitize/validate user inputs.
- Q5: Asks: official company URL redirects to fake login — attack? Answer: DNS hijacking (vs MITM = live interception).
- Q6: Asks: clicked link downloads script that self-spreads across network — malware? Answer: Worm.
- Q7: Asks: security device actively blocking malicious traffic (not just detecting)? Answer: IPS (vs IDS detects, SIEM correlates, NAC controls access).
- Q8: Asks: primary benefit of data-center micro-segmentation? Answer: restricts lateral movement after foothold.
- Q9: Asks: ALE given SLE $500,000 and 4 failures/year? Answer: $2,000,000. Why: ALE = SLE × ARO.
- Q10: Asks: new worm, constantly changing payload signature — type? Answer: Polymorphic malware.
- Q11: Asks: smart camera auto-connects to unknown open Wi-Fi — vulnerability? Answer: rogue access point / backdoor bridge.
- Q12: Asks: Zero Trust best description? Answer: "Never trust, always verify."
- Q13: Asks: app protected by WAF + IPS + strong access — principle? Answer: Defense in depth.
- Q14: Asks: main goal of SOAR adoption? Answer: reduce MTTR by automating repetitive IR tasks.
- Q15: Asks: technique giving integrity + authenticity with one shared symmetric key? Answer: HMAC.
- Q16: Asks: bank breached via over-permissioned serverless fn with cross-account S3 — failures? Answer: least-privilege violation + shadow-IT governance failure.
- Q17: Asks: critical RCE in popular open-source logging lib — best containment before patch? Answer: restrict all outbound connections via firewall/security groups.
- Q18: Asks: employee copied customer list to USB then deleted it; process logging off — missing evidence? Answer: the exact command line of the copy utility.
- Q19: Asks: Alex installed free unreleased "Cosmic Quest" from sketchy forum — infection? Answer: Trojan horse.
- Q20: Asks: Maria got urgent fake "IT Helpdesk" email asking for sensitive info — best defense? Answer: spam filtering + domain whitelisting.

## OOPS Mock-1 (20 questions)
- Q1: Asks: who invented OOP? Answer: Alan Kay (Goldberg → Smalltalk; Ritchie → C).
- Q2: Asks: which is NOT a general OOP feature? Answer: duplicate/redundant data.
- Q3: Asks: which is NOT a basic OOP concept? Answer: Functions.
- Q4: Asks: output of Python snippet (Animal/Dog, overridden speak()). Answer: "barks".
- Q5: Asks: Java class-creation keyword? Answer: class.
- Q6: Asks: which OOP feature indicates reusability? Answer: Inheritance.
- Q7: Asks: specifier applying to constructors only? Answer: Explicit (prevents implicit conversions).
- Q8: Asks: a constructor _______. Answer: has no return type (not even void).
- Q9: Asks: where is object memory allocated? Answer: RAM.
- Q10: Asks: what determines when a variable comes into existence in memory? Answer: Storage class.
- Q11: Asks: correct constructor name? Answer: same as the class.
- Q12: Asks: how to access class data members? Answer: dot or arrow operator as required.
- Q13: Asks: total C++ access specifiers? Answer: 3 (private, public, protected).
- Q14: Asks: instances of an abstract class creatable? Answer: 0.
- Q15: Asks: why is Java only partially object-oriented? Answer: primitive data type declarations.
- Q16: Asks: correct inheritance syntax? Answer: class derived : access base { ... };
- Q17: Asks: which OOP features in given code (classes + inheriting student)? Answer: Encapsulation and Inheritance.
- Q18: Asks: by which feature does one object interact with another? Answer: Message passing.
- Q19: Asks: for a pure OOP language, which is true? Answer: must follow all OOP rules.
- Q20: Asks: which is NOT true about polymorphism? Answer: it always increases function-definition overhead.

## OOPS Mock-2 (20 questions)
- Q1: Asks: which constructor runs (C++ code, default + one-default-arg ctors)? Answer: Compile-time error (ambiguous).
- Q2: Asks: which can show polymorphism? Answer: Overloading <<.
- Q3: Asks: in which access should a constructor be defined for objects creatable in any function? Answer: Public.
- Q4: Asks: class with single-arg constructor — correct? Answer: runs; all objects created (conversion ctor).
- Q5: Asks: copy constructors can be used to ______? Answer: copy an object to pass to a function.
- Q6: Asks: class defined, no instance, method called — error? Answer: Compilation error.
- Q7: Asks: Car with no-arg drive() — correct call? Answer: myCar.drive().
- Q8: Asks: what best describes an object's "state"? Answer: data stored within the object.
- Q9: Asks: what best describes an instance variable? Answer: variable unique to each instance.
- Q10: Asks: output of Box program (ctor sets width=5)? Answer: 5.
- Q11: Asks: output of code (increment()/getCount(), no main)? Answer: None of the above (compiles, nothing executes).
- Q12: Asks: per encapsulation, private age with getter/setter? Answer: private int age; public getAge()/setAge().
- Q13: Asks: what's wrong (static setScore accessing instance var)? Answer: setScore can't be static.
- Q14: Asks: after adding feature, object creation fails — likely cause? Answer: class not recompiled.
- Q15: Asks: inheriting base, then another from derived — which inheritance? Answer: Multi-level.
- Q16: Asks: feature enforcing abstract-function definitions at derived level? Answer: Dynamic polymorphism.
- Q17: Asks: class called in main directly with public member fn — result? Answer: Undeclared function error.
- Q18: Asks: total C++ constructor types? Answer: 3 (default, parameterized, copy).
- Q19: Asks: total C++ polymorphism types? Answer: 2 (runtime, compile-time).
- Q20: Asks: a virtual function should be ______? Answer: public.

## OOPS Mock-3 (20 questions)
- Q1: Asks: how many catch blocks per try? Answer: as many as needed.
- Q2: Asks: when is object created with new? Answer: at run time.
- Q3: Asks: which functions can be inherited from base? Answer: none (constructor, destructor, static).
- Q4: Asks: another name for generic class? Answer: Template class.
- Q5: Asks: function overriding shows which feature? Answer: Polymorphism.
- Q6: Asks: which frees C++ object memory? Answer: delete.
- Q7: Asks: which ctor called for obj2 (two args)? Answer: A(int y, int x).
- Q8: Asks: what happens passing object by reference? Answer: destructor is not called.
- Q9: Asks: which is NOT an object property? Answer: Names.
- Q10: Asks: keyword declaring virtual functions? Answer: virtual.
- Q11: Asks: non-static members in static member fn? Answer: Compile-time error.
- Q12: Asks: how can a private member function be accessed? Answer: via its address.
- Q13: Asks: which classes illustrate polymorphism (student/topper/average code)? Answer: student, topper, average together.
- Q14: Asks: ______ underlines polymorphism in a class? Answer: Virtual Function.
- Q15: Asks: which ctor declaration is correct? Answer: class student{ public: student(){} }; (no return type).
- Q16: Asks: class with only default-arg parameterized ctor; no-arg object creation? Answer: succeeds (defaults supply values).
- Q17: Asks: B inherits A (protected add() + public members) — which can B's object call? Answer: none of them.
- Q18: Asks: output of Java Malloc code? Answer: 200.
- Q19: Asks: output (left-shift)? Answer: 80. Why: shift = ×2^n.
- Q20: Asks: "try can exist without catch, but not vice versa" — true/false? Answer: True.

## Java Mock-2 (20 questions)
- Q1: Asks: last step in Java programming process? Answer: program execution.
- Q2: Asks: valid Java identifier? Answer: _identifier.
- Q3: Asks: Integer in Java is a/an ______? Answer: Wrapper class.
- Q4: Asks: what is super() for? Answer: call parent class constructor.
- Q5: Asks: output (class B extends A, both define display())? Answer: 2. Why: B's override runs.
- Q6: Asks: output (Vehicle/Car move())? Answer: "The car moves".
- Q7: Asks: output with inheritance (Sweet=)? Answer: Sweet=20.
- Q8: Asks: access modifiers in increasing visibility? Answer: private < default < protected < public.
- Q9: Asks: package storing all standard Java classes? Answer: java.lang.
- Q10: Asks: output with interface (variable reassignment)? Answer: Compiler error (interface vars are constants).
- Q11: Asks: output (for loop with i++)? Answer: 1 3.
- Q12: Asks: output (Thread.activeCount())? Answer: 1.
- Q13: Asks: which class creates a new directory? Answer: File.
- Q14: Asks: which class reads a file line by line? Answer: BufferedReader.
- Q15: Asks: which method resizes a java.awt.Component? Answer: setSize().
- Q16: Asks: what's true (OK/Cancel buttons on JFrame)? Answer: both added, only Cancel visible (BorderLayout overlap).
- Q17: Asks: what happens on button click? Answer: message dialog "Welcome to the course".
- Q18: Asks: which GUI component inputs a password? Answer: JPasswordField.
- Q19: Asks: which exception signals JDBC connectivity failure? Answer: SQLException.
- Q20: Asks: output of the Java code? Answer: Compiler error.

## Java Mock-1 (20 questions)
- Q1: Asks: primary focus of Java? Answer: Platform independence (JVM).
- Q2: Asks: valid object declaration of class NPTEL? Answer: NPTEL obj = new NPTEL ();
- Q3: Asks: a default constructor ______? Answer: has no arguments.
- Q4: Asks: constructor execution order in inheritance? Answer: base first, then derived.
- Q5: Asks: output of Java program with access modifiers (missing import)? Answer: Compiler error.
- Q6: Asks: incorrect statement about interfaces? Answer: "All variables are static and methods are public if interface is defined public." (all members implicitly public).
- Q7: Asks: output of exception-handling program? Answer: Compile-time error (catch(Exception) first swallows all).
- Q8: Asks: which stream reads data from a source? Answer: InputStream.
- Q9: Asks: repaint() on Component invokes which method? Answer: update() (→ paint()).
- Q10: Asks: parent class of all AWT components? Answer: java.awt.Component.
- Q11: Asks: event on AWT button click? Answer: ActionListener (action event).
- Q12: Asks: which architecture does Swing use? Answer: MVC.
- Q13: Asks: which class works with URLs? Answer: URL.
- Q14: Asks: what does the code do (JFrame + "JButon" "Programming in Java")? Answer: creates JFrame with labeled JButon.
- Q15: Asks: what's true about Statement.executeQuery()? Answer: executes a SELECT statement.
- Q16: Asks: which component manages a DB connection in JDBC? Answer: DriverManager.
- Q17: Asks: output (variable redefinition + undefined var)? Answer: "There are two errors."
- Q18: Asks: output of char-loop (ASCII 52, 5 iterations)? Answer: 45678. Why: '4' (52) increments → 4,5,6,7,8.
- Q19: Asks: primary purpose of PreparedStatement? Answer: execute parameterized SQL queries.
- Q20: Asks: what happens on button click? Answer: message dialog "Welcome to the course".

Note: Question Paper modal opened for OOPS mocks + Java Mock-2; for the two Cybersecurity SB mocks and Java Mock-1 the intro/Solutions pages were used. Each quiz submitted as-is (dialogs showed 1 answered/19 not — the Question Paper click had selected one radio); solutions revealed all correct answers regardless.
