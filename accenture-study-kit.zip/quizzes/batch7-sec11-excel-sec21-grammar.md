# Quiz Batch 7 — Section 11 Excel + Section 21 grammar (7 quizzes, 140 questions)

Extracted 2026-10-14 via submit-unanswered → View Solution.
Per-question: Asks (paraphrased intent) / Answer (correct) / Why (gist).

## [Security & MS Office] > Excel Mock-1 (20 questions)
- Q1: Asks: Excel shortcut opening "Go To" dialog? Answer: Ctrl+G.
- Q2: Asks: shortcut opening "Paste Special" dialog? Answer: Alt + E, S, V.
- Q3: Asks: VBA best practice for maintainable code? Answer: use comments and document the code.
- Q4: Asks: VBA technique to optimize scripts over large data? Answer: turn off screen updating.
- Q5: Asks: copy cells shortcut? Answer: Ctrl+C.
- Q6: Asks: what does COUNTA() do? Answer: counts non-blank cells.
- Q7: Asks: typing "=B25" into a cell? Answer: cell shows same value as B25.
- Q8: Asks: function returning N chars from string start? Answer: LEFT.
- Q9: Asks: function joining two+ text strings? Answer: CONCATENATE.
- Q10: Asks: which method CANNOT enter data in a cell? Answer: pressing Esc.
- Q11: Asks: where do Cancel/Enter buttons appear? Answer: formula bar.
- Q12: Asks: what does "B7:B9" indicate? Answer: cells B7 through B9.
- Q13: Asks: function category for depreciation, rates, future values, loan payments? Answer: Financial.
- Q14: Asks: select entire column? Answer: Ctrl+Spacebar.
- Q15: Asks: select entire row? Answer: Shift+Spacebar.
- Q16: Asks: insert hyperlink? Answer: Ctrl+K.
- Q17: Asks: what does Ctrl + "-" do? Answer: deletes selected row/column.
- Q18: Asks: essential for secure Excel-VBA integration with other Office apps? Answer: use trusted locations for files.
- Q19: Asks: handle a VBA script crashing Excel? Answer: isolate the problem code.
- Q20: Asks: what is a "cell"? Answer: intersection of a row and column.

## [Security & MS Office] > Excel Mock-2 (20 questions)
- Q1: Asks: function summing a range? Answer: SUM().
- Q2: Asks: purpose of AutoSum? Answer: adds up a range of cells.
- Q3: Asks: change column width? Answer: drag the column boundary.
- Q4: Asks: switch between open workbooks? Answer: Ctrl+Tab.
- Q5: Asks: Ctrl+S? Answer: Save.
- Q6: Asks: function converting text to numeric? Answer: VALUE.
- Q7: Asks: function finding position of text in string? Answer: FIND.
- Q8: Asks: function searching for text in string? Answer: SEARCH.
- Q9: Asks: true statements about active cell (bold border / receives entered data)? Answer: Only A and B.
- Q10: Asks: term for grid with labeled columns/rows? Answer: Worksheet.
- Q11: Asks: tabs found in Excel's help menu? Answer: all of the above.
- Q12: Asks: Fill Color button used for? Answer: add shading/color to cell range.
- Q13: Asks: what is a data series? Answer: collection of related data.
- Q14: Asks: Ctrl+H in Excel? Answer: opens Replace dialog.
- Q15: Asks: close workbook? Answer: Ctrl+W.
- Q16: Asks: Alt + =? Answer: inserts SUM function.
- Q17: Asks: insert current date? Answer: Ctrl+;.
- Q18: Asks: Ctrl+D? Answer: fills down data/formula from cell above.
- Q19: Asks: which key edits cell content? Answer: F2.
- Q20: Asks: insert a new row? Answer: Ctrl+Shift+Plus.

## [Security & MS Office] > Excel Mock-3 (20 questions)
- Q1: Asks: move to last cell in worksheet? Answer: Ctrl+End.
- Q2: Asks: create new worksheet? Answer: Shift+F11.
- Q3: Asks: insert a comment? Answer: Review > Insert Comment.
- Q4: Asks: first troubleshooting step when VBA script misbehaves? Answer: check for syntax errors.
- Q5: Asks: debug intermittent VBA errors? Answer: Debug tool + breakpoints.
- Q6: Asks: VBA function prompting user to select a range? Answer: InputBox().
- Q7: Asks: remove duplicates in a column? Answer: Remove Duplicates feature.
- Q8: Asks: purpose of IF function? Answer: conditional statements.
- Q9: Asks: purpose of UPPER()? Answer: converts text to uppercase.
- Q10: Asks: meaning of "data validation"? Answer: ensuring data accuracy through validation rules.
- Q11: Asks: purpose of TRANSPOSE? Answer: swaps rows and columns.
- Q12: Asks: group worksheets? Answer: select multiple sheets, right-click → Group Sheets.
- Q13: Asks: protect worksheet from editing? Answer: all of the above (password + Protect Worksheet).
- Q14: Asks: language used for Excel macros? Answer: Visual Basic.
- Q15: Asks: function returning TRUE/FALSE on two+ conditions? Answer: =AND.
- Q16: Asks: copy value from cell above? Answer: Ctrl+Shift+".
- Q17: Asks: function applying filter to a range? Answer: FILTER.
- Q18: Asks: function counting cells meeting criteria? Answer: COUNTIF.
- Q19: Asks: function splitting cell contents by delimiter? Answer: SPLIT.
- Q20: Asks: function searching first row of range, returning value? Answer: HLOOKUP.

## [Security & MS Office] > Excel Mock-4 (20 questions)
- Q1: Asks: function returning cell value at specified row/column? Answer: INDEX.
- Q2: Asks: function finding largest value ≤ specified value? Answer: VLOOKUP.
- Q3: Asks: function removing decimal portion? Answer: TRUNC.
- Q4: Asks: function rounding down to nearest integer? Answer: ROUNDDOWN.
- Q5: Asks: function counting characters in string? Answer: LEN.
- Q6: Asks: function capitalizing first letter of each word? Answer: PROPER.
- Q7: Asks: small black square at lower-right of active cell? Answer: fill handle.
- Q8: Asks: tabs at bottom of workbook? Answer: sheet tabs.
- Q9: Asks: dollar signs ($) in cell address create? Answer: absolute cell address.
- Q10: Asks: what records keystrokes/mouse for playback? Answer: Macro Recorder.
- Q11: Asks: key to check spelling? Answer: F7.
- Q12: Asks: menu opening Spelling dialog? Answer: Tools.
- Q13: Asks: difference between MS Word and MS Excel? Answer: Word = text editing; Excel = data analysis/calculations.
- Q14: Asks: prevent formula changing when copied? Answer: absolute references ($A$1).
- Q15: Asks: Ctrl+T? Answer: converts range into a table.
- Q16: Asks: what does =SUMIF(A1:A10,">10") do? Answer: adds values >10 in A1:A10.
- Q17: Asks: apply a predefined style? Answer: Styles group in Home tab.
- Q18: Asks: automate email from Excel in VBA? Answer: CDO.Message object.
- Q19: Asks: primary use of UserForm in VBA? Answer: UI element for data input.
- Q20: Asks: record a macro? Answer: Developer tab → Record Macro.

## [Communicaiton] > Concord (20 questions, subject-verb agreement)
- Q1: Asks: "Neither Raj nor his friends ___ attending the class today." Answer: are. Why: nor → verb agrees with nearest plural subject.
- Q2: Asks: "Shankar, with his friends ___." Answer: is planning for a trip to Goa. Why: agrees with singular "Shankar".
- Q3: Asks: "The club ___ planning..." Answer: is. Why: collective noun as whole.
- Q4: Asks: sentence whose verb does NOT agree? Answer: "The cohesion in paragraphs are considered..." (should be singular).
- Q5: Asks: "Two-thirds of the profit ___." Answer: is awarded to him. Why: money quantity → singular.
- Q6: Asks: "The talented magician and juggler ___ not available." Answer: is. Why: same person.
- Q7: Asks: "Fish and rice ___ a staple diet." Answer: is.
- Q8: Asks: "Each of the six boys ___ his task." Answer: has completed.
- Q9: Asks: "The mother, along with her daughter, ___ tennis on Sundays." Answer: plays.
- Q10: Asks: "Unless she ___ done the work to my standards, I ___ her." Answer: has, shall not appreciate.
- Q11: Asks: "Public speaking ___ a skill." Answer: is.
- Q12: Asks: "Some of the rice ___ still left." Answer: is.
- Q13: Asks: "Few applicants ___ backed out." Answer: have.
- Q14: Asks: "The dog and the cat ___ been fed." Answer: have.
- Q15: Asks: "The information obtained ... ___ relevant." Answer: was. Why: uncountable noun.
- Q16: Asks: "Five kilometers ___ considered a long run." Answer: is. Why: distance quantity → singular.
- Q17: Asks: "The following day every one of the students ___." Answer: was down with fever.
- Q18: Asks: "The market cost of all these accessories ___ increased." Answer: has. Why: agrees with "market cost".
- Q19: Asks: sentence whose verb does NOT agree? Answer: "The jury is split on their verdict" (collective noun split → members).
- Q20: Asks: "The Engineer and Scientist ___." Answer: has arrived. Why: single person.

## [Communicaiton] > Tenses (20 questions)
- Q1: Asks: "The player has ___ his worst days. (see)" Answer: seen (past participle).
- Q2: Asks: past participle of "catch"? Answer: caught.
- Q3: Asks: "Before pursuing entrepreneurship, Kunal ___ very hard in IoT domain. (work)" Answer: had worked. Why: earlier of two past actions.
- Q4: Asks: past participle of "swim"? Answer: swum.
- Q5: Asks: "I ___ my offer letter a week ago." Answer: received (simple past).
- Q6: Asks: "If I had been a bird, I ___ in the sky." Answer: could fly.
- Q7: Asks: "She ___ the book since 8 o'clock this morning." Answer: has been reading.
- Q8: Asks: "I ___ cricket every weekend." Answer: play.
- Q9: Asks: "She ___ her daughter to school before she goes to work." Answer: takes.
- Q10: Asks: "You can meet her at 6 o'clock. She ___ from the excursion by then." Answer: would have returned.
- Q11: Asks: "They ___ the bridge for several months." Answer: have been building.
- Q12: Asks: "The pen I ___ five years ago is still writing well." Answer: bought.
- Q13: Asks: "More than half the drain ___ been desilted." Answer: has.
- Q14: Asks: "The old Neem tree which ___ in our compound for fifty years suddenly crashed..." Answer: had stood.
- Q15: Asks: "Tamil is ___ in Tamilnadu. (speak)" Answer: spoken (verb+adjective).
- Q16: Asks: "The school ___ on June 1. (open)" Answer: opens (timetables).
- Q17: Asks: sentence with appropriate verb form? Answer: "I bought a new mobile phone last week".
- Q18: Asks: "The team is ___ by internal dissensions. (tear)" Answer: torn (past participle).
- Q19: Asks: "I ___ my glasses when I fell down." Answer: broke.
- Q20: Asks: "I was ___ for my brother. (mistake)" Answer: mistook (past tense).

## [Communicaiton] > Articles (20 questions)
- Q1: Asks: "He returned after ...... hour." Answer: an. Why: silent h → vowel sound.
- Q2: Asks: "After ....... fourth lesson, English students have ....... break of ..... hour and [a ...]." Answer: the, a, an, a.
- Q3: Asks: "Can you play_______piano" Answer: the.
- Q4: Asks: "_______Oranges are grown in Nagpur" Answer: no article.
- Q5: Asks: "This woman is wearing _______ awful hat" Answer: an.
- Q6: Asks: "... water is ... elixir of life, but ... water of this pond is poisonous." Answer: no article, the, the.
- Q7: Asks: "_____food that you cooked was good" Answer: the.
- Q8: Asks: "We live in _____ house" Answer: a.
- Q9: Asks: "Would you recognise _____Pope or _____ Queen of England?" Answer: the, the.
- Q10: Asks: "Please close _____window. Its cold here" Answer: the.
- Q11: Asks: "We were on a trip to _______ Alps." Answer: the. Why: plural noun.
- Q12: Asks: "________ owls were seated on a branch." Answer: the.
- Q13: Asks: "Shyam lives in _________ United Kingdom." Answer: the.
- Q14: Asks: "These countries lie in ________ equator of Earth" Answer: the. Why: unique place.
- Q15: Asks: "The crew visited ________ Switzerland." Answer: no article.
- Q16: Asks: "She bought me ______ novel to read." Answer: a. Why: consonant sound.
- Q17: Asks: "Buy _______ egg from the grocery store." Answer: an.
- Q18: Asks: "In the end ________ wamor in him was aroused." Answer: the.
- Q19: Asks: "___________ sky looked beautiful today." Answer: the. Why: unique of kind.
- Q20: Asks: "We met her at _______ church." Answer: the. Why: definite place.

Note: course shows 30% completed in 1h 44m; all quizzes show completed (green check) in sidebar.
