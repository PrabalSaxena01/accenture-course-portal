# Quiz Batch 3 — Section 10 networking + OS (7 quizzes, 132 questions)

Extracted 2026-10-14 via submit-unanswered → View Solution.
Per-question: Asks (paraphrased intent) / Answer (correct) / Why (gist).

## Networking Mock-1 (20 questions)
- Q1: Asks: network type built on top of another network. Answer: overlay network. Why: e.g. VPN, P2P.
- Q2: Asks: which is NOT a network-layer function. Answer: error control. Why: L3 provides routing paths.
- Q3: Asks: topology best describing the Internet. Answer: Mesh. Why: multiple paths between any two points.
- Q4: Asks: command viewing current IP config. Answer: Both ipconfig and ifconfig. Why: Windows vs Unix.
- Q5: Asks: what does "ping localhost" do? Answer: sends ICMP echo requests to local machine.
- Q6: Asks: IP 10.16.3.65/23 — which two statements describe it? Answer: 2 and 4 (lowest host 10.16.2.1; broadcast 10.16.3.255).
- Q7: Asks: two hosts wired directly, no connectivity (figure) — fixes? Answer: 1 and 5 (crossover cable; mask 255.255.255.0).
- Q8: Asks: max host IPs on subnet [prefix truncated]. Answer: 30.
- Q9: Asks: port number of POP. Answer: 110.
- Q10: Asks: MAC address length. Answer: 48 bits.
- Q11: Asks: proxy server also known as? Answer: Application level gateway.
- Q12: Asks: command displaying RIP updates. Answer: debug ip rip.
- Q13: Asks: what is "split horizon"? Answer: route info not sent back where the update came from.
- Q14: Asks: layer converting bits to electromagnetic signals. Answer: Physical.
- Q15: Asks: computer↔keyboard transmission mode. Answer: Simplex.
- Q16: Asks: sharing one channel among multiple signals. Answer: multiplexing.
- Q17: Asks: endpoint of inter-process communication flow across network. Answer: socket.
- Q18: Asks: in virtual-circuit network, each packet contains? Answer: a short VC number (VCID).
- Q19: Asks: 4000 frames/sec, 8 bits/slot — transmission rate? Answer: 32 kbps (4000×8).
- Q20: Asks: command testing connectivity + tracing path. Answer: tracert (traceroute on Unix).

## Networking Mock-2 (20 questions)
- Q1: Asks: web app sends but can't receive — malfunctioning layer? Answer: Transport. Why: end-to-end delivery.
- Q2: Asks: standard Ethernet frame size. Answer: 64 to 1518 bytes.
- Q3: Asks: primary benefit of EIGRP over RIP. Answer: Faster convergence.
- Q4: Asks: OSPF loop-prevention mechanism. Answer: Area designations.
- Q5: Asks: host bits to borrow for [given] subnet mask. Answer: 5.
- Q6: Asks: why parity bits used. Answer: To detect error.
- Q7: Asks: SMTP port. Answer: 25.
- Q8: Asks: asymmetric crypto — who keeps private key? Answer: Receiver.
- Q9: Asks: bit-oriented protocol. Answer: HDLC.
- Q10: Asks: what is "route poisoning"? Answer: router sets metric of downed link to infinity.
- Q11: Asks: IGRP default path parameters. Answer: 3 and 5 (cumulative delay; path bandwidth).
- Q12: Asks: 206.143.5.0 for Acme — which two default-route commands? Answer: 1 and 4.
- Q13: Asks: attack rendering a resource unavailable. Answer: denial-of-service.
- Q14: Asks: HTTP code for CREATED via POST/PUT. Answer: 201.
- Q15: Asks: in REST, server provides resource access; client accesses/modifies? Answer: True.
- Q16: Asks: domain registrars accredited by whom? Answer: ICANN.
- Q17: Asks: open-loop congestion control policies applied to what end? Answer: Prevent before congestion occurs.
- Q18: Asks: Go-Back-N timeout — which packets resent? Answer: only lost/corrupted ones (Selective Repeat behavior).
- Q19: Asks: new network not in routing tables — check first? Answer: Network advertisements.
- Q20: Asks: SNMP message agent→manager for events. Answer: TRAP.

## Networking SB Mock-1 (20 questions, scenario-based)
- Q1: Asks: office LAN packet loss on one segment only — faulty device? Answer: Switch. Why: per-segment switch/port failure.
- Q2: Asks: video calls slow during high bandwidth — implement? Answer: QoS for voice/video.
- Q3: Asks: two LANs joined — device limiting broadcasts? Answer: Bridge. Why: L2 filtering.
- Q4: Asks: isolate guests on same switch. Answer: separate VLANs.
- Q5: Asks: mask changed /24→/25, some devices can't communicate — why? Answer: devices in different subnets.
- Q6: Asks: crowded conference Wi-Fi disconnects — cause? Answer: AP signal interference (overlapping channels).
- Q7: Asks: branch slow DB access over leased line — cause? Answer: insufficient leased-line bandwidth.
- Q8: Asks: intranet unreachable but Internet works — check first? Answer: local DNS server config.
- Q9: Asks: ping by IP works, not by hostname — issue? Answer: DNS server settings.
- Q10: Asks: new office wireless — highest-security setting? Answer: WPA3.
- Q11: Asks: total connectivity loss after switch firmware update — investigate which layer next? Answer: Physical layer.
- Q12: Asks: TCP sent 1001–2000, ACK=1501 — meaning? Answer: receiver got bytes through 1500 (cumulative ACK).
- Q13: Asks: client SYN sent, SYN-ACK lost — client should? Answer: Resend SYN.
- Q14: Asks: distance-vector router gets shorter-path update — guard mechanism? Answer: Hold-down timer.
- Q15: Asks: Wi-Fi user moves away, system auto-adjusts — mechanism? Answer: Rate adaptation.
- Q16: Asks: router between 100 Mbps LAN and 10 Mbps WAN, queue filling — phenomenon? Answer: Queuing delay buildup.
- Q17: Asks: IPv6-only network, can't ping IPv4 server — cause? Answer: no dual-stack/NAT64 translation.
- Q18: Asks: router gets TTL=1 packet, discards + responds — which ICMP? Answer: ICMP Time Exceeded.
- Q19: Asks: OSPF router returns online, immediate problems — cause? Answer: routing table convergence delay.
- Q20: Asks: private-IP network with NAT, local web server unreachable from Internet — fix? Answer: port forwarding on NAT.

## Networking SB Mock-2 (20 questions, scenario-based)
- Q1: Asks: legacy Ethernet high collisions — replace hub with? Answer: Layer 2 switch. Why: isolates collision domains.
- Q2: Asks: which layer determines TCP MSS? Answer: Transport Layer.
- Q3: Asks: budget office network topology? Answer: Bus topology.
- Q4: Asks: FTP ports/channels? Answer: TCP 21 (control), TCP 20 (data).
- Q5: Asks: core router very high CPU [routing-loop symptoms] — cause? Answer: routing loop.
- Q6: Asks: OSI-spanning protocol [truncated]. Answer: MPLS.
- Q7: Asks: stateful firewall, outbound web connection — return traffic? Answer: auto-permitted as established connection.
- Q8: Asks: intermittent dropouts on some devices — cause? Answer: cable >100 m or EMI (L1 issue).
- Q9: Asks: client 10.1.1.10/24 sending to different subnet — does what? Answer: consults routing table for next-hop (default gateway).
- Q10: Asks: automatic addressing on DHCP-less segment — mechanism name? Answer: APIPA.
- Q11: Asks: poor video conferencing during backups — implement? Answer: Traffic Shaping and Queuing (QoS).
- Q12: Asks: forward proxy for outbound web — which feature serves user requests? Answer: Caching.
- Q13: Asks: packet goes one path, returns another — what? Answer: Asymmetrical routing.
- Q14: Asks: load balancer using HTTP headers/URL/cookies — operates at? Answer: Layer 7 (Application).
- Q15: Asks: WPA3-Personal key security mechanism? Answer: SAE (Simultaneous Authentication of Equals).
- Q16: Asks: remote employee secure file access — edge device terminating tunnel? Answer: VPN Gateway/Concentrator.
- Q17: Asks: Europe user types www.mycompany.asia first time; after local DNS, next server type? Answer: TLD server.
- Q18: Asks: slow Wi-Fi only when microwave on — cause? Answer: 2.4 GHz non-Wi-Fi interference.
- Q19: Asks: router learns 172.16.0.0/16 via OSPF and EIGRP — deciding parameter? Answer: Administrative Distance.
- Q20: Asks: two routers, one LAN, high availability — protocol? Answer: VRRP or HSRP.

## Networking (Medium - Hard) (12 questions)
- Q1: Asks: network address for 192.168.1.150/27. Answer: 192.168.1.128. Why: /27 block size 32; 150 in 128–159.
- Q2: Asks: usable hosts with mask 255.255.255.240. Answer: 14. Why: 4 host bits → 16−2.
- Q3: Asks: subnet mask for /26. Answer: 255.255.255.192.
- Q4: Asks: 10 MB file in 8 s — speed in Mbps? Answer: 10 Mbps. Why: 80 Mb/8 s.
- Q5: Asks: subnet mask for /24. Answer: 255.255.255.0.
- Q6: Asks: broadcast for 10.1.1.0/24. Answer: 10.1.1.255.
- Q7: Asks: megabits in 2 megabytes? Answer: 16. Why: 2M bytes × 8.
- Q8: Asks: 25 computers, same subnet + Internet — best approach? Answer: router with NAT + private 192.168.1.1–25.
- Q9: Asks: can ping 8.8.8.8 but not open google.com (others can) — cause? Answer: DNS server config issue.
- Q10: Asks: two offices 50 miles apart, share files as one network — solution? Answer: Site-to-Site VPN.
- Q11: Asks: coffee-shop Wi-Fi slow, single router — fix? Answer: multiple APs, same SSID, proper channel planning.
- Q12: Asks: exposed SSH (22) with weak passwords — immediate action? Answer: disable SSH or restrict to internal network.

## OS SB Mock-1 (20 questions, scenario-based)
- Q1: Asks: slow video editing — OS function deciding next CPU process? Answer: Process Scheduling.
- Q2: Asks: critical system files deleted — mechanism restricting access? Answer: ACLs.
- Q3: Asks: large memory block managed via secondary storage — technique? Answer: Virtual Memory.
- Q4: Asks: app crashes from memory exhaustion despite free RAM — what? Answer: Memory Leak.
- Q5: Asks: old printer on modern OS — what enables communication? Answer: Device Driver.
- Q6: Asks: multiple remote users simultaneously — OS type? Answer: Multi-User OS.
- Q7: Asks: OS refuses to load invalid program file — responsible component? Answer: File System.
- Q8: Asks: unresponsive server process, can't terminate normally — state? Answer: Zombie.
- Q9: Asks: FCFS scheduling, three processes [given] — metric? Answer: 12 ms.
- Q10: Asks: 16-bit logical space, 1024-byte pages [truncated] — number? Answer: 2. Why: address/page size, integer part.
- Q11: Asks: 4 frames, reference string [truncated] — FIFO faults? Answer: 6.
- Q12: Asks: P1–P4 bursts 10,5,2,3 — avg waiting? Answer: 4 ms.
- Q13: Asks: 10,000 tracks; 40 KB file; 4 KB buffer/I/O — I/O ops? Answer: 10. Why: 40/4.
- Q14: Asks: kernel for highly secure transactions [truncated] — architecture? Answer: Microkernel. Why: services in user space → isolation.
- Q15: Asks: slow printer, OS collects output to free CPU — technique? Answer: Spooling.
- Q16: Asks: process reads file data not in user space — mediating mechanism? Answer: System Call.
- Q17: Asks: 4 pages; ref string 1,2,4,3,2,1,4 [truncated] — page faults? Answer: 5.
- Q18: Asks: deterministic request→response DB server — which OS? Answer: Hard Real-Time OS.
- Q19: Asks: multithreaded process — what's unique per thread? Answer: Program Counter (PC).
- Q20: Asks: constant paging, CPU idle — degradation state? Answer: Thrashing.

## OS SB Mock-2 (20 questions, scenario-based)
- Q1: Asks: program makes file-read OS request — kernel executes in which mode? Answer: Kernel Mode.
- Q2: Asks: legacy app must run at boot bypassing startup — enabling component? Answer: Shell (command interpreter)/init script.
- Q3: Asks: OS rapidly switching between apps — concept? Answer: Concurrency.
- Q4: Asks: kernel security patch without reboot — technique? Answer: Kernel Hot-Swapping (live patching).
- Q5: Asks: variable-sized segments for large block — technique? Answer: Segmentation.
- Q6: Asks: P1 writes pipe, P2 reads — IPC model? Answer: Producer-Consumer.
- Q7: Asks: P1(AT=0,BT=7), P2, P3 [scheduling, truncated] — ms? Answer: 2.00 ms.
- Q8: Asks: disk 10 surfaces × 500 tracks × 50 sectors × 1 KB — capacity? Answer: 250 MB.
- Q9: Asks: 2^32 virtual space, 8 KB pages, 2^24 physical — max page-table entries? Answer: 2^19.
- Q10: Asks: 5 ms quantum + context-switch overhead [truncated] — CPU utilization? Answer: 90.9%.
- Q11: Asks: FIFO, 3 frames, ref string [truncated] — final frames? Answer: 4, 2, 3.
- Q12: Asks: Banker's algorithm, R=5 instances, P1/P2/P3 hold 2/1/1 [truncated] — safe result? Answer: 1.
- Q13: Asks: threads share counter via mutex spinlock [truncated] — main downside? Answer: wasting CPU in busy waiting.
- Q14: Asks: microkernel user-space services — how do user processes reach them? Answer: message-passing IPC primitives.
- Q15: Asks: kernel module hits uninitialized memory — most dangerous in which architecture? Answer: Monolithic kernel (shared privileged address space).
- Q16: Asks: limit resources for a process group — feature? Answer: cgroups.
- Q17: Asks: I/O devices accessing memory directly, bypassing CPU — what? Answer: DMA.
- Q18: Asks: ASLR randomizes memory layout — mitigates? Answer: Buffer overflow + ROP.
- Q19: Asks: new thread with ULT/KLT support — better choice? Answer: Kernel-Level Thread — blocking is independent.
- Q20: Asks: repeated preemption while holding resource needed by high-priority task; missed deadlines — problem + fix? Answer: Priority inversion; priority inheritance.

Note: some question texts/explanations truncated by platform rendering (marked in source). Networking SB Mock-1's Question Paper opened the palette, not a full modal — count confirmed via solutions page (20).
