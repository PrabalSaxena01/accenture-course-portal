# Quiz Batch 2 — Section 10 pseudocode group (7 quizzes, 85 questions)

Extracted 2026-10-14 via submit-unanswered → View Solution.
Per-question: Asks (paraphrased intent) / Answer (correct) / Why (gist).

## Pseudo Mock-2 (20 questions)
- Q1: Asks: flowchart maps X→Y via three branches (prime → X²+1, even → 2X+4, odd composite → 2X−1); for how many X<50 does the same output repeat? Answer: 0. Why: no two X<50 give same Y across formulas.
- Q2: Asks: if/else-if ladder on x prints "Brinda" if x>4, "Karthik" if x>10, "Pradeep" if x>21, else "Sandeep"; for which x does "Karthik" print? Answer: none. Why: "Karthik" branch reachable only when x≤4, contradicting x>10 — never prints.
- Q3: Asks: trace snippet (m=9, n=6, increments, comparison using N=n−1); printed value? Answer: 15.
- Q4: Asks: trace recursive fun(x,y) recursing (x−2, y+2) while x>1, printing y on unwind, x=4, y=5. Answer: 9 7 5.
- Q5: Asks: C code printing char 'A' with %d. Answer: 65. Why: ASCII of 'A'.
- Q6: Asks: evaluate funn(a=9, b=5) with if testing (b^a < b&a). Answer: 9. Why: 12<1 false → return a=9.
- Q7: Asks: snippet a=3,b=4,c=6; c→18; conditional b-doubling; print a+b+c. Answer: 25. Why: (c−6)<(6−c) → 12<−12 false; 3+4+18=25.
- Q8: Asks: two-loop function with XOR/AND (a=2,b=6,c=7); return a+b. Answer: 121. Why: first loop drives a→121; second zeroes b.
- Q9: Asks: nested if/else with XOR/AND (a=1,b=4,c=4); return a+b+c. Answer: 50.
- Q10: Asks: cuboid snippet (w=d=h=2); displayed volume/surface area. Answer: 8 24. Why: 2³=8; 2×(4+4+4)=24.
- Q11: Asks: recursive function with 5 prints "Welcome" while num>0 then num--; how many prints? Answer: 5.
- Q12: Asks: what does snippet do (stores string, loops last index→0 printing chars)? Answer: Reverses string and prints it.
- Q13: Asks: float 20.45→int, then (post-dec + pre-dec − pre-inc); printed? Answer: 19. Why: 20+18−19=19.
- Q14: Asks: trace funn(a=4,b=2): a=a+b+2; a=a*2; if(a) return a−b else a+b. Answer: 14. Why: a→8→16 (truthy) → 16−2=14.
- Q15: Asks: for-loop (x 1→11) containing x=x+2; printed x? Answer: 13.
- Q16: Asks: while loop (a=125,b=122): if (a+b) odd, repeat b=a+b, a//=5 until a=0; print b. Answer: 278. Why: b: 247→272→277→278 as a: 125→25→5→1→0.
- Q17: Asks: arithmetic/MOD (x=16,y=6): x=x+y; y=x/10; x=(x−y)MOD5; x=x+6; print x,y. Answer: 6 2.
- Q18: Asks: array updates (a={0,1,0}; additions; if a[0] then a[3]=5; m=m+a[3]); printed m? Answer: 6. Why: a[3]=5; m=1+5=6.
- Q19: Asks: summation (f=6,g=9): if g>f, loop n from f while n<g accumulating; print sum. Answer: 21 (6+7+8).
- Q20: Asks: z = x++ + ++y, x=2,y=4; printed z? Answer: 7. Why: 2+5=7.

## Pseudocode - 1 (10 questions; no explanations shown)
- Q1: Asks: adjacent-sum transform (arr=[1,2,3,4,5], arr[i]+=arr[i+1]); print array. Answer: 3 5 7 9 5.
- Q2: Asks: x=0,y=3,z=11; evaluate if(x+(1|2) && y+(2|3)); predict x+y+z. Answer: 7.
- Q3: Asks: operation of loop printing string array last→first. Answer: reverses the string.
- Q4: Asks: recursive solve(x,y), x=10,y=5. Answer: 18.
- Q5: Asks: adjacent-difference transform (arr=[5,4,3,2,1], arr[i]−=arr[i+1]); print array. Answer: 1 1 1 1 1.
- Q6: Asks: recursive solve(n,m) with (n>4 && m<7), n=5,m=6. Answer: 13.
- Q7: Asks: operation of loop printing string array first→last. Answer: prints the original string.
- Q8: Asks: adjacent-product transform (arr=[5,4,3,2,1], arr[i]*=arr[i+1]); print array. Answer: 20 12 6 2 1.
- Q9: Asks: nested loops (w=21,x=11; y 21–30; z −1–0; w decrement w/ continue/jump); printed w+x? Answer: 12.
- Q10: Asks: conditionals (x=10,y=16,z=3; else y=x/2; nested if; y=z/2); printed x+y+z? Answer: 14.

## Pseudocode - 2 (10 questions; no explanations shown)
- Q1: Asks: operation of loop running once (l=0→0) printing word[0]. Answer: prints first character.
- Q2: Asks: x=−2,y=3,z=1; evaluate if(x+(2&2) && y+(3&3) && z+(2^2)); predict x+y+z. Answer: 3.
- Q3: Asks: y=7 mod 2, x=9 mod 2 in funn; return x+y. Answer: 2.
- Q4: Asks: nested conditionals (x=8,y=6,z=4); printed value? Answer: 14.
- Q5: Asks: nested loops (a=1,b=1; c 1–2; d −2–0; a+=2 w/ continue); printed a+b? Answer: 14.
- Q6: Asks: p=3,q=8,r=1 (sum 12); compound AND condition; printed message? Answer: Fail.
- Q7: Asks: nested loops (w=1,x=1; y 11–20; z −3–0; w+=5 w/ continue/jump); printed w+x? Answer: 2.
- Q8: Asks: conditionals (x=10,y=16,z=3; else y=x); printed value? Answer: 16.
- Q9: Asks: recursive solve(a,b) with (a<3 && b<4), a=11,b=12. Answer: 23.
- Q10: Asks: multiply-recursive solve(x,y), x=4,y=9. Answer: 41.

## Pseudocode - 3 (10 questions)
- Q1: Asks: JS reduce summing [1,2,3] from 0. Answer: 6.
- Q2: Asks: Python set intersection {1,2,3} & {3,4,5}. Answer: {3}.
- Q3: Asks: C bitwise OR 5|3. Answer: 7. Why: 101|011=111.
- Q4: Asks: JS [1,2,3].map(x*2).filter(x>4). Answer: [6].
- Q5: Asks: JS 1+"2"+3. Answer: "123". Why: string concatenation via "2".
- Q6: Asks: Python aliasing (y=x; y.append(4); print(x)). Answer: [1, 2, 3, 4]. Why: same list reference.
- Q7: Asks: C short-circuit (a=5,b=0; if(a && b++)). Answer: 0. Why: b++ not evaluated.
- Q8: Asks: JS typeof null. Answer: "object" (reported as true). Why: legacy quirk.
- Q9: Asks: Python x,y = y,x+y (x=10,y=20). Answer: 20, 30.
- Q10: Asks: in-place array reversal on [1,2,3,4]. Answer: [4, 3, 2, 1].

## Pseudocode - 4 (10 questions)
- Q1: Asks: count primes 1–20 via isPrime. Answer: 7.
- Q2: Asks: 5th term of Fibonacci-style loop (x←0,y←1,z←x+y). Answer: 8.
- Q3: Asks: what does mystery(x) compute (halve evens, 3x+1 odds, count steps to 1)? Answer: Collatz step count.
- Q4: Asks: final z after while loop (y←3,z←0, x+=2). Answer: 21.
- Q5: Asks: compute(6) for compute(x)=compute(x−1)+compute(x−2). Answer: 21. Why: Fibonacci; compute(6)=21.
- Q6: Asks: y after nested loops (x←5; i 1..x, j 1..i: y←y+j). Answer: 35.
- Q7: Asks: recursive mystery(n) = n*mystery(n−1). Answer: Factorial.
- Q8: Asks: output of while loop (x←10,y←5; y updated by x's parity). Answer: -5.
- Q9: Asks: 7 MOD 3. Answer: 1.
- Q10: Asks: sum of integers 1–100. Answer: 5050.

## Recursion (Medium - Hard) (10 questions)
- Q1: Asks: recursive calculate_value(4), x*f(x−1) − f(x−2), f(x)=x for x<2. Answer: 18. Why: unwind 2, 5, 4×5−2=18.
- Q2: Asks: recursive TransformString("abcde") splitting/swapping halves. Answer: "edcba".
- Q3: Asks: recursive CalculateArray summing elements divisible by 3 (skip next after hit). Answer: 27. Why: hits 6,9,12.
- Q4: Asks: G(n)=3·G(n−1)−2·G(n−2), G(0)=1,G(1)=2, n=5. Answer: 32. Why: powers of 2.
- Q5: Asks: recursive binomial AnalyzePattern(4,2). Answer: 6. Why: C(4,2).
- Q6: Asks: recursive CountPaths(3,3). Answer: 6.
- Q7: Asks: recursive digital root of 9875. Answer: 2. Why: 29→11→2.
- Q8: Asks: any subset summing to target (CheckCombinationC)? Answer: TRUE. Why: e.g. [4,5]→9.
- Q9: Asks: distinct arrangements of "AAB" (CountArrangementsD). Answer: 3 (AAB, ABA, BAA).
- Q10: Asks: doubling recurrence X for 4 items (base 1). Answer: 16. Why: 2^4.

## Pseudocode Bit Operators (Medium-Hard) (15 questions)
- Q1: Asks: (a AND b) OR (a XOR b), a=37,b=23. Answer: 55. Why: 5|50=55.
- Q2: Asks: (120 << 3) >> 2. Answer: 240. Why: 960>>2.
- Q3: Asks: (55 XOR 29) << 2. Answer: 168. Why: 42×4.
- Q4: Asks: (45 AND 25) + (45 OR 25) − (45 XOR 25). Answer: 18. Why: 9+61−52.
- Q5: Asks: b=NOT a (a=32), c=b>>4. Answer: depends on machine. Why: arithmetic vs logical shift.
- Q6: Asks: (0x37 & 0x55) | (~0x37 & ~0x55) in C, hex. Answer: 0xFFFFFF9D.
- Q7: Asks: chained bitwise on a=73,b=109,c=167. Answer: 109.
- Q8: Asks: (a^b) & (b&c) & (c^a), a=73,b=109,c=167. Answer: 36.
- Q9: Asks: identify bit hack (x − ((x>>1) & 0x55555555), ...). Answer: population count (Hamming weight).
- Q10: Asks: d = (3^11) & 32. Answer: 0. Why: 8 & 32 share no bits.
- Q11: Asks: (12 & 7) | (12 ^ 7) in C. Answer: 15. Why: = x|y.
- Q12: Asks: expression testing exactly one of bits 5/6 set. Answer: ((x & 0x10) != 0) ^ ((x & 0x20) != 0).
- Q13: Asks: what does bit-spreading fn compute (x|=x>>1; x|=x>>2; ...; x−(x>>1))? Answer: highest set bit's value.
- Q14: Asks: (0xAB >> 2) & ~(0xCD << 3), 8-bit unsigned. Answer: 0x02. Why: 0x2A & 0x97.
- Q15: Asks: expressions swapping two variables without temp. Answer: All of the above (arithmetic, mul/div, XOR — each with caveats).

Note: Pseudo Mock-2 questions were image-based (read via screenshots, paraphrased); others text-based. Pseudocode-1/2 show "No explanation available".
