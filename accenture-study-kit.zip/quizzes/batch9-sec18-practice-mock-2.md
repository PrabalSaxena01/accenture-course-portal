# Quiz Batch 9 — Section 18 Practice Mock Test 2 (6 quizzes, 90 questions)

Extracted 2026-10-14 via submit-unanswered → View Solution.
Per-question: Asks (paraphrased intent) / Answer (correct) / Why (gist).
Note: sixth quiz titled "Pseudo Code (Easy)" on the platform.

## English Ability (17 questions)
- Q1: Asks: synonym of "Impediment"? Answer: Obstacle.
- Q2: Asks: error in "He don't know the answer." Answer: don't (→ doesn't).
- Q3: Asks: "She has been working here ___ three years." Answer: for.
- Q4: Asks: antonym of "Courageous"? Answer: Cowardly.
- Q5: Asks: correct spelling? Answer: Definitely.
- Q6: Asks: passive of "The chef cooked a delicious meal." Answer: "A delicious meal was cooked by the chef."
- Q7: Asks: "He congratulated her ___ her success." Answer: on.
- Q8: Asks: meaning of idiom "Hit the nail on the head"? Answer: to do something perfectly.
- Q9: Asks: arrange "Books / useful / are / very." Answer: "Books are very useful."
- Q10: Asks: "We ___ to the park every Sunday." Answer: go.
- Q11: Asks: synonym of "Abundant"? Answer: Plentiful.
- Q12: Asks: indirect speech of "I will visit tomorrow" (she said)? Answer: "She said that she would visit the next day."
- Q13: Asks: error in "The team were happy with the results." Answer: were (→ was).
- Q14: Asks: "He jumped ___ the wall." Answer: over.
- Q15: Asks: antonym of "Generous"? Answer: Selfish.
- Q16: Asks: part of speech of "Quickly" in "He completed the task quickly." Answer: Adverb.
- Q17: Asks: article before "university" in "___ university is a place of learning." Answer: A. Why: "yu" sound.

## Critical Reasoning and Problem Solving (18 questions)
- Q1: Asks: syllogism — some books are novels; all novels are fiction? Answer: some books are fiction.
- Q2: Asks: A taller than B but shorter than C; D shorter than A but taller than B — shortest? Answer: B.
- Q3: Asks: syllogism — all dogs are mammals; all mammals are animals? Answer: all dogs are animals.
- Q4: Asks: A is B's father, B is C's mother — A to C? Answer: Grandfather.
- Q5: Asks: syllogism — all apples are fruits; some fruits are sweet? Answer: none of the above (insufficient info).
- Q6: Asks: which statement weakens "Technology improves productivity"? Answer: employees need time to adapt to new technology.
- Q7: Asks: bench-seating puzzle (A–E, given constraints) — where does A sit? Answer: between B and C.
- Q8: Asks: analogy Architect:Building :: Sculptor:? Answer: Statue.
- Q9: Asks: assumption in "If you eat healthily, you will stay fit." Answer: healthy eating causes fitness.
- Q10: Asks: arrange 1. Poverty 2. Population 3. Death 4. Unemployment 5. Disease meaningfully? Answer: 2, 4, 1, 5, 3.
- Q11: Asks: statement "Fashion is a form of ugliness..." — conclusions? Answer: only conclusion II follows.
- Q12: Asks: next in 8, 22, 8, 28, 8, ...? Answer: 34. Why: 22+6, 28+6 (8 interpolated).
- Q13: Asks: tank fills in 5h; inlet closed after 3h — how much filled? Answer: 3/5.
- Q14: Asks: analogy Cup:coffee :: bowl:? Answer: soup.
- Q15: Asks: analogy Candid:indirect :: honest:? Answer: untruthful.
- Q16: Asks: 1/3 salary rent, 1/4 food — fraction saved? Answer: 5/12.
- Q17: Asks: P(red card or face card) from deck? Answer: 8/13. Why: (26+12−6)/52.
- Q18: Asks: 10% raise then 10% cut — net change? Answer: −1%. Why: 1.1×0.9−1.

## Abstract Reasoning (15 questions)
- Q1: Asks: next in 3, 9, 27, 81, __? Answer: 243 (×3).
- Q2: Asks: missing shape in ○ ▲ ○ ▲ ○ __? Answer: ▲.
- Q3: Asks: if South-East becomes North, North-East becomes West (etc.), what does West become? Answer: South-East.
- Q4: Asks: pie chart subject-wise marks (total 500) — CS marks? Answer: 150 (30%).
- Q5: Asks: 6-month line chart companies A/B — when did A's sales first surpass 300? Answer: April.
- Q6: Asks: direction-distance path (X, 15m W, left 20m, left 15m, right 12m) — distance/direction from X? Answer: 32 m, South.
- Q7: Asks: path (25m S, left 20m, left again...) — distance/direction? Answer: 35 m East.
- Q8: Asks: circle rotates 90° clockwise each step — look after 4th step? Answer: same as original.
- Q9: Asks: which shape completes alternating pattern? Answer: ◆ (alternates ♦/◆).
- Q10: Asks: coded relations (# = father, @ = sister; X # Y, Y @ Z) — true statement? Answer: X is father of Z.
- Q11: Asks: decode "GAMBLING" given "TRAINERS"→"WWDNQJUX"? Answer: JFPGONQL.
- Q12: Asks: given TRY→ABC, SHAPE→DEFGH, code THREE? Answer: AEBHH.
- Q13: Asks: missing term Q1F, S2E, U6D, W21C, ?? Answer: Y66B.
- Q14: Asks: six-person hexagonal seating — who sits opposite P? Answer: S.
- Q15: Asks: same setup — who is fourth to the left of Q? Answer: P.

## Common Application and MS Office (12 questions)
- Q1: Asks: paste shortcut in Word/Excel? Answer: Ctrl+V.
- Q2: Asks: what does Track Changes do? Answer: keeps record of edits/comments.
- Q3: Asks: Excel formula for highest value in range? Answer: =MAX().
- Q4: Asks: PowerPoint view showing slide thumbnails? Answer: Slide Sorter View.
- Q5: Asks: which Office app for databases? Answer: Access.
- Q6: Asks: insert page numbers in Word? Answer: Insert tab → Page Number.
- Q7: Asks: adjust Excel column width? Answer: drag column header boundary.
- Q8: Asks: default PowerPoint slide layout? Answer: Title and Content.
- Q9: Asks: Excel feature auto-filling a range? Answer: Fill Handle.
- Q10: Asks: check spelling/grammar in Word? Answer: Review tab → Spelling & Grammar.
- Q11: Asks: add comment to Excel cell? Answer: right-click → Insert Comment.
- Q12: Asks: consistent design across presentation? Answer: Slide Master.

## Network Security and Cloud (10 questions)
- Q1: Asks: what does a DoS attack aim to do? Answer: overload network/server, making it unavailable.
- Q2: Asks: primary benefit of cloud over on-premise? Answer: no need for hardware upgrades.
- Q3: Asks: deployment model using both public and private clouds? Answer: Hybrid Cloud.
- Q4: Asks: which is NOT a cloud-security component? Answer: Cloud backup.
- Q5: Asks: purpose of MFA? Answer: verify identity via multiple methods.
- Q6: Asks: purpose of load balancing in cloud? Answer: distribute traffic across servers for reliability/performance.
- Q7: Asks: which cloud service protects web apps from threats? Answer: WAF.
- Q8: Asks: model for dev/test/run without managing infra? Answer: PaaS.
- Q9: Asks: primary advantage of VPC? Answer: private network within public cloud — security and control.
- Q10: Asks: offering providing pre-built software over internet? Answer: SaaS.

## Pseudo Code (Easy) (18 questions)
- Q1: Asks: A=5, B=10, C=A+B output? Answer: 15.
- Q2: Asks: X=0, FOR I=1 TO 5: X=X+I — does what? Answer: sums 1 to 5.
- Q3: Asks: error in A=10, B=0, C=A/B? Answer: division by zero.
- Q4: Asks: X=1, WHILE X<=10: X=X+1 — purpose? Answer: print numbers 1 to 10.
- Q5: Asks: A=2, B=3, IF A>B PRINT A ELSE PRINT B? Answer: 3.
- Q6: Asks: N=5 factorial accumulator loop — does what? Answer: 5! = 120.
- Q7: Asks: X=10, Y=20, SWAP, PRINT X, Y? Answer: 20, 10.
- Q8: Asks: IF A MOD B = 0 (A=10, B=5) — does what? Answer: prints "Divisible."
- Q9: Asks: A=3, C=A*B=15, IF C>10 PRINT "Large" else "Small"? Answer: Large.
- Q10: Asks: FOR I=1 TO 10 STEP 2 — executions? Answer: 5.
- Q11: Asks: A=5, B=2, WHILE A>0: PRINT A, A=A−B? Answer: 5, 3, 1.
- Q12: Asks: FOR I=1 TO 10 with IF I MOD 2 = 0 filter? Answer: all evens 1–10.
- Q13: Asks: SUM=0, I=1, WHILE I<=3: SUM=SUM+I? Answer: 6.
- Q14: Asks: COUNT=0, FOR I=1 TO 10, IF I MOD 2=0: COUNT++ — purpose? Answer: count evens 1–10 (5).
- Q15: Asks: A=4, B=6, C=A+B, IF C>10 PRINT "Yes" ELSE "No"? Answer: Yes. Why: marked correct (platform's explanation wording inconsistent, says "C is 10 which is greater than 10").
- Q16: Asks: X=10, WHILE X>0: PRINT X, X=X−2 — purpose? Answer: print evens 10→2 in reverse.
- Q17: Asks: SUM=0, FOR I=1 TO 100: SUM=SUM+I? Answer: 5050.
- Q18: Asks: A=7, B=3, C=A % B? Answer: 1.

Note: Q15's platform explanation contains an arithmetic inconsistency ("C is 10, which is greater than 10") — recorded as shown; marked correct option is "Yes".
