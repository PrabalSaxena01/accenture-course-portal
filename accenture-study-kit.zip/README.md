# Accenture Mock Test Series — Offline Study Kit

Extracted 2026-10-14 from `knacademycourses.graphy.com` (course owner authorized).
All question intents are paraphrased study notes; answers are the key correct answers
as marked by the platform's official solutions. Brief exact terms/values quoted only.

## Contents

- `index.html` — offline study app: browse all quizzes, search, show/hide answers,
  progress checklist (saved in the browser via localStorage). Open it in any browser;
  it loads `dataset.json` from the same folder.
- `dataset.json` — structured data: 80 quizzes, 1,625 questions (`asks`, `answer`, `why`),
  plus article metadata.
- `quizzes/` — per-batch markdown source files (pilot + batches 1–11 + interactive).
- `articles/` — 62 articles as paraphrased study notes (3 chunk files).

## Coverage

| Area | Status |
|---|---|
| 62 articles | ✅ extracted as study notes |
| 77 standard quizzes | ✅ 1,481 questions with answers |
| Embedded full paper + 2 technical sets | ✅ 134 questions |
| Grammar practice (30Q) | ✅ |
| Listening comprehension (8 passages × 2Q) | ✅ |
| Section 13 coding labs (10 items) | ✅ problems + key approaches |
| 32 PDFs | ⚠️ downloaded but password-protected — open password unknown; share it to unlock |
| 13 videos | ❌ player streams via video.js with no download button; source URLs not obtainable with available tools — download via the Graphy mobile app's offline feature or provide direct URLs |

## Notes

- Some platform answer keys were internally inconsistent (flagged in the app):
  Complete Set - Technical 2 Q32/Q37 (options duplicated from neighbors, key contradicts
  explanation — marked unreliable), Full Paper Q27 (learner-disputed), Easy Reasoning
  batch 9 Q15 (platform's own explanation misstates its arithmetic).
- Mic-required speaking/listening-record apps were identified but not attempted.
- Each quiz submission recorded a completed attempt on the course account (approved).
